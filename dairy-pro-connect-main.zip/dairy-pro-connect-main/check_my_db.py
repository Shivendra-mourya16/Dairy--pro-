import os
from sqlalchemy import create_engine, inspect, text
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
db_url = os.getenv('DATABASE_URL')

if not db_url:
    print("❌ Error: DATABASE_URL not found in .env file")
    exit()

# Handle the hostaddr fix if it's there
connect_args = {}
if "hostaddr=" in db_url:
    import urllib.parse
    parsed = urllib.parse.urlparse(db_url)
    params = urllib.parse.parse_qs(parsed.query)
    if 'hostaddr' in params:
        connect_args['hostaddr'] = params['hostaddr'][0]

try:
    engine = create_engine(db_url, connect_args=connect_args)
    inspector = inspect(engine)
    
    print("\n--- 📊 Dairy Pro Database Explorer ---")
    tables = inspector.get_table_names()
    
    if not tables:
        print("⚠️ No tables found in the database. (Maybe they haven't been created yet?)")
    else:
        print(f"✅ Found {len(tables)} tables:\n")
        print(f"{'Table Name':<25} | {'Row Count':<10}")
        print("-" * 40)
        
        with engine.connect() as conn:
            for table in tables:
                # Get row count for each table
                try:
                    result = conn.execute(text(f'SELECT COUNT(*) FROM "{table}"'))
                    count = result.scalar()
                    print(f"{table:<25} | {count:<10}")
                except Exception as e:
                    print(f"{table:<25} | Error: {str(e)[:20]}...")

    print("\n💡 Suggestion: If you want to see data for a specific table, run:")
    print("   SELECT * FROM table_name LIMIT 10; in Neon SQL Editor.")

except Exception as e:
    print(f"❌ Connection Failed: {e}")
