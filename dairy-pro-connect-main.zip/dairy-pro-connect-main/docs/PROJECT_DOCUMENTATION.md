# Dairy Pro - Complete Project Documentation

## Table of Contents
1. [Project Overview](#1-project-overview)
2. [Technology Stack](#2-technology-stack)
3. [Architecture](#3-architecture)
4. [Database Schema](#4-database-schema)
5. [Authentication Module](#5-authentication-module)
6. [Admin Module](#6-admin-module)
7. [User Module](#7-user-module)
8. [Milk Collection & Pricing Module](#8-milk-collection--pricing-module)
9. [Payment Distribution Module](#9-payment-distribution-module)
10. [Cattle Marketplace Module](#10-cattle-marketplace-module)
11. [Supplements Distribution Module](#11-supplements-distribution-module)
12. [Security & Access Control](#12-security--access-control)
13. [File Structure](#13-file-structure)
14. [API Reference](#14-api-reference)

---

## 1. Project Overview

### 1.1 Introduction
**Dairy Pro** is a village-based dairy milk collection platform designed to provide complete transparency between Admins (Collection Center Operators) and Users (Farmers). The system digitizes the traditional milk collection process, ensuring fair pricing, accurate measurements, and transparent payment distribution.

### 1.2 Key Objectives
- Digitize milk collection records with accurate measurements
- Ensure transparent payment distribution (90% Farmer, 6% Admin, 4% Company)
- Provide verification system for farmers (Mobile, Email, Aadhaar, PAN)
- Enable cattle buy/sell marketplace for farmers
- Track supplement distribution to farmers
- Maintain complete audit trail of all transactions

### 1.3 User Roles
| Role | Description | Access Level |
|------|-------------|--------------|
| **Admin** | Collection center operator who manages milk collection, payments, and verified farmers | Full access to admin dashboard, verified user data, milk records, payments |
| **User (Farmer)** | Dairy farmer who sells milk to the collection center | Access to personal dashboard, own milk records, payments, cattle listings |

---

## 2. Technology Stack

### 2.1 Frontend
| Technology | Version | Purpose |
|------------|---------|---------|
| React | 18.3.1 | UI Framework |
| TypeScript | Latest | Type Safety |
| Vite | Latest | Build Tool & Dev Server |
| Tailwind CSS | Latest | Styling |
| React Router DOM | 6.30.1 | Client-side Routing |
| TanStack React Query | 5.83.0 | Server State Management |
| Shadcn/UI | Latest | UI Component Library |
| Lucide React | 0.462.0 | Icon Library |
| Recharts | 2.15.4 | Data Visualization |

### 2.2 Backend (Lovable Cloud / Supabase)
| Technology | Purpose |
|------------|---------|
| Supabase Auth | User Authentication |
| Supabase Database (PostgreSQL) | Data Persistence |
| Row Level Security (RLS) | Data Access Control |
| Database Functions | Business Logic |
| Edge Functions | Server-side Logic |

### 2.3 Design System
- **Primary Color**: Dairy Green (`hsl(142, 76%, 36%)`)
- **Secondary Color**: Dairy Cream (`hsl(43, 74%, 94%)`)
- **Accent Colors**: Dairy Gold, Dairy Earth, Dairy Sky
- **Typography**: Display font for headings, system fonts for body

---

## 3. Architecture

### 3.1 Application Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                      React Frontend                          │
├─────────────────────────────────────────────────────────────┤
│  Landing Page  │  Auth Pages  │  Admin Dashboard  │  User   │
│                │              │                   │Dashboard│
├─────────────────────────────────────────────────────────────┤
│                    React Router DOM                          │
├─────────────────────────────────────────────────────────────┤
│  AuthContext   │  TanStack Query  │  Supabase Client        │
├─────────────────────────────────────────────────────────────┤
│                    Lovable Cloud (Supabase)                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │   Auth   │  │ Database │  │   RLS    │  │ Functions│    │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Component Architecture
```
src/
├── components/
│   ├── layout/           # Layout components (Navbar, Sidebar, Footer)
│   └── ui/               # Reusable UI components (Button, Card, etc.)
├── contexts/             # React Context providers
├── hooks/                # Custom React hooks
├── pages/                # Page components
│   ├── admin/            # Admin-specific pages
│   ├── auth/             # Authentication pages
│   └── user/             # User-specific pages
├── types/                # TypeScript type definitions
├── lib/                  # Utility functions
└── integrations/         # External service integrations
```

### 3.3 Data Flow
```
User Action → React Component → Supabase Client → Database
                    ↓
              AuthContext (for auth state)
                    ↓
              React Query (for server state)
                    ↓
              UI Update
```

---

## 4. Database Schema

### 4.1 Entity Relationship Diagram
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   profiles  │────<│ milk_records│>────│  payments   │
│             │     │             │     │             │
│ id (PK)     │     │ id (PK)     │     │ id (PK)     │
│ full_name   │     │ user_id(FK) │     │ user_id(FK) │
│ mobile      │     │ admin_id    │     │ milk_rec_id │
│ email       │     │ milk_type   │     │ amount      │
│ aadhaar     │     │ weight      │     │ status      │
│ pan         │     │ fat_%       │     │ payment_type│
│ verified... │     │ snf_%       │     └─────────────┘
└─────────────┘     │ water_qty   │
       │            │ total_amount│
       │            │ user_payout │
       ↓            │ admin_cut   │
┌─────────────┐     │ company_cut │
│ user_roles  │     └─────────────┘
│             │
│ id (PK)     │     ┌─────────────┐
│ user_id(FK) │     │ supplements │
│ role        │     │             │
└─────────────┘     │ id (PK)     │
                    │ user_id(FK) │
┌─────────────┐     │ admin_id    │
│bank_details │     │ name        │
│             │     │ quantity    │
│ id (PK)     │     │ is_free     │
│ user_id(FK) │     │ price       │
│ bank_name   │     └─────────────┘
│ account_no  │
│ ifsc_code   │     ┌─────────────────┐
└─────────────┘     │cattle_listings  │
                    │                 │
┌─────────────────┐ │ id (PK)         │
│milk_price_set   │ │ user_id (FK)    │
│                 │ │ cattle_type     │
│ id (PK)         │ │ age_years       │
│ price_per_liter │ │ price           │
│ company_cut_%   │ │ is_sold         │
│ admin_cut_%     │ └─────────────────┘
│ user_payout_%   │
└─────────────────┘
```

### 4.2 Table Specifications

#### 4.2.1 `profiles`
Stores user profile information linked to auth.users.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | - | Primary key, references auth.users |
| full_name | TEXT | No | - | User's full name |
| mobile_number | TEXT | No | - | Mobile number |
| email | TEXT | No | - | Email address |
| aadhaar_number | TEXT | Yes | NULL | 12-digit Aadhaar number |
| pan_number | TEXT | Yes | NULL | 10-character PAN |
| address | TEXT | Yes | NULL | Physical address |
| mobile_verified | BOOLEAN | Yes | false | Mobile OTP verified |
| email_verified | BOOLEAN | Yes | false | Email OTP verified |
| aadhaar_verified | BOOLEAN | Yes | false | Aadhaar verified |
| pan_verified | BOOLEAN | Yes | false | PAN verified |
| profile_completed | BOOLEAN | Yes | false | Profile completion status |
| startup_plan | ENUM | Yes | NULL | 'basic' or 'advanced' |
| payment_completed | BOOLEAN | Yes | false | Startup payment status |
| created_at | TIMESTAMPTZ | Yes | now() | Record creation time |
| updated_at | TIMESTAMPTZ | Yes | now() | Last update time |

#### 4.2.2 `user_roles`
Maps users to their roles (admin/user).

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | References auth.users |
| role | ENUM | No | - | 'admin' or 'user' |

#### 4.2.3 `milk_records`
Stores daily milk collection entries.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | Farmer's user ID |
| admin_id | UUID | Yes | NULL | Admin who recorded |
| milk_type | ENUM | No | - | 'cow' or 'buffalo' |
| weight_liters | NUMERIC | No | - | Milk weight in liters |
| fat_percentage | NUMERIC | No | - | Fat content % |
| snf_percentage | NUMERIC | No | - | SNF content % |
| water_quantity | NUMERIC | Yes | 0 | Water content |
| price_per_liter | NUMERIC | No | - | Price at time of record |
| total_amount | NUMERIC | No | - | Total value |
| user_payout | NUMERIC | No | - | Farmer's 90% share |
| admin_cut | NUMERIC | No | - | Admin's 6% share |
| company_cut | NUMERIC | No | - | Company's 4% share |
| record_date | DATE | No | CURRENT_DATE | Collection date |
| created_at | TIMESTAMPTZ | Yes | now() | Record creation time |

#### 4.2.4 `payments`
Tracks all payment transactions.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | Recipient user ID |
| milk_record_id | UUID | Yes | NULL | Linked milk record |
| amount | NUMERIC | No | - | Payment amount |
| payment_type | TEXT | No | 'milk_payment' | Type of payment |
| status | TEXT | No | 'pending' | Payment status |
| payment_date | TIMESTAMPTZ | Yes | now() | Payment date |
| created_at | TIMESTAMPTZ | Yes | now() | Record creation time |

#### 4.2.5 `cattle_listings`
Marketplace for buying/selling cattle.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | Seller's user ID |
| photo_url | TEXT | Yes | NULL | Cattle photo URL |
| cattle_type | TEXT | No | - | Type (Cow/Buffalo) |
| age_years | INTEGER | No | - | Age in years |
| age_months | INTEGER | Yes | 0 | Additional months |
| number_of_calves | INTEGER | Yes | 0 | Number of calves |
| medical_records | TEXT | Yes | NULL | Medical history |
| address | TEXT | No | - | Location |
| price | NUMERIC | No | - | Asking price |
| description | TEXT | Yes | NULL | Additional details |
| is_sold | BOOLEAN | Yes | false | Sold status |
| created_at | TIMESTAMPTZ | Yes | now() | Listing date |
| updated_at | TIMESTAMPTZ | Yes | now() | Last update |

#### 4.2.6 `supplements`
Tracks supplement distribution to farmers.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | Recipient farmer |
| admin_id | UUID | Yes | NULL | Distributing admin |
| supplement_name | TEXT | No | - | Name of supplement |
| quantity | NUMERIC | No | - | Quantity distributed |
| unit | TEXT | No | 'kg' | Unit of measure |
| is_free | BOOLEAN | Yes | false | Free distribution |
| price | NUMERIC | Yes | 0 | Price if not free |
| distribution_date | DATE | No | CURRENT_DATE | Distribution date |
| created_at | TIMESTAMPTZ | Yes | now() | Record creation time |

#### 4.2.7 `milk_price_settings`
Global milk pricing configuration.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| price_per_liter | NUMERIC | No | 85.00 | Base price (₹80-90) |
| company_cut_percentage | NUMERIC | No | 4.00 | Company's share % |
| admin_cut_percentage | NUMERIC | No | 6.00 | Admin's share % |
| user_payout_percentage | NUMERIC | No | 90.00 | Farmer's share % |
| updated_by | UUID | Yes | NULL | Admin who updated |
| created_at | TIMESTAMPTZ | Yes | now() | Creation time |
| updated_at | TIMESTAMPTZ | Yes | now() | Last update |

#### 4.2.8 `bank_details`
Bank account information for payments.

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| id | UUID | No | gen_random_uuid() | Primary key |
| user_id | UUID | No | - | Account owner |
| bank_name | TEXT | No | - | Bank name |
| account_holder_name | TEXT | No | - | Account holder |
| account_number | TEXT | No | - | Account number |
| ifsc_code | TEXT | No | - | IFSC code |
| created_at | TIMESTAMPTZ | Yes | now() | Creation time |
| updated_at | TIMESTAMPTZ | Yes | now() | Last update |

---

## 5. Authentication Module

### 5.1 Overview
The authentication module handles user registration, login, and session management using Supabase Auth.

### 5.2 Components
| Component | Path | Description |
|-----------|------|-------------|
| Login | `src/pages/auth/Login.tsx` | Role-based login page |
| Signup | `src/pages/auth/Signup.tsx` | Multi-step registration |
| AuthContext | `src/contexts/AuthContext.tsx` | Auth state management |

### 5.3 Authentication Flow

#### 5.3.1 Signup Flow
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Step 1     │────>│  Step 2     │────>│  Step 3     │
│ Basic Info  │     │ OTP Verify  │     │ Documents   │
│             │     │             │     │             │
│ - Name      │     │ - Mobile OTP│     │ - Aadhaar   │
│ - Mobile    │     │ - Email OTP │     │ - PAN       │
│ - Email     │     │             │     │ - Address   │
│ - Password  │     │ Demo: 123456│     │             │
│ - Role      │     │             │     │             │
└─────────────┘     └─────────────┘     └─────────────┘
                                               │
                                               ▼
                                        ┌─────────────┐
                                        │  Redirect   │
                                        │ Based on    │
                                        │ Role        │
                                        └─────────────┘
```

#### 5.3.2 Login Flow
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Login      │────>│  Fetch      │────>│  Redirect   │
│  Credentials│     │  Profile &  │     │  to         │
│             │     │  Role       │     │  Dashboard  │
│ - Email     │     │             │     │             │
│ - Password  │     │             │     │ Admin →     │
│             │     │             │     │ /admin/...  │
│             │     │             │     │             │
│             │     │             │     │ User →      │
│             │     │             │     │ /user/...   │
└─────────────┘     └─────────────┘     └─────────────┘
```

### 5.4 Verification Requirements
A user is considered **verified** only when ALL of the following are true:
- ✅ Mobile number verified (OTP)
- ✅ Email verified (OTP)
- ✅ Aadhaar number verified
- ✅ PAN number verified

### 5.5 Database Function: `is_user_verified`
```sql
CREATE OR REPLACE FUNCTION public.is_user_verified(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = _user_id
      AND mobile_verified = TRUE
      AND email_verified = TRUE
      AND aadhaar_verified = TRUE
      AND pan_verified = TRUE
  )
$$
```

### 5.6 AuthContext API
```typescript
interface AuthContextType {
  user: User | null;           // Supabase user object
  session: Session | null;     // Supabase session
  profile: Profile | null;     // User profile data
  role: UserRole | null;       // 'admin' | 'user'
  loading: boolean;            // Loading state
  signUp: (email, password, metadata) => Promise<{ error }>;
  signIn: (email, password) => Promise<{ error }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}
```

---

## 6. Admin Module

### 6.1 Overview
The Admin module provides collection center operators with tools to manage farmers, record milk collection, process payments, and distribute supplements.

### 6.2 Admin Pages
| Page | Path | Description |
|------|------|-------------|
| Dashboard | `/admin/dashboard` | Overview with stats and quick actions |
| Complete Profile | `/admin/complete-profile` | Mandatory profile + startup plan |
| User Management | `/admin/users` | View/manage verified farmers |
| Milk Collection | `/admin/milk-collection` | Record daily milk entries |
| Payments | `/admin/payments` | Process and track payments |
| Supplements | `/admin/supplements` | Distribute supplements |
| Cattle | `/admin/cattle` | View cattle marketplace |
| Settings | `/admin/settings` | Milk pricing & bank details |

### 6.3 Admin Profile Completion
Before accessing the dashboard, admins must complete:
1. **Personal Information**
   - Full Name
   - Aadhaar Number
   - PAN Number
   - Mobile Number
   - Address

2. **Startup Plan Selection**
   | Plan | Investment | Features |
   |------|------------|----------|
   | Basic | ₹2-3 Lakhs | Essential collection equipment |
   | Advanced | ₹5 Lakhs | Full setup with cold storage |

3. **Payment** (UI demo only)

### 6.4 Admin Dashboard Features
```
┌─────────────────────────────────────────────────────────┐
│                    Admin Dashboard                       │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐       │
│  │ Verified    │ │ Today's     │ │ Payments    │  ...  │
│  │ Users: 156  │ │ Collection  │ │ Due: ₹1.2L  │       │
│  └─────────────┘ └─────────────┘ └─────────────┘       │
├─────────────────────────────────────────────────────────┤
│  Recent Collections          │  Quick Actions          │
│  ├─ Rajesh: 12.5L Buffalo   │  ├─ Add Collection      │
│  ├─ Suresh: 8.2L Cow        │  ├─ Process Payments    │
│  └─ ...                      │  ├─ Supplements         │
│                              │  └─ Cattle Market       │
├─────────────────────────────────────────────────────────┤
│  Current Milk Pricing                                   │
│  ₹85/L  │  90% Farmer  │  6% Admin  │  4% Company     │
└─────────────────────────────────────────────────────────┘
```

### 6.5 Admin Restrictions
| Cannot Do | Reason |
|-----------|--------|
| View unverified users | Security policy |
| Edit user's Mobile/Email/Aadhaar/PAN | Immutable identity data |
| Add milk records for unverified users | RLS policy enforcement |
| Access user-only routes | Route protection |
| View other admins' data | Data isolation |

---

## 7. User Module

### 7.1 Overview
The User (Farmer) module allows farmers to view their milk records, track payments, manage cattle listings, and maintain their profile.

### 7.2 User Pages
| Page | Path | Description |
|------|------|-------------|
| Dashboard | `/user/dashboard` | Overview of recent activity |
| Profile | `/user/profile` | View/edit profile & verification status |
| Milk Records | `/user/milk-records` | View collection history |
| Payments | `/user/payments` | Track payment history |
| Cattle | `/user/cattle` | Manage cattle listings |
| Bank Details | `/user/bank-details` | Add/update bank account |

### 7.3 User Dashboard Features
```
┌─────────────────────────────────────────────────────────┐
│                    User Dashboard                        │
├─────────────────────────────────────────────────────────┤
│  Welcome, Farmer Name!                                  │
│  Current Milk Price: ₹85/L                              │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐       │
│  │ This Month  │ │ Total       │ │ Pending     │  ...  │
│  │ Milk: 450L  │ │ Earnings    │ │ Payment     │       │
│  └─────────────┘ └─────────────┘ └─────────────┘       │
├─────────────────────────────────────────────────────────┤
│  Recent Milk Records         │  Quick Actions          │
│  ├─ Jan 28: 12.5L (₹956)    │  ├─ View All Records    │
│  ├─ Jan 27: 10.2L (₹780)    │  ├─ Payment History     │
│  └─ ...                      │  ├─ My Cattle          │
│                              │  └─ Update Bank        │
└─────────────────────────────────────────────────────────┘
```

### 7.4 Verification Status Display
```
┌─────────────────────────────────────────┐
│  Verification Status                     │
├─────────────────────────────────────────┤
│  ✅ Mobile Verified                      │
│  ✅ Email Verified                       │
│  ⏳ Aadhaar Pending                      │
│  ⏳ PAN Pending                          │
├─────────────────────────────────────────┤
│  Status: PENDING VERIFICATION            │
│  Complete verification to enable milk    │
│  collection by admin                     │
└─────────────────────────────────────────┘
```

### 7.5 User Restrictions
| Cannot Do | Reason |
|-----------|--------|
| Access admin routes | Route protection |
| View other users' data | RLS policies |
| Modify milk records | Admin-only action |
| Update milk prices | Admin-only setting |

---

## 8. Milk Collection & Pricing Module

### 8.1 Overview
The core module for recording daily milk collection with quality parameters and automatic payment calculation.

### 8.2 Milk Entry Parameters
| Parameter | Type | Range/Format | Description |
|-----------|------|--------------|-------------|
| Farmer | Select | Verified users only | Target farmer |
| Milk Type | Enum | Cow / Buffalo | Source animal |
| Weight | Number | > 0 liters | Quantity collected |
| Fat % | Number | 0-100% | Fat content |
| SNF % | Number | 0-100% | Solid-Not-Fat content |
| Water Qty | Number | ≥ 0 | Water content detected |

### 8.3 Milk Collection Flow
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Select     │────>│  Enter      │────>│  Calculate  │
│  Farmer     │     │  Parameters │     │  Amounts    │
│             │     │             │     │             │
│ (Verified   │     │ - Type      │     │ Total =     │
│  only)      │     │ - Weight    │     │ Weight ×    │
│             │     │ - Fat %     │     │ Price/L     │
│             │     │ - SNF %     │     │             │
│             │     │ - Water     │     │ User: 90%   │
│             │     │             │     │ Admin: 6%   │
│             │     │             │     │ Company: 4% │
└─────────────┘     └─────────────┘     └─────────────┘
                                               │
                                               ▼
                                        ┌─────────────┐
                                        │  Save       │
                                        │  Record     │
                                        │             │
                                        │ milk_records│
                                        │ + payments  │
                                        └─────────────┘
```

### 8.4 Calculation Logic
```typescript
const calculatePayouts = (weight: number, pricePerLiter: number) => {
  const totalAmount = weight * pricePerLiter;
  
  return {
    totalAmount: totalAmount,
    userPayout: totalAmount * 0.90,    // 90% to farmer
    adminCut: totalAmount * 0.06,       // 6% to admin
    companyCut: totalAmount * 0.04      // 4% to company
  };
};
```

### 8.5 Pricing Configuration
| Setting | Value | Editable By |
|---------|-------|-------------|
| Price Range | ₹80 - ₹90 per liter | Admin only |
| Farmer Payout | 90% | Fixed |
| Admin Cut | 6% | Fixed |
| Company Cut | 4% | Fixed |

---

## 9. Payment Distribution Module

### 9.1 Overview
Manages the tracking and processing of payments to farmers based on milk collection records.

### 9.2 Payment Types
| Type | Description | Trigger |
|------|-------------|---------|
| milk_payment | Payment for milk collection | Automatic on milk record |
| supplement_deduction | Deduction for paid supplements | Admin action |
| advance | Advance payment to farmer | Admin action |

### 9.3 Payment Status Flow
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Pending    │────>│  Processing │────>│  Completed  │
│             │     │             │     │             │
│ Created on  │     │ Admin       │     │ Payment     │
│ milk record │     │ initiates   │     │ transferred │
└─────────────┘     └─────────────┘     └─────────────┘
```

### 9.4 Payment Calculation Example
```
Milk Record:
├── Weight: 10 liters
├── Price: ₹85/liter
├── Total: ₹850

Payment Distribution:
├── Farmer: ₹850 × 90% = ₹765
├── Admin: ₹850 × 6% = ₹51
└── Company: ₹850 × 4% = ₹34
```

---

## 10. Cattle Marketplace Module

### 10.1 Overview
A buy/sell marketplace for farmers to list their cattle for sale.

### 10.2 Listing Parameters
| Field | Required | Description |
|-------|----------|-------------|
| Photo | No | Cattle image |
| Cattle Type | Yes | Cow/Buffalo/etc. |
| Age (Years) | Yes | Age in years |
| Age (Months) | No | Additional months |
| Number of Calves | No | Calving history |
| Medical Records | No | Health history |
| Address | Yes | Location |
| Price | Yes | Asking price |
| Description | No | Additional details |

### 10.3 Access Control
| Role | Permissions |
|------|-------------|
| User | Create, view, edit, delete OWN listings |
| Admin | View ALL listings (read-only) |

### 10.4 Listing States
```
┌─────────────┐     ┌─────────────┐
│  Available  │────>│    Sold     │
│             │     │             │
│ Listed for  │     │ Marked as   │
│ sale        │     │ sold        │
└─────────────┘     └─────────────┘
```

---

## 11. Supplements Distribution Module

### 11.1 Overview
Tracks the distribution of cattle supplements (feed, medicine, etc.) to farmers by admins.

### 11.2 Supplement Record Fields
| Field | Required | Description |
|-------|----------|-------------|
| Farmer | Yes | Recipient farmer |
| Supplement Name | Yes | Name of supplement |
| Quantity | Yes | Amount distributed |
| Unit | Yes | kg/bags/liters/etc. |
| Is Free | Yes | Free or paid |
| Price | Conditional | Price if not free |
| Distribution Date | Yes | Date of distribution |

### 11.3 Distribution Types
| Type | Description | Billing |
|------|-------------|---------|
| Free | Government scheme or promotional | No charge |
| Paid | Regular purchase | Deducted from payments |

---

## 12. Security & Access Control

### 12.1 Row Level Security (RLS) Policies

#### 12.1.1 Profiles Table
| Policy | Command | Condition |
|--------|---------|-----------|
| Users can view own profile | SELECT | `auth.uid() = id` |
| Users can insert own profile | INSERT | `auth.uid() = id` |
| Users can update own profile | UPDATE | `auth.uid() = id` |
| Admins can view verified users | SELECT | `has_role('admin') AND is_user_verified(id)` |

#### 12.1.2 Milk Records Table
| Policy | Command | Condition |
|--------|---------|-----------|
| Users can view own records | SELECT | `auth.uid() = user_id` |
| Admins can view all records | SELECT | `has_role('admin')` |
| Admins can insert for verified users | INSERT | `has_role('admin') AND is_user_verified(user_id)` |

#### 12.1.3 Payments Table
| Policy | Command | Condition |
|--------|---------|-----------|
| Users can view own payments | SELECT | `auth.uid() = user_id` |
| Admins can view all payments | SELECT | `has_role('admin')` |
| Admins can manage payments | ALL | `has_role('admin')` |

### 12.2 Database Functions

#### 12.2.1 `has_role`
```sql
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$
```

#### 12.2.2 `is_user_verified`
```sql
CREATE OR REPLACE FUNCTION public.is_user_verified(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = _user_id
      AND mobile_verified = TRUE
      AND email_verified = TRUE
      AND aadhaar_verified = TRUE
      AND pan_verified = TRUE
  )
$$
```

### 12.3 Route Protection
```typescript
function ProtectedRoute({ children, allowedRole }) {
  const { user, role, loading } = useAuth();
  
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/login" />;
  if (role !== allowedRole) {
    return <Navigate to={role === 'admin' ? '/admin/dashboard' : '/user/dashboard'} />;
  }
  
  return children;
}
```

---

## 13. File Structure

```
dairy-pro/
├── docs/
│   └── PROJECT_DOCUMENTATION.md    # This file
├── public/
│   ├── favicon.ico
│   ├── placeholder.svg
│   └── robots.txt
├── src/
│   ├── assets/
│   │   └── hero-dairy.jpg          # Hero image
│   ├── components/
│   │   ├── layout/
│   │   │   ├── AdminSidebar.tsx    # Admin navigation
│   │   │   ├── DashboardLayout.tsx # Dashboard wrapper
│   │   │   ├── Footer.tsx          # Landing page footer
│   │   │   ├── Navbar.tsx          # Landing page navbar
│   │   │   └── UserSidebar.tsx     # User navigation
│   │   └── ui/                     # Shadcn UI components
│   │       ├── button.tsx
│   │       ├── card.tsx
│   │       ├── input.tsx
│   │       └── ...
│   ├── contexts/
│   │   └── AuthContext.tsx         # Authentication state
│   ├── hooks/
│   │   ├── use-mobile.tsx          # Mobile detection
│   │   └── use-toast.ts            # Toast notifications
│   ├── integrations/
│   │   └── supabase/
│   │       ├── client.ts           # Supabase client
│   │       └── types.ts            # Database types
│   ├── lib/
│   │   └── utils.ts                # Utility functions
│   ├── pages/
│   │   ├── admin/
│   │   │   ├── Cattle.tsx          # Cattle marketplace
│   │   │   ├── CompleteProfile.tsx # Profile completion
│   │   │   ├── Dashboard.tsx       # Admin dashboard
│   │   │   ├── MilkCollection.tsx  # Milk entry
│   │   │   ├── Payments.tsx        # Payment management
│   │   │   ├── Settings.tsx        # Pricing & bank
│   │   │   ├── Supplements.tsx     # Supplement distribution
│   │   │   └── UserManagement.tsx  # User management
│   │   ├── auth/
│   │   │   ├── Login.tsx           # Login page
│   │   │   └── Signup.tsx          # Registration
│   │   ├── user/
│   │   │   ├── BankDetails.tsx     # Bank account
│   │   │   ├── Cattle.tsx          # Cattle listings
│   │   │   ├── Dashboard.tsx       # User dashboard
│   │   │   ├── MilkRecords.tsx     # Milk history
│   │   │   ├── Payments.tsx        # Payment history
│   │   │   └── Profile.tsx         # User profile
│   │   ├── Index.tsx               # Redirect
│   │   ├── Landing.tsx             # Public landing
│   │   └── NotFound.tsx            # 404 page
│   ├── types/
│   │   └── index.ts                # TypeScript interfaces
│   ├── App.tsx                     # App router
│   ├── App.css                     # Global styles
│   ├── index.css                   # Tailwind base
│   ├── main.tsx                    # Entry point
│   └── vite-env.d.ts               # Vite types
├── supabase/
│   ├── config.toml                 # Supabase config
│   └── migrations/                 # SQL migrations
├── .env                            # Environment variables
├── index.html                      # HTML template
├── package.json                    # Dependencies
├── tailwind.config.ts              # Tailwind config
├── tsconfig.json                   # TypeScript config
└── vite.config.ts                  # Vite config
```

---

## 14. API Reference

### 14.1 Supabase Client Usage

#### 14.1.1 Authentication
```typescript
import { supabase } from "@/integrations/supabase/client";

// Sign up
const { error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'password123',
  options: {
    data: { full_name: 'John Doe', mobile_number: '9876543210' }
  }
});

// Sign in
const { error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'password123'
});

// Sign out
await supabase.auth.signOut();

// Get current session
const { data: { session } } = await supabase.auth.getSession();
```

#### 14.1.2 Database Operations
```typescript
// Fetch records
const { data, error } = await supabase
  .from('milk_records')
  .select('*')
  .eq('user_id', userId)
  .order('record_date', { ascending: false });

// Insert record
const { data, error } = await supabase
  .from('milk_records')
  .insert({
    user_id: farmerId,
    admin_id: adminId,
    milk_type: 'cow',
    weight_liters: 10.5,
    fat_percentage: 4.2,
    snf_percentage: 8.5,
    water_quantity: 0,
    price_per_liter: 85,
    total_amount: 892.50,
    user_payout: 803.25,
    admin_cut: 53.55,
    company_cut: 35.70
  });

// Update record
const { error } = await supabase
  .from('profiles')
  .update({ mobile_verified: true })
  .eq('id', userId);
```

### 14.2 TypeScript Interfaces
```typescript
// User types
type UserRole = 'admin' | 'user';
type VerificationStatus = 'pending' | 'verified';
type MilkType = 'cow' | 'buffalo';
type StartupPlan = 'basic' | 'advanced';

// Profile interface
interface Profile {
  id: string;
  full_name: string;
  mobile_number: string;
  email: string;
  aadhaar_number?: string;
  pan_number?: string;
  address?: string;
  mobile_verified: boolean;
  email_verified: boolean;
  aadhaar_verified: boolean;
  pan_verified: boolean;
  profile_completed: boolean;
  startup_plan?: StartupPlan;
  payment_completed: boolean;
  created_at: string;
  updated_at: string;
}

// Milk record interface
interface MilkRecord {
  id: string;
  user_id: string;
  admin_id?: string;
  milk_type: MilkType;
  weight_liters: number;
  fat_percentage: number;
  snf_percentage: number;
  water_quantity: number;
  price_per_liter: number;
  total_amount: number;
  user_payout: number;
  admin_cut: number;
  company_cut: number;
  record_date: string;
  created_at: string;
}
```

---

## Appendix

### A. Environment Variables
```env
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGci...
VITE_SUPABASE_PROJECT_ID=xxx
```

### B. Demo Credentials
| Field | Value |
|-------|-------|
| OTP Code | 123456 |

### C. Color Palette
| Token | HSL Value | Usage |
|-------|-----------|-------|
| --primary | 142 76% 36% | Dairy Green |
| --secondary | 43 74% 94% | Dairy Cream |
| --dairy-gold | 43 96% 56% | Accents |
| --dairy-earth | 24 38% 42% | Brown tones |
| --dairy-sky | 199 89% 48% | Blue accents |

---

*Document Version: 1.0*  
*Last Updated: February 2026*  
*Project: Dairy Pro - Village Dairy Management System*
