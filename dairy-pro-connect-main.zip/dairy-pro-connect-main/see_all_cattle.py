import os
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

load_dotenv()
db_url = os.getenv('DATABASE_URL')

# Support the hostaddr fix
connect_args = {}
if db_url and "hostaddr=" in db_url:
    import urllib.parse
    params = urllib.parse.parse_qs(urllib.parse.urlparse(db_url).query)
    if 'hostaddr' in params:
        connect_args['hostaddr'] = params['hostaddr'][0]

try:
    engine = create_engine(db_url, connect_args=connect_args)
    with engine.connect() as conn:
        print("\n--- 🐄 Cattle Market Data (Direct from DB) ---")
        result = conn.execute(text('SELECT id, type, price, location, age FROM cattle_listing'))
        rows = result.fetchall()
        
        if not rows:
            print("⚠️ Database is empty. Cattle tables exist but no entries yet.")
        else:
            print(f"{'ID':<5} | {'Type':<15} | {'Price':<10} | {'Location':<15} | {'Age':<5}")
            print("-" * 60)
            for row in rows:
                print(f"{row.id:<5} | {row.type:<15} | {row.price:<10} | {row.location:<15} | {row.age:<5}")
    
    print("\n✅ Database is working perfectly! Neon UI ka glitch temporary hai.")

except Exception as e:
    print(f"\n❌ Error finding data: {e}")
    print("\n💡 Tip: Try running the app first. Tables are created automatically when the app starts.")
