import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Vercel deployment trigger - landing page fix
createRoot(document.getElementById("root")!).render(<App />);
