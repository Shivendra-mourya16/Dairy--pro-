import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { persistQueryClient } from "@tanstack/query-persist-client-core";
import { createSyncStoragePersister } from "@tanstack/query-sync-storage-persister";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { SystemStatus } from "@/components/SystemStatus";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { OfflineBanner } from "@/components/OfflineBanner";
import ScrollToHash from "@/components/ScrollToHash";

// Pages
import Landing from "./pages/Landing";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import NotFound from "./pages/NotFound";

// Admin Pages
import AdminDashboard from "./pages/admin/Dashboard";
import CompleteProfile from "./pages/admin/CompleteProfile";
import UserManagement from "./pages/admin/UserManagement";
import MilkCollection from "./pages/admin/MilkCollection";
import AdminPayments from "./pages/admin/Payments";
import Supplements from "./pages/admin/Supplements";
import AdminCattle from "./pages/admin/Cattle";
import AdminSettings from "./pages/admin/Settings";
import AdminDonations from "./pages/admin/Donations";
import AdminPosts from "./pages/admin/Posts";

// User Pages
import UserDashboard from "./pages/user/Dashboard";
import UserProfile from "./pages/user/Profile";
import UserMilkRecords from "./pages/user/MilkRecords";
import UserPayments from "./pages/user/Payments";
import UserCattle from "./pages/user/Cattle";
import UserBankDetails from "./pages/user/BankDetails";
import UserSupplements from "./pages/user/Supplements";

// ─── Persistent QueryClient Setup ────────────────────────────────────────────
// Data stays in localStorage so it's available offline on reload
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Show cached data immediately, refetch in background when online
      staleTime: 1000 * 60 * 5,           // 5 minutes — data stays "fresh"
      gcTime: 1000 * 60 * 60 * 24 * 7,   // 7 days  — keep in cache/localStorage
      retry: (failureCount, error: unknown) => {
        // Don't retry if offline, retry up to 2 times otherwise
        if (!navigator.onLine) return false;
        return failureCount < 2;
      },
    },
  },
});

// Persist all query data to localStorage
const localStoragePersister = createSyncStoragePersister({
  storage: window.localStorage,
  key: "dairy-pro-cache",
});

persistQueryClient({
  queryClient,
  persister: localStoragePersister,
  maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
});
// ─────────────────────────────────────────────────────────────────────────────

function ProtectedRoute({ children, allowedRole }: { children: React.ReactNode; allowedRole: 'admin' | 'user' }) {
  const { user, role, loading } = useAuth();

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (role && role !== allowedRole) return <Navigate to={role === 'admin' ? '/admin/dashboard' : '/user/dashboard'} replace />;

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />

      {/* Admin Routes */}
      <Route path="/admin/complete-profile" element={<CompleteProfile />} />
      <Route path="/admin/dashboard" element={<ProtectedRoute allowedRole="admin"><AdminDashboard /></ProtectedRoute>} />
      <Route path="/admin/posts" element={<ProtectedRoute allowedRole="admin"><AdminPosts /></ProtectedRoute>} />
      <Route path="/admin/users" element={<ProtectedRoute allowedRole="admin"><UserManagement /></ProtectedRoute>} />
      <Route path="/admin/milk-collection" element={<ProtectedRoute allowedRole="admin"><MilkCollection /></ProtectedRoute>} />
      <Route path="/admin/payments" element={<ProtectedRoute allowedRole="admin"><AdminPayments /></ProtectedRoute>} />
      <Route path="/admin/supplements" element={<ProtectedRoute allowedRole="admin"><Supplements /></ProtectedRoute>} />
      <Route path="/admin/cattle" element={<ProtectedRoute allowedRole="admin"><AdminCattle /></ProtectedRoute>} />
      <Route path="/admin/settings" element={<ProtectedRoute allowedRole="admin"><AdminSettings /></ProtectedRoute>} />
      <Route path="/admin/donations" element={<ProtectedRoute allowedRole="admin"><AdminDonations /></ProtectedRoute>} />

      {/* User Routes */}
      <Route path="/user/dashboard" element={<ProtectedRoute allowedRole="user"><UserDashboard /></ProtectedRoute>} />
      <Route path="/user/profile" element={<ProtectedRoute allowedRole="user"><UserProfile /></ProtectedRoute>} />
      <Route path="/user/milk-records" element={<ProtectedRoute allowedRole="user"><UserMilkRecords /></ProtectedRoute>} />
      <Route path="/user/payments" element={<ProtectedRoute allowedRole="user"><UserPayments /></ProtectedRoute>} />
      <Route path="/user/cattle" element={<ProtectedRoute allowedRole="user"><UserCattle /></ProtectedRoute>} />
      <Route path="/user/supplements" element={<ProtectedRoute allowedRole="user"><UserSupplements /></ProtectedRoute>} />
      <Route path="/user/bank-details" element={<ProtectedRoute allowedRole="user"><UserBankDetails /></ProtectedRoute>} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      {/* Offline / Reconnected status banner */}
      <OfflineBanner />
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToHash />
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>

      <SystemStatus />
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
