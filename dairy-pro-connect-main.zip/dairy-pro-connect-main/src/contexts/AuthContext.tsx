import React, { createContext, useContext, useEffect, useState } from 'react';
import { Profile, UserRole } from '@/types';
import { API_BASE, safeFetch } from '@/lib/api';

const API_URL = `${API_BASE}/api`;


interface User {
  id: string;
  email?: string;
  full_name?: string;
  role?: string;
  mobile?: string;
  address?: string;
  is_verified?: boolean;
  admin_id?: number;
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  role: UserRole | null;
  loading: boolean;
  signUp: (email: string, password: string, metadata: Record<string, string>, role?: UserRole) => Promise<{ error: any }>;
  verifyOTP: (email: string, otp: string) => Promise<{ error: any; role?: UserRole }>;
  signIn: (email: string, password: string, role?: UserRole) => Promise<{ error: any; role?: UserRole }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('dairy_pro_user');
    if (savedUser) {
      const data = JSON.parse(savedUser);
      setUser(data.user);
      setRole(data.user.role);
      // For simplicity, we create a profile from user data
      setProfile({
        id: data.user.id,
        full_name: data.user.full_name,
        email: data.user.email,
        mobile: data.user.mobile,
        mobile_number: data.user.mobile,
        address: data.user.address,
        mobile_verified: true,
        email_verified: true,
        aadhaar_verified: true,
        pan_verified: true,
      } as any);
    }
    setLoading(false);
  }, []);

  const signUp = async (email: string, password: string, metadata: Record<string, string>, role: UserRole = 'user') => {
    try {
      const res = await safeFetch(`${API_URL}/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          full_name: metadata.full_name,
          mobile: metadata.mobile_number,
          admin_id: metadata.admin_id,
          role
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      return { error: null };
    } catch (err: any) {
      return { error: err.message };
    }
  };

  const verifyOTP = async (email: string, otp: string) => {
    try {
      const res = await safeFetch(`${API_URL}/auth/verify-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);

      const authData = { user: data.user };
      setUser(authData.user);
      setRole(data.user.role);
      localStorage.setItem('dairy_pro_user', JSON.stringify(authData));

      return { error: null, role: data.user.role as UserRole };
    } catch (err: any) {
      return { error: err.message };
    }
  };

  const signIn = async (email: string, password: string, role?: UserRole) => {
    try {
      const res = await safeFetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);

      const authData = { user: data.user };
      setUser(authData.user);
      setRole(data.user.role);
      localStorage.setItem('dairy_pro_user', JSON.stringify(authData));

      return { error: null, role: data.user.role };
    } catch (err: any) {
      return { error: err.message };
    }
  };

  const signOut = async () => {
    setUser(null);
    setRole(null);
    setProfile(null);
    localStorage.removeItem('dairy_pro_user');
  };

  const refreshProfile = async () => {
    if (!user?.id) return;
    try {
      const endpoint = role === 'admin' ? `${API_URL}/admins` : `${API_URL}/user/profile/${user.id}`;
      const res = await safeFetch(endpoint);
      if (res.ok) {
        let profileData;
        if (role === 'admin') {
           const admins = await res.json();
           profileData = admins.find((a: any) => a.id === user.id) || user;
        } else {
           profileData = await res.json();
        }
        
        const newUserData = { 
          ...user, 
          ...profileData, 
          mobile: profileData.mobile || profileData.mobile_number 
        };
        setUser(newUserData);
        setProfile({
          ...profileData,
          mobile_number: newUserData.mobile,
          aadhaar_verified: !!profileData.aadhaar,
          pan_verified: !!profileData.pan,
          email_verified: profileData.is_verified ?? true
        } as any);
        
        localStorage.setItem('dairy_pro_user', JSON.stringify({ user: newUserData }));
      }
    } catch (err) {
      console.error("Failed to refresh profile locally", err);
    }
  };

  return (
    <AuthContext.Provider value={{
      user, profile, role, loading,
      signUp, verifyOTP, signIn, signOut, refreshProfile
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
