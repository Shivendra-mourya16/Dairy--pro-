import { MapPin, Users, Truck, Milk } from 'lucide-react';

interface GrowthSummaryProps {
  importCount: number;
  locationCount: number;
  distributorCount: number;
  routeCount: number;
}

export function GrowthSummary({ importCount, locationCount, distributorCount, routeCount }: GrowthSummaryProps) {
  const cards = [
    { 
      title: 'Import', 
      value: importCount, 
      icon: Milk, 
      color: 'text-blue-500', 
      bg: 'bg-blue-50/50', 
      iconBg: 'bg-blue-100/50',
      description: 'Total Liters'
    },
    { 
      title: 'Location', 
      value: locationCount, 
      icon: MapPin, 
      color: 'text-rose-500', 
      bg: 'bg-rose-50/50', 
      iconBg: 'bg-rose-100/50',
      description: 'Active Points'
    },
    { 
      title: 'Distributor', 
      value: distributorCount, 
      icon: Users, 
      color: 'text-sky-500', 
      bg: 'bg-sky-50/50', 
      iconBg: 'bg-sky-100/50',
      description: 'Verified Partners'
    },
    { 
      title: 'Location', 
      value: routeCount, 
      icon: Truck, 
      color: 'text-indigo-500', 
      bg: 'bg-indigo-50/50', 
      iconBg: 'bg-indigo-100/50',
      description: 'Delivery Routes'
    },
  ];

  return (
    <div className="bg-white/50 backdrop-blur-md rounded-3xl p-6 border border-white/20 shadow-xl">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-800">Growth Summary</h3>
        <select className="bg-transparent text-sm text-gray-500 border-none focus:ring-0 cursor-pointer">
          <option>Last Month</option>
          <option>Today</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {cards.map((card, index) => (
          <div 
            key={index} 
            className={`${card.bg} rounded-2xl p-4 transition-all duration-300 hover:scale-[1.03] hover:shadow-lg border border-white/40 group`}
          >
            <div className="flex flex-col gap-2">
              <div className={`${card.iconBg} w-10 h-10 rounded-xl flex items-center justify-center mb-1 group-hover:rotate-6 transition-transform`}>
                <card.icon size={20} className={card.color} />
              </div>
              <div>
                <p className="text-2xl font-black text-gray-800">{card.value.toLocaleString()}</p>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-tighter">{card.title}</p>
              </div>
            </div>
            <p className="text-[10px] text-gray-400/80 mt-2 font-medium">{card.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
