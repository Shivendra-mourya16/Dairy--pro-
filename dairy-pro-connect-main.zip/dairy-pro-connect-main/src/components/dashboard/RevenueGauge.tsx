interface RevenueGaugeProps {
  current: number;
  target: number;
}

export function RevenueGauge({ current, target }: RevenueGaugeProps) {
  const percentage = Math.min(Math.round((current / target) * 100), 100);
  const radius = 80;
  const circumference = Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="bg-white/50 backdrop-blur-md rounded-3xl p-6 border border-white/20 shadow-xl flex flex-col items-center justify-center">
      <div className="w-full flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-gray-800">Revenue</h3>
        <p className="text-xs font-bold text-gray-400 uppercase">Aug 2018</p>
      </div>

      <div className="relative flex flex-col items-center">
        <svg width="200" height="120" viewBox="0 0 200 120" className="rotate-0">
          {/* Background Track */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#f3f4f6"
            strokeWidth="12"
            strokeLinecap="round"
          />
          {/* Progress Path */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="url(#gauge-gradient)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000 ease-out"
          />
          {/* Gradient Definition */}
          <defs>
            <linearGradient id="gauge-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" />
              <stop offset="50%" stopColor="#8b5cf6" />
              <stop offset="100%" stopColor="#ec4899" />
            </linearGradient>
          </defs>
        </svg>

        {/* Center Text */}
        <div className="absolute top-12 flex flex-col items-center">
          <p className="text-3xl font-black text-gray-800">₹{current.toLocaleString()}</p>
          <p className="text-xs font-bold text-gray-400 mt-1">₹{target.toLocaleString()}K</p>
        </div>

        {/* Pointer/Indicator */}
        <div 
          className="absolute bottom-5 w-4 h-4 bg-white border-2 border-gray-800 rounded-full shadow-md transition-all duration-1000 ease-out"
          style={{ 
            left: `calc(${percentage}% - 8px)`,
            transform: 'translateY(50%)'
          }}
        />
      </div>

      <div className="mt-4 w-full bg-gray-100 h-2 rounded-full overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 transition-all duration-1000 ease-out"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
