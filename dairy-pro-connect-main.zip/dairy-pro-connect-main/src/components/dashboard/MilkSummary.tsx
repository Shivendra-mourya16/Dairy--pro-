import { Milk } from 'lucide-react';

interface MilkSummaryProps {
  importLiters: number;
  distributionLiters: number;
}

export function MilkSummary({ importLiters, distributionLiters }: MilkSummaryProps) {
  const total = importLiters + distributionLiters;
  const importPercent = total > 0 ? Math.round((importLiters / (importLiters + distributionLiters)) * 100) : 0;
  const distributionPercent = total > 0 ? Math.round((distributionLiters / (importLiters + distributionLiters)) * 100) : 0;

  return (
    <div className="bg-white/50 backdrop-blur-md rounded-3xl p-6 border border-white/20 shadow-xl">
      <div className="flex justify-between items-center mb-8">
        <h3 className="text-xl font-bold text-gray-800">Milk Summary</h3>
        <select className="bg-transparent text-sm text-gray-500 border-none focus:ring-0 cursor-pointer">
          <option>Last Month</option>
          <option>Last Week</option>
          <option>Today</option>
        </select>
      </div>

      <div className="relative flex justify-around items-end h-64 gap-8">
        {/* Import Bottle */}
        <div className="flex flex-col items-center gap-4 group">
          <div className="relative w-24 h-48 bg-gray-100 rounded-b-3xl rounded-t-xl border-2 border-gray-200 overflow-hidden shadow-inner">
            <div 
              className="absolute bottom-0 w-full bg-gradient-to-t from-blue-400 to-blue-300 transition-all duration-1000 ease-out"
              style={{ height: `${importPercent}%` }}
            >
              <div className="absolute top-0 w-full h-2 bg-white/20 animate-pulse" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center opacity-10 group-hover:opacity-20 transition-opacity">
              <Milk size={48} className="text-gray-400" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-blue-500">{importPercent}%</p>
            <p className="text-sm font-medium text-gray-600">{importLiters.toLocaleString()} L</p>
            <p className="text-xs uppercase tracking-wider text-gray-400 font-bold mt-1">Import</p>
          </div>
        </div>

        {/* Distribution Bottle */}
        <div className="flex flex-col items-center gap-4 group">
          <div className="relative w-24 h-48 bg-gray-100 rounded-b-3xl rounded-t-xl border-2 border-gray-200 overflow-hidden shadow-inner">
            <div 
              className="absolute bottom-0 w-full bg-gradient-to-t from-yellow-400 to-yellow-300 transition-all duration-1000 ease-out"
              style={{ height: `${distributionPercent}%` }}
            >
              <div className="absolute top-0 w-full h-2 bg-white/20 animate-pulse" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center opacity-10 group-hover:opacity-20 transition-opacity">
              <Milk size={48} className="text-gray-400" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-yellow-500">{distributionPercent}%</p>
            <p className="text-sm font-medium text-gray-600">{distributionLiters.toLocaleString()} L</p>
            <p className="text-xs uppercase tracking-wider text-gray-400 font-bold mt-1">Distribution</p>
          </div>
        </div>

        {/* Connecting Line (Optional Decoration) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-[12px] border-gray-100 rounded-full -z-10" />
      </div>
    </div>
  );
}
