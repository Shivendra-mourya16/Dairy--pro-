import { useState, useEffect } from 'react';
import { API_BASE } from '@/lib/api';
import { Database, Server, RefreshCw, CheckCircle2, XCircle } from 'lucide-react';

export function SystemStatus() {
    const [status, setStatus] = useState<{
        backend: 'checking' | 'online' | 'offline';
        database: 'checking' | 'online' | 'offline';
        tables: string[];
    }>({
        backend: 'checking',
        database: 'checking',
        tables: [],
    });

    const checkStatus = async () => {
        setStatus(prev => ({ ...prev, backend: 'checking', database: 'checking' }));
        try {
            // 1. Check Backend
            console.log('[Status] Checking Backend:', `${API_BASE}/api/health`);
            const backendRes = await fetch(`${API_BASE}/api/health`, { cache: 'no-store' });

            if (backendRes.ok) {
                setStatus(prev => ({ ...prev, backend: 'online' }));

                // 2. Check Database only if Backend is up
                try {
                    console.log('[Status] Checking Database:', `${API_BASE}/api/db-check`);
                    const dbRes = await fetch(`${API_BASE}/api/db-check`, { cache: 'no-store' });
                    const dbData = await dbRes.json();

                    if (dbRes.ok && dbData.status === 'connected') {
                        setStatus(prev => ({
                            ...prev,
                            database: 'online',
                            tables: dbData.tables_found || []
                        }));
                    } else {
                        console.warn('[Status] Database not connected:', dbData.message);
                        setStatus(prev => ({ ...prev, database: 'offline' }));
                    }
                } catch (dbErr) {
                    console.error('[Status] Database fetch error');
                    setStatus(prev => ({ ...prev, database: 'offline' }));
                }
            } else {
                console.error('[Status] Backend unreachable (Non-OK response)');
                setStatus(prev => ({ ...prev, backend: 'offline', database: 'offline' }));
            }
        } catch (err: any) {
            console.error('[Status] Backend check failed:', err.message);
            setStatus({ backend: 'offline', database: 'offline', tables: [] });
        }
    };

    useEffect(() => {
        checkStatus();
        const interval = setInterval(checkStatus, 30000); // Check every 30s
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="fixed hidden md:flex bottom-4 right-4 z-[9999] flex-col gap-2 max-w-[calc(100vw-32px)]">
            <div className="bg-background/80 backdrop-blur-md border border-border p-3 rounded-xl shadow-2xl flex flex-col gap-2 min-w-[200px]">
                <div className="flex items-center justify-between border-b pb-2 mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">System Health</span>
                    <button onClick={checkStatus} className="hover:rotate-180 transition-transform duration-500">
                        <RefreshCw className="h-3 w-3 text-muted-foreground" />
                    </button>
                </div>
                <div className="text-[8px] text-muted-foreground truncate mb-1">
                    URL: {API_BASE || 'Relative (Vercel)'}
                </div>

                <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                        <Server className="h-3.5 w-3.5" />
                        <span>Backend</span>
                    </div>
                    {status.backend === 'online' ? (
                        <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                    ) : status.backend === 'checking' ? (
                        <span className="h-2 w-2 rounded-full bg-dairy-gold animate-pulse" />
                    ) : (
                        <XCircle className="h-3.5 w-3.5 text-destructive" />
                    )}
                </div>

                <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                        <Database className="h-3.5 w-3.5" />
                        <span>Database</span>
                    </div>
                    {status.database === 'online' ? (
                        <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                    ) : status.database === 'checking' ? (
                        <span className="h-2 w-2 rounded-full bg-dairy-gold animate-pulse" />
                    ) : (
                        <XCircle className="h-3.5 w-3.5 text-destructive" />
                    )}
                </div>

                {status.tables.length > 0 && (
                    <div className="pt-2 border-t flex flex-wrap gap-1">
                        <span className="text-[8px] text-muted-foreground w-full">Ready Tables: {status.tables.length}</span>
                    </div>
                )}
            </div>
        </div>
    );
}
