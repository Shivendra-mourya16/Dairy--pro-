import { ReactNode, useState } from 'react';
import { AdminSidebar } from './AdminSidebar';
import { UserSidebar } from './UserSidebar';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DashboardLayoutProps {
  children: ReactNode;
  role: 'admin' | 'user';
}

export function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b bg-background sticky top-0 z-30 shadow-sm">
        <span className="font-display font-bold text-lg text-primary">Dairy Pro</span>
        <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
          {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity" 
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <div className={`fixed inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out md:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        {role === 'admin' ? <AdminSidebar onClose={() => setSidebarOpen(false)} /> : <UserSidebar onClose={() => setSidebarOpen(false)} />}
      </div>

      <main className="md:ml-64 p-4 sm:p-6 flex-1 min-w-0 overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
