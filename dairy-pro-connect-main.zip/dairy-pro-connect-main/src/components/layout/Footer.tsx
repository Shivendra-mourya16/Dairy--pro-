import { Link } from 'react-router-dom';
import { Milk, Mail, Phone, MapPin } from 'lucide-react';

import logoImg from '@/assets/logo-pro.png';

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img src={logoImg} alt="Dairy Pro Logo" className="h-12 w-auto object-contain brightness-0 invert" />
            </Link>
            <p className="text-background/70 mb-4 max-w-md">
              Empowering village dairy farmers with transparent milk collection systems.
              Fair pricing, accurate measurements, and timely payments.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-background/70">
              <li>
                <Link to="/#benefits" className="hover:text-background transition-colors">
                  Benefits
                </Link>
              </li>
              <li>
                <Link to="/#about" className="hover:text-background transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/#support" className="hover:text-background transition-colors">
                  Support
                </Link>
              </li>
              <li>
                <Link to="/#donate" className="hover:text-background transition-colors">
                  Donate
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3 text-background/70">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+91 83690 98778</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>ayush.v.singh2611@gmail.com</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-1" />
                <span>Village Dairy Cooperative, Maharashtra, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 mt-8 pt-8 text-center text-background/50">
          <p>&copy; {new Date().getFullYear()} Dairy Pro. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
