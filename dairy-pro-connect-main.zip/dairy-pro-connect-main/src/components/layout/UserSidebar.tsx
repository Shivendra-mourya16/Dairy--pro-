import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Milk, User, ClipboardList, Banknote, Settings, 
  LogOut, PiggyBank, LayoutDashboard, CreditCard, Package, Globe
} from 'lucide-react';
import logoImg from '@/assets/logo-pro.png';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/user/dashboard' },
  { icon: User, label: 'My Profile', path: '/user/profile' },
  { icon: ClipboardList, label: 'Milk Records', path: '/user/milk-records' },
  { icon: Banknote, label: 'Payments', path: '/user/payments' },
  { icon: PiggyBank, label: 'Cattle Market', path: '/user/cattle' },
  { icon: Package, label: 'Supplements', path: '/user/supplements' },
  { icon: CreditCard, label: 'Bank Details', path: '/user/bank-details' },
];

export function UserSidebar({ onClose }: { onClose?: () => void }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, profile } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleLanguageChange = (lang: string) => {
    const gtSelect = document.querySelector('.goog-te-combo') as HTMLSelectElement;
    if (gtSelect) {
      gtSelect.value = lang;
      gtSelect.dispatchEvent(new Event('change'));
    }
  };

  const isVerified = profile?.mobile_verified && profile?.email_verified && 
                     profile?.aadhaar_verified && profile?.pan_verified;

  return (
    <aside className="h-screen w-64 bg-sidebar flex flex-col shadow-xl md:shadow-none border-r border-sidebar-border">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border hidden md:block">
        <Link to="/user/dashboard" className="flex items-center gap-3">
          <div className="p-1 rounded-lg bg-white/10 overflow-hidden">
            <img src={logoImg} alt="Dairy Pro" className="h-8 w-8 object-contain" />
          </div>
          <div>
            <span className="text-lg font-display font-bold text-sidebar-foreground">Dairy Pro</span>
            <span className="block text-xs text-sidebar-foreground/60">Farmer Portal</span>
          </div>
        </Link>
      </div>

      {/* Mobile Title */}
      <div className="p-4 border-b border-sidebar-border md:hidden bg-sidebar-primary text-sidebar-primary-foreground">
        <span className="font-bold">Farmer Navigation</span>
      </div>

      {/* Verification Status */}
      {!isVerified && (
        <div className="mx-4 mt-4 p-3 rounded-lg bg-dairy-gold/20 border border-dairy-gold/30">
          <p className="text-xs text-dairy-gold font-medium">⚠️ Verification Pending</p>
          <p className="text-xs text-sidebar-foreground/60 mt-1">Complete verification to access all features</p>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                isActive 
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground' 
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User Section */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-10 h-10 rounded-full bg-sidebar-accent flex items-center justify-center">
            <span className="text-lg font-semibold text-sidebar-foreground">
              {profile?.full_name?.charAt(0) || 'U'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {profile?.full_name || 'User'}
            </p>
            <p className="text-xs text-sidebar-foreground/60">
              {isVerified ? '✓ Verified' : 'Pending Verification'}
            </p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors mb-2">
              <Globe className="h-5 w-5" />
              <span>Language</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={() => handleLanguageChange('en')}>English</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleLanguageChange('hi')}>हिंदी (Hindi)</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleLanguageChange('mr')}>मराठी (Marathi)</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <button
          onClick={handleSignOut}
          className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-sidebar-foreground/70 hover:bg-destructive/20 hover:text-destructive transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
