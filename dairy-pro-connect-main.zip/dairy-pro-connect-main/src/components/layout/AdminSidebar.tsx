import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Milk, Users, ClipboardList, Banknote, Settings, 
  LogOut, Package, PiggyBank, LayoutDashboard, Globe, Newspaper, Heart
} from 'lucide-react';
import logoImg from '@/assets/logo-pro.png';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
  { icon: Newspaper, label: 'Posts & Updates', path: '/admin/posts' },
  { icon: Users, label: 'User Management', path: '/admin/users' },
  { icon: ClipboardList, label: 'Milk Collection', path: '/admin/milk-collection' },
  { icon: Banknote, label: 'Payments', path: '/admin/payments' },
  { icon: Package, label: 'Supplements', path: '/admin/supplements' },
  { icon: PiggyBank, label: 'Cattle Market', path: '/admin/cattle' },
  { icon: Heart, label: 'Donations', path: '/admin/donations' },
  { icon: Settings, label: 'Settings', path: '/admin/settings' },
];

export function AdminSidebar({ onClose }: { onClose?: () => void }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut, profile } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleLanguageChange = (lang: string) => {
    const gtSelect = document.querySelector('.goog-te-combo') as HTMLSelectElement;
    if (gtSelect) {
      gtSelect.value = lang;
      gtSelect.dispatchEvent(new Event('change'));
    }
  };

  return (
    <aside className="h-screen w-64 bg-sidebar flex flex-col shadow-xl md:shadow-none border-r border-sidebar-border">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border hidden md:block">
        <Link to="/admin/dashboard" className="flex items-center gap-3">
          <div className="p-1 rounded-lg bg-white/10 overflow-hidden">
            <img src={logoImg} alt="Dairy Pro" className="h-8 w-8 object-contain" />
          </div>
          <div>
            <span className="text-lg font-display font-bold text-sidebar-foreground">Dairy Pro</span>
            <span className="block text-xs text-sidebar-foreground/60">Admin Panel</span>
          </div>
        </Link>
      </div>
      
      {/* Mobile Title */}
      <div className="p-4 border-b border-sidebar-border md:hidden bg-sidebar-primary text-sidebar-primary-foreground">
        <span className="font-bold">Admin Navigation</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                isActive 
                  ? 'bg-sidebar-accent text-sidebar-accent-foreground' 
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* User Section */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-10 h-10 rounded-full bg-sidebar-accent flex items-center justify-center">
            <span className="text-lg font-semibold text-sidebar-foreground">
              {profile?.full_name?.charAt(0) || 'A'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {profile?.full_name || 'Admin'}
            </p>
            <p className="text-xs text-sidebar-foreground/60">Administrator</p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors mb-2">
              <Globe className="h-5 w-5" />
              <span>Language</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem onClick={() => handleLanguageChange('en')}>English</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleLanguageChange('hi')}>हिंदी (Hindi)</DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleLanguageChange('mr')}>मराठी (Marathi)</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <button
          onClick={handleSignOut}
          className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-sidebar-foreground/70 hover:bg-destructive/20 hover:text-destructive transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
