import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, FileSpreadsheet, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';

export default function UserPayments() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [payments, setPayments] = useState<any[]>([]);

  useEffect(() => {
    if (user?.id) {
      fetchPayments();
    }
  }, [user]);

  const fetchPayments = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/user/${user.id}/records`);
      const data = await response.json();
      setPayments(data.payments || []);
    } catch (error) {
      console.error("Failed to fetch payments:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportExcel = () => {
    window.open(`${API_BASE}/api/export/milk-history?user_id=${user?.id}`, '_blank');
  };

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-display font-bold">Payment History</h1>
          <Button variant="outline" size="sm" onClick={handleExportExcel} disabled={loading}>
            <FileSpreadsheet className="h-4 w-4 mr-2 text-success" />
            Export Excel
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Card className="gradient-card">
            <CardHeader><CardTitle>Your Payments</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-3">
                {payments.map((p) => (
                  <div key={p.id} className="flex justify-between p-4 bg-secondary/50 rounded-lg">
                    <div>
                      <p className="font-medium">{p.date}</p>
                      <div className="flex gap-2 items-center mt-1">
                        <Badge className={p.status === 'completed' || p.status === 'paid' ? 'bg-success/10 text-success border-none' : 'bg-dairy-gold/10 text-dairy-gold border-none'}>
                          {p.status === 'completed' || p.status === 'paid' ? <CheckCircle className="h-3 w-3 mr-1" /> : <Clock className="h-3 w-3 mr-1" />}
                          {p.status}
                        </Badge>
                        <Badge variant="outline" className="text-[10px] uppercase">{p.type || 'Milk Payout'}</Badge>
                      </div>
                    </div>
                    <p className="font-semibold text-primary">₹{p.amount.toLocaleString()}</p>
                  </div>
                ))}
                {payments.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No payment history found.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
