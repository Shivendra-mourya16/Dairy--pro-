import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  PiggyBank, Plus, MapPin, History, Heart, CreditCard,
  Landmark, QrCode, Loader2, Phone, Info, CheckCircle2, XCircle, Upload
} from 'lucide-react';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader,
  DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { API_BASE, getImageUrl } from '@/lib/api';

export default function UserCattle() {
  const { profile, user } = useAuth();
  const [listings, setListings] = useState<any[]>([]);
  const [myListings, setMyListings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Dialog States
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isBuyDialogOpen, setIsBuyDialogOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isRecordsOpen, setIsRecordsOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Add Listing Form State
  const [newListing, setNewListing] = useState({
    type: '',
    age: '',
    price: '',
    calves: '',
    milkYield: '',
  });
  const [imageFile, setImageFile] = useState<File | null>(null);

  // Buy Dialog State
  const [selectedCattle, setSelectedCattle] = useState<any>(null);
  const [paymentMode, setPaymentMode] = useState('card');
  const [showSellerContact, setShowSellerContact] = useState(false);
  const [sellerPhone, setSellerPhone] = useState('');

  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/cattle/listings`);
      const data = await response.json();
      setListings(data);
    } catch (error) {
      console.error("Failed to fetch listings:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMyListings = async () => {
    if (!user?.id) return;
    try {
      const response = await fetch(`${API_BASE}/api/cattle/user/${user.id}`);
      const data = await response.json();
      setMyListings(data);
    } catch (error) {
      console.error("Failed to fetch my listings:", error);
    }
  };

  const bookingFee = selectedCattle ? (parseFloat(selectedCattle.price) * 0.1) : 0;

  const handleAddListing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;
    setActionLoading(true);

    try {
      const formData = new FormData();
      formData.append('seller_id', String(user.id));
      formData.append('type', newListing.type);
      formData.append('age', newListing.age);
      formData.append('price', newListing.price);
      formData.append('calves', newListing.calves);
      formData.append('milkYield', newListing.milkYield);
      formData.append('location', profile?.address || 'Registered Address');

      if (imageFile) {
        formData.append('image', imageFile);
      }

      const response = await fetch(`${API_BASE}/api/cattle/listings/add`, {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        toast.success('Cattle listed for sale successfully!');
        fetchListings();
        setIsAddDialogOpen(false);
        setNewListing({ type: '', age: '', price: '', calves: '', milkYield: '' });
        setImageFile(null);
      } else {
        toast.error('Failed to add listing');
      }
    } catch (error) {
      toast.error('Connection error');
    } finally {
      setActionLoading(false);
    }
  };

  const handleBookingPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCattle || !user?.id) return;
    setActionLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/cattle/book`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          listing_id: selectedCattle.id,
          buyer_id: user.id
        })
      });

      const result = await response.json();
      if (response.ok) {
        setSellerPhone(result.seller_phone);
        setShowSellerContact(true);
        toast.success('Booking confirmed! Contact details unlocked.');
        fetchListings();
      } else {
        toast.error(result.message || 'Failed to book cattle');
      }
    } catch (error) {
      toast.error('Connection error');
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Cattle Market</h1>
            <p className="text-muted-foreground">Buy and sell verified cattle within your community</p>
          </div>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={() => {
                fetchMyListings();
                setIsOrdersOpen(true);
              }}
            >
              <History className="h-4 w-4 mr-2" /> My Listings
            </Button>
            <Button onClick={() => setIsAddDialogOpen(true)} className="gradient-hero flex-1 sm:flex-none">
              <Plus className="h-4 w-4 mr-2" /> Add Listing
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {listings.map((c) => (
              <Card key={c.id} className="gradient-card border-border/50 overflow-hidden hover:shadow-dairy transition-all group">
                <div className="aspect-video bg-secondary/50 flex flex-col items-center justify-center relative overflow-hidden">
                  {c.image_url ? (
                    <img
                      src={getImageUrl(c.image_url) || ''}
                      alt={c.type}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    />
                  ) : (
                    <PiggyBank className="h-16 w-16 text-primary/20 group-hover:scale-110 transition-transform" />
                  )}
                  <Badge className="absolute top-2 right-2 gradient-hero border-none">{c.status?.toUpperCase() || 'FOR SALE'}</Badge>
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{c.type}</CardTitle>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                        <MapPin className="h-3 w-3" /> {c.address}
                      </div>
                    </div>
                    <p className="text-xl font-bold text-primary">₹{parseFloat(c.price).toLocaleString()}</p>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="bg-background/50 p-2 rounded border border-border/50">
                      <span className="text-muted-foreground block text-[10px] uppercase">Age</span>
                      <span className="font-semibold">{c.age}</span>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/50">
                      <span className="text-muted-foreground block text-[10px] uppercase">Milk Yield</span>
                      <span className="font-semibold">{c.milk_yield} L/day</span>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/50">
                      <span className="text-muted-foreground block text-[10px] uppercase">Calves</span>
                      <span className="font-semibold">{c.calves}</span>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/50">
                      <span className="text-muted-foreground block text-[10px] uppercase">Listed By</span>
                      <span className="font-semibold truncate">{c.owner}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {c.owner !== profile?.full_name && c.status === 'available' && (
                      <Button
                        className="flex-1 gradient-gold text-foreground font-bold"
                        onClick={() => {
                          setSelectedCattle(c);
                          setIsBuyDialogOpen(true);
                          setShowSellerContact(false);
                        }}
                      >
                        Buy Now
                      </Button>
                    )}
                    {(c.owner === profile?.full_name || c.status !== 'available') && (
                      <Button variant="outline" className="flex-1" disabled>
                        {c.owner === profile?.full_name ? 'Your Listing' : 'Sold/Booked'}
                      </Button>
                    )}
                    <Badge variant={c.status === 'available' ? 'default' : 'secondary'} className="h-10 px-4 flex items-center justify-center capitalize">
                      {c.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
            {listings.length === 0 && (
              <div className="col-span-full text-center py-12 text-muted-foreground">
                No cattle listed in the market currently.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Listing Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add Cattle for Sale</DialogTitle>
            <DialogDescription>
              List your cattle in the market. Your profile details will be pre-filled.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddListing} className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4 bg-secondary/30 p-4 rounded-lg border border-border">
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Seller Name</Label>
                <p className="font-medium text-sm">{profile?.full_name}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[10px] uppercase text-muted-foreground">Mobile Number</Label>
                <p className="font-medium text-sm">{profile?.mobile}</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Cattle Type</Label>
              <Select onValueChange={(v) => setNewListing({ ...newListing, type: v })} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Holstein Friesian">Holstein Friesian (Cow)</SelectItem>
                  <SelectItem value="Jersey">Jersey (Cow)</SelectItem>
                  <SelectItem value="Murrah Buffalo">Murrah Buffalo</SelectItem>
                  <SelectItem value="Sahiwal">Sahiwal (Cow)</SelectItem>
                  <SelectItem value="Gir">Gir (Cow)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Age (Years)</Label>
                <Input
                  type="text"
                  placeholder="e.g. 4 years"
                  required
                  onChange={(e) => setNewListing({ ...newListing, age: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>No. of Calves</Label>
                <Input
                  type="number"
                  placeholder="e.g. 2"
                  required
                  onChange={(e) => setNewListing({ ...newListing, calves: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Milk Yield (L/day)</Label>
                <Input
                  type="number"
                  placeholder="e.g. 15"
                  required
                  onChange={(e) => setNewListing({ ...newListing, milkYield: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Asking Price (₹)</Label>
                <Input
                  type="number"
                  placeholder="e.g. 80000"
                  required
                  onChange={(e) => setNewListing({ ...newListing, price: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Cattle Image</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  accept="image/*"
                  className="cursor-pointer"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setImageFile(e.target.files[0]);
                    }
                  }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground">Upload a clear photo of the cattle (Max 5MB)</p>
            </div>

            <Button type="submit" className="w-full gradient-hero" disabled={actionLoading}>
              {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'List for Sale'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Buy/Booking Dialog */}
      <Dialog open={isBuyDialogOpen} onOpenChange={setIsBuyDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{showSellerContact ? 'Booking Confirmed!' : 'Book Your Cattle'}</DialogTitle>
            <DialogDescription>
              {showSellerContact
                ? 'Contact the seller to arrange transport and final payment.'
                : 'Pay 10% booking fee to unlock seller contact details.'}
            </DialogDescription>
          </DialogHeader>

          {!showSellerContact ? (
            <form onSubmit={handleBookingPayment} className="space-y-6 py-4">
              <div className="p-4 bg-primary/5 rounded-lg border border-primary/10 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Price:</span>
                  <span className="font-bold text-lg">₹{parseFloat(selectedCattle?.price || 0).toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-primary/10">
                  <span className="font-medium">Booking Fee (10%):</span>
                  <span className="text-2xl font-bold text-primary">₹{bookingFee.toLocaleString()}</span>
                </div>
              </div>

              <div className="space-y-3">
                <Label>Select Payment Mode</Label>
                <RadioGroup value={paymentMode} onValueChange={setPaymentMode} className="grid grid-cols-3 gap-4">
                  <div>
                    <RadioGroupItem value="card" id="b-card" className="peer sr-only" />
                    <Label htmlFor="b-card" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                      <CreditCard className="mb-2 h-5 w-5" />
                      <span className="text-[10px] font-bold uppercase">Card</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="upi" id="b-upi" className="peer sr-only" />
                    <Label htmlFor="b-upi" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                      <Landmark className="mb-2 h-5 w-5" />
                      <span className="text-[10px] font-bold uppercase">UPI</span>
                    </Label>
                  </div>
                  <div>
                    <RadioGroupItem value="qr" id="b-qr" className="peer sr-only" />
                    <Label htmlFor="b-qr" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                      <QrCode className="mb-2 h-5 w-5" />
                      <span className="text-[10px] font-bold uppercase">QR</span>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {paymentMode === 'card' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-2 border p-4 rounded-lg bg-secondary/20">
                  <div className="space-y-2">
                    <Label>Card Number</Label>
                    <Input placeholder="0000 0000 0000 0000" maxLength={19} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Expiry Date</Label>
                      <Input placeholder="MM/YY" maxLength={5} />
                    </div>
                    <div className="space-y-2">
                      <Label>CVV</Label>
                      <Input placeholder="123" type="password" maxLength={3} />
                    </div>
                  </div>
                </div>
              )}

              {paymentMode === 'upi' && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-2 border p-4 rounded-lg bg-secondary/20">
                  <Label>UPI ID</Label>
                  <div className="relative">
                    <Input placeholder="username@upi" />
                    <Landmark className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-xs text-muted-foreground">Supported: Google Pay, PhonePe, Paytm, etc.</p>
                </div>
              )}

              {paymentMode === 'qr' && (
                <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg border-2 border-dashed border-primary/30 animate-in fade-in slide-in-from-top-2">
                  <div className="relative w-32 h-32 bg-white p-2 border-2 border-primary/10 rounded-xl mb-4 shadow-sm">
                    <div className="w-full h-full border-4 border-primary/20 rounded-lg flex items-center justify-center relative overflow-hidden">
                      <QrCode className="w-24 h-24 text-primary opacity-80" />
                      <div className="absolute top-0 left-0 w-full h-1 bg-primary/40 animate-scan shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
                    </div>
                  </div>
                  <p className="text-xs font-bold text-primary">Scan to Pay ₹{bookingFee.toLocaleString()}</p>
                </div>
              )}

              <Button type="submit" className="w-full gradient-hero" disabled={actionLoading}>
                {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : `Pay ₹${bookingFee.toLocaleString()} & Book`}
              </Button>
            </form>
          ) : (
            <div className="py-8 space-y-6 text-center animate-in zoom-in-95 duration-300">
              <div className="relative mx-auto w-20 h-20">
                <div className="absolute inset-0 bg-success/20 rounded-full animate-ping" />
                <div className="relative bg-success/10 p-5 rounded-full text-success">
                  <CheckCircle2 className="h-10 w-10" />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-black text-foreground">Seller Unlocked!</h3>
                <p className="text-muted-foreground">Please call the owner to finalize the deal.</p>
              </div>

              <div className="p-6 bg-secondary/50 rounded-xl border-2 border-dashed border-primary/30 space-y-4">
                <div className="space-y-1">
                  <Label className="text-[10px] uppercase text-muted-foreground">Seller Contact</Label>
                  <p className="text-3xl font-black tracking-widest text-primary">{sellerPhone}</p>
                </div>
                <Button className="w-full bg-success hover:bg-success/90 text-white font-bold h-12" asChild>
                  <a href={`tel:${sellerPhone}`}>
                    <Phone className="h-5 w-5 mr-2" /> Call Now
                  </a>
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      {/* My Listings Dialog */}
      <Dialog open={isOrdersOpen} onOpenChange={setIsOrdersOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>My Cattle Listings</DialogTitle>
            <DialogDescription>Track the status of your listings</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {myListings.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">You haven't listed any cattle yet.</div>
            ) : (
              myListings.map((item) => (
                <Card
                  key={item.id}
                  className={`flex flex-col gap-4 p-4 transition-all cursor-pointer ${selectedCattle?.id === item.id ? 'ring-2 ring-primary bg-secondary/20' : 'hover:bg-secondary/10'}`}
                  onClick={() => setSelectedCattle(selectedCattle?.id === item.id ? null : item)}
                >
                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="w-full sm:w-24 h-24 bg-secondary rounded-lg flex items-center justify-center overflow-hidden shrink-0">
                      {item.image_url ? (
                        <img src={getImageUrl(item.image_url) || ''} alt={item.type} className="w-full h-full object-cover" />
                      ) : (
                        <PiggyBank className="h-8 w-8 text-muted-foreground/30" />
                      )}
                    </div>
                    <div className="flex-1 text-center sm:text-left">
                      <h4 className="font-bold">{item.type}</h4>
                      <p className="text-sm text-muted-foreground">Price: ₹{item.price.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">Listed on: {item.created}</p>

                      {(item.status === 'booked' || item.status === 'sold') && (
                        <p className="text-[10px] text-primary mt-1 font-medium animate-pulse">
                          {selectedCattle?.id === item.id ? 'Click to collapse' : 'Click to view buyer details'}
                        </p>
                      )}
                    </div>
                    <div>
                      <Badge variant={item.status === 'available' ? 'default' : 'secondary'} className="capitalize">
                        {item.status}
                      </Badge>
                    </div>
                  </div>

                  {/* Buyer Details Section (Expandable) */}
                  {selectedCattle?.id === item.id && (item.status === 'booked' || item.status === 'sold') && (
                    <div className="mt-2 pt-4 border-t border-border/50 animate-in fade-in slide-in-from-top-2">
                      <h5 className="text-sm font-bold mb-2 flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        Buyer Details
                      </h5>
                      {item.buyer ? (
                        <>
                          <div className="bg-secondary/30 p-3 rounded-md text-sm grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <span className="text-muted-foreground text-xs block">Name</span>
                              <span className="font-medium">{item.buyer.name}</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground text-xs block">Mobile</span>
                              <span className="font-medium">{item.buyer.mobile}</span>
                            </div>
                            {item.buyer.address && (
                              <div className="col-span-full">
                                <span className="text-muted-foreground text-xs block">Address</span>
                                <span className="font-medium">{item.buyer.address}</span>
                              </div>
                            )}
                          </div>
                          <div className="mt-3 flex gap-2">
                            <Button size="sm" className="w-full bg-green-600 hover:bg-green-700" asChild>
                              <a href={`tel:${item.buyer.mobile}`}>
                                <Phone className="h-3 w-3 mr-2" /> Call Buyer
                              </a>
                            </Button>
                          </div>
                        </>
                      ) : (
                        <div className="p-3 bg-destructive/10 text-destructive rounded-md text-sm">
                          Buyer details unavailable for this listing.
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
