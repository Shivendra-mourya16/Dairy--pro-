import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Download, FileSpreadsheet, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';

export default function UserMilkRecords() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [presentRecords, setPresentRecords] = useState<any[]>([]);
  const [pastRecords, setPastRecords] = useState<any[]>([]);

  useEffect(() => {
    if (user?.id) {
      fetchRecords();
    }
  }, [user]);

  const fetchRecords = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/user/${user.id}/records`);
      const data = await response.json();

      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();

      const present = data.milk_records.filter((r: any) => {
        const d = new Date(r.date);
        return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      });

      const past = data.milk_records.filter((r: any) => {
        const d = new Date(r.date);
        return d.getMonth() !== currentMonth || d.getFullYear() !== currentYear;
      });

      setPresentRecords(present);
      setPastRecords(past);
    } catch (error) {
      console.error("Failed to fetch records:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleExportExcel = () => {
    window.open(`${API_BASE}/api/export/milk-history?user_id=${user?.id}`, '_blank');
  };

  const RecordList = ({ records }: { records: any[] }) => (
    <div className="space-y-3">
      {records.map((r) => (
        <div key={r.id} className="flex justify-between p-4 bg-secondary/50 rounded-lg flex-wrap sm:flex-nowrap gap-2">
          <div className="min-w-0 flex-1">
            <p className="font-medium truncate">{r.date}</p>
            <p className="text-sm text-muted-foreground truncate">{r.type} • {r.weight}L • {r.fat}% fat</p>
          </div>
          <p className="font-semibold text-primary flex-shrink-0">₹{r.amount.toFixed(2)}</p>
        </div>
      ))}
      {records.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          No records found for this period.
        </div>
      )}
    </div>
  );

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-display font-bold">Milk Records</h1>
          <Button variant="outline" size="sm" onClick={handleExportExcel} disabled={loading}>
            <FileSpreadsheet className="h-4 w-4 mr-2 text-success" />
            Export Excel
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <Card className="gradient-card">
            <CardHeader><CardTitle>Collection History</CardTitle></CardHeader>
            <CardContent>
              <Tabs defaultValue="present">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="present">Present Month</TabsTrigger>
                  <TabsTrigger value="past">Past Records</TabsTrigger>
                </TabsList>
                <TabsContent value="present"><RecordList records={presentRecords} /></TabsContent>
                <TabsContent value="past"><RecordList records={pastRecords} /></TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
