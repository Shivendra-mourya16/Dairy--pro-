import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, Gift, CreditCard, Clock, CheckCircle2, Info, Loader2, Landmark, QrCode } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { API_BASE } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

const availableSupplements = [
  { id: '1', name: 'Cattle Feed Premium', price: 1500, unit: '50kg Bag' },
  { id: '2', name: 'Mineral Mix', price: 450, unit: '5kg Pack' },
  { id: '3', name: 'Vitamin Supplement', price: 850, unit: '1L Bottle' },
];

export default function UserSupplements() {
  const { user } = useAuth();
  const [selectedSup, setSelectedSup] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [history, setHistory] = useState<any[]>([]);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentMode, setPaymentMode] = useState('card');

  useEffect(() => {
    if (user?.id) {
      fetchHistory();
    }
  }, [user]);

  const fetchHistory = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/user/supplements/${user.id}`);
      const data = await response.json();
      setHistory(data);
    } catch (error) {
      console.error("Failed to fetch history:", error);
    } finally {
      setHistoryLoading(false);
    }
  };

  const isFirstThisMonth = history.filter(h => {
    const d = new Date(h.date);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).length === 0;

  const handleApply = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedSup || !user?.id) return;

    // If it's a paid request and payment modal isn't open yet, open it
    if (!isFirstThisMonth && !isPaymentOpen) {
      setIsPaymentOpen(true);
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/user/supplements/request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          name: selectedSup.name,
          price: selectedSup.price,
          is_paid: !isFirstThisMonth,
          payment_mode: paymentMode
        })
      });

      const result = await response.json();
      if (response.ok) {
        toast.success(result.is_free ? 'Free supplement requested!' : 'Supplement requested and payment processed!');
        fetchHistory();
        setSelectedSup(null);
        setIsPaymentOpen(false);
      } else {
        toast.error(result.message || 'Failed to request supplement');
      }
    } catch (error) {
      toast.error('Connection error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-display font-bold">Cattle Supplements</h1>
          <p className="text-muted-foreground">Apply for monthly supplements and cattle feed</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 gradient-card">
            <CardHeader>
              <CardTitle>Request New Supplement</CardTitle>
              <CardDescription>Get one free supplement per month. Subsequent requests are paid.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                {availableSupplements.map((sup) => (
                  <div
                    key={sup.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${selectedSup?.id === sup.id ? 'border-primary bg-primary/5' : 'border-border bg-secondary/20'}`}
                    onClick={() => setSelectedSup(sup)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <Package className={`h-6 w-6 ${selectedSup?.id === sup.id ? 'text-primary' : 'text-muted-foreground'}`} />
                      <Badge variant="outline">{sup.unit}</Badge>
                    </div>
                    <p className="font-bold">{sup.name}</p>
                    <p className="text-sm text-primary font-semibold">₹{sup.price}</p>
                  </div>
                ))}
              </div>

              {selectedSup && (
                <div className="animate-in fade-in slide-in-from-top-2">
                  <Card className={isFirstThisMonth ? 'bg-success/5 border-success/20' : 'bg-dairy-gold/5 border-dairy-gold/20'}>
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-4">
                        {isFirstThisMonth ? (
                          <div className="p-3 bg-success/10 rounded-full text-success"><Gift className="h-6 w-6" /></div>
                        ) : (
                          <div className="p-3 bg-dairy-gold/10 rounded-full text-dairy-gold"><CreditCard className="h-6 w-6" /></div>
                        )}
                        <div className="flex-1">
                          <p className="font-bold text-lg">{isFirstThisMonth ? 'First Free Supplement!' : 'Paid Request'}</p>
                          <p className="text-sm text-muted-foreground">
                            {isFirstThisMonth
                              ? "You haven't used your free limit this month. This request will be free of cost."
                              : `You already used your free limit this month. This will cost ₹${selectedSup.price}.`}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-black text-primary">₹{isFirstThisMonth ? '0' : selectedSup.price}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <Button
                className="w-full gradient-hero h-12 text-lg font-bold"
                disabled={!selectedSup || loading}
                onClick={handleApply}
              >
                {loading ? <Loader2 className="h-5 w-5 animate-spin mx-auto" /> : (isFirstThisMonth ? 'Get Free Supplement' : 'Pay & Request Supplement')}
              </Button>
            </CardContent>
          </Card>

          <Card className="gradient-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Clock className="h-5 w-5" /> Recent Requests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {historyLoading ? (
                  <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
                ) : (
                  history.map((item) => (
                    <div key={item.id} className="p-3 rounded-lg bg-secondary/30 space-y-2 border border-border/50">
                      <div className="flex justify-between items-start">
                        <p className="font-medium text-sm">{item.name}</p>
                        {item.is_free && <Badge className="bg-success/10 text-success text-[10px] h-4">FREE</Badge>}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-muted-foreground">{item.date}</span>
                        <div className={`flex items-center gap-1 text-xs font-medium ${item.status === 'delivered' ? 'text-success' : 'text-dairy-gold'}`}>
                          {item.status === 'delivered' ? <CheckCircle2 className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                        </div>
                      </div>
                    </div>
                  ))
                )}
                {!historyLoading && history.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Info className="h-8 w-8 mx-auto mb-2 opacity-20" />
                    <p className="text-sm">No history yet</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Payment Dialog */}
      <Dialog open={isPaymentOpen} onOpenChange={setIsPaymentOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
            <DialogDescription>
              Complete the payment to request <strong>{selectedSup?.name}</strong>.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="p-4 bg-primary/5 rounded-lg border border-primary/10 space-y-2">
              <div className="flex justify-between items-center pt-2">
                <span className="font-medium text-muted-foreground">Amount to Pay:</span>
                <span className="text-2xl font-black text-primary">₹{selectedSup?.price}</span>
              </div>
            </div>

            <div className="space-y-3">
              <Label>Select Payment Mode</Label>
              <RadioGroup value={paymentMode} onValueChange={setPaymentMode} className="grid grid-cols-3 gap-4">
                <div>
                  <RadioGroupItem value="card" id="b-card" className="peer sr-only" />
                  <Label htmlFor="b-card" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <CreditCard className="mb-2 h-5 w-5" />
                    <span className="text-[10px] font-bold uppercase">Card</span>
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="upi" id="b-upi" className="peer sr-only" />
                  <Label htmlFor="b-upi" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <Landmark className="mb-2 h-5 w-5" />
                    <span className="text-[10px] font-bold uppercase">UPI</span>
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="qr" id="b-qr" className="peer sr-only" />
                  <Label htmlFor="b-qr" className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer">
                    <QrCode className="mb-2 h-5 w-5" />
                    <span className="text-[10px] font-bold uppercase">QR</span>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {paymentMode === 'card' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-top-2 border p-4 rounded-lg bg-secondary/20">
                <div className="space-y-2">
                  <Label>Card Number</Label>
                  <Input placeholder="0000 0000 0000 0000" maxLength={19} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Expiry Date</Label>
                    <Input placeholder="MM/YY" maxLength={5} />
                  </div>
                  <div className="space-y-2">
                    <Label>CVV</Label>
                    <Input placeholder="123" type="password" maxLength={3} />
                  </div>
                </div>
              </div>
            )}

            {paymentMode === 'upi' && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-2 border p-4 rounded-lg bg-secondary/20">
                <Label>UPI ID</Label>
                <div className="relative">
                  <Input placeholder="username@upi" />
                  <Landmark className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                </div>
                <p className="text-xs text-muted-foreground">Supported: Google Pay, PhonePe, Paytm, etc.</p>
              </div>
            )}

            {paymentMode === 'qr' && (
              <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg border-2 border-dashed border-primary/30 animate-in fade-in slide-in-from-top-2">
                <div className="relative w-32 h-32 bg-white p-2 border-2 border-primary/10 rounded-xl mb-4 shadow-sm">
                  <div className="w-full h-full border-4 border-primary/20 rounded-lg flex items-center justify-center relative overflow-hidden">
                    <QrCode className="w-24 h-24 text-primary opacity-80" />
                    <div className="absolute top-0 left-0 w-full h-1 bg-primary/40 animate-scan shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
                  </div>
                </div>
                <p className="text-xs font-bold text-primary">Scan to Pay ₹{selectedSup?.price}</p>
              </div>
            )}

            <Button onClick={() => handleApply()} className="w-full gradient-hero" disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : `Pay ₹${selectedSup?.price} & Request`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
