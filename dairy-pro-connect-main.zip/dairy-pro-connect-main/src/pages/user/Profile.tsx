import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { User, CheckCircle, Clock, Mail, Phone, MapPin, Shield, Edit2, Save, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { API_BASE, safeFetch } from '@/lib/api';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

export default function UserProfile() {
  const { user, profile, verifyOTP, refreshProfile } = useAuth();
  
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Form State
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [mobile, setMobile] = useState(profile?.mobile_number || '');
  const [email, setEmail] = useState(profile?.email || '');
  const [address, setAddress] = useState(profile?.address || '');

  // OTP Dialog State
  const [showOtpDialog, setShowOtpDialog] = useState(false);
  const [otp, setOtp] = useState('');
  const [otpLoading, setOtpLoading] = useState(false);
  const [newEmail, setNewEmail] = useState('');

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setMobile(profile.mobile_number || '');
      setEmail(profile.email || '');
      setAddress(profile.address || '');
    }
  }, [profile]);

  const handleSave = async () => {
    setLoading(true);
    try {
      const res = await safeFetch(`${API_BASE}/api/users/${user?.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          full_name: fullName,
          mobile: mobile,
          email: email,
          address: address
        }),
      });

      const data = await res.json();
      
      if (!res.ok) throw new Error(data.error || data.message || 'Failed to update profile');

      toast.success(data.message || 'Profile updated successfully!');
      setIsEditing(false);

      if (data.otp_sent) {
        setNewEmail(email);
        setShowOtpDialog(true);
      } else {
        await refreshProfile();
      }
    } catch (err: any) {
      toast.error(err.message || 'An error occurred while saving.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp || otp.length < 6) {
      toast.error('Please enter a valid OTP');
      return;
    }

    setOtpLoading(true);
    try {
      const res = await verifyOTP(newEmail, otp);
      if (res.error) throw new Error(res.error);
      
      toast.success('Email verified successfully!');
      setShowOtpDialog(false);
      await refreshProfile();
    } catch (err: any) {
      toast.error(err.message || 'Invalid OTP');
    } finally {
      setOtpLoading(false);
    }
  };

  const isVerified = (val?: boolean) => val ? <CheckCircle className="h-4 w-4 text-success" /> : <Clock className="h-4 w-4 text-dairy-gold" />;

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-display font-bold">My Profile</h1>
          {!isEditing ? (
            <Button variant="outline" onClick={() => setIsEditing(true)}>
              <Edit2 className="h-4 w-4 mr-2" /> Edit Profile
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={() => setIsEditing(false)} disabled={loading}>
                <X className="h-4 w-4 mr-2" /> Cancel
              </Button>
              <Button onClick={handleSave} className="gradient-hero" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />} 
                Save Changes
              </Button>
            </div>
          )}
        </div>
        
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="gradient-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><User className="h-5 w-5" />Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              
              {isEditing ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Full Name (Cannot be changed)</Label>
                    <Input value={fullName} disabled className="bg-muted" />
                  </div>
                  <div className="space-y-2">
                    <Label>Mobile Number</Label>
                    <Input value={mobile} onChange={(e) => setMobile(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Email Address</Label>
                    <Input value={email} onChange={(e) => setEmail(e.target.value)} />
                    <p className="text-xs text-muted-foreground">Changing your email will require OTP verification.</p>
                  </div>
                  <div className="space-y-2">
                    <Label>Home Address</Label>
                    <Input value={address} onChange={(e) => setAddress(e.target.value)} />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <User className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="font-medium">{profile?.full_name || user?.full_name || 'Not set'}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{profile?.mobile_number || 'Not set'}</span>
                    {isVerified(profile?.mobile_verified)}
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{profile?.email || user?.email || 'Not set'}</span>
                    {isVerified(profile?.email_verified ?? true)}
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span>{profile?.address || 'Not set'}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="gradient-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" />Document Verification</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between p-3 bg-secondary/50 rounded-lg items-center">
                <div>
                  <p className="font-medium">Aadhaar Card</p>
                  <p className="text-sm font-mono text-muted-foreground">{profile?.aadhaar || 'Not Provided'}</p>
                </div>
                <Badge className={profile?.aadhaar_verified ? 'bg-success/10 text-success' : 'bg-dairy-gold/10 text-dairy-gold'}>{profile?.aadhaar_verified ? 'Verified' : 'Pending'}</Badge>
              </div>
              <div className="flex justify-between p-3 bg-secondary/50 rounded-lg items-center">
                <div>
                  <p className="font-medium">PAN Card</p>
                  <p className="text-sm font-mono text-muted-foreground">{profile?.pan || 'Not Provided'}</p>
                </div>
                <Badge className={profile?.pan_verified ? 'bg-success/10 text-success' : 'bg-dairy-gold/10 text-dairy-gold'}>{profile?.pan_verified ? 'Verified' : 'Pending'}</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={showOtpDialog} onOpenChange={setShowOtpDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Verify New Email Server</DialogTitle>
            <DialogDescription>
              We've sent a 6-digit OTP to {newEmail}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>One-Time Password</Label>
              <Input 
                value={otp} 
                onChange={(e) => setOtp(e.target.value)} 
                placeholder="000000"
                maxLength={6}
                className="text-center tracking-widest text-2xl font-bold h-14"
              />
            </div>
            <Button className="w-full gradient-hero" onClick={handleVerifyOtp} disabled={otpLoading || otp.length !== 6}>
              {otpLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Verify Email Address
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
