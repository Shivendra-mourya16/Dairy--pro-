import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { Milk, Banknote, TrendingUp, Calendar, CheckCircle, Clock, AlertCircle, Package, Plus, Loader2, Newspaper } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { API_BASE } from '@/lib/api';

export default function UserDashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [recentRecords, setRecentRecords] = useState<any[]>([]);
  const [adminPosts, setAdminPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      const fetchPromises = [
        fetch(`${API_BASE}/api/user/stats/${user?.id}`),
        fetch(`${API_BASE}/api/user/${user?.id}/records`)
      ];
      
      if ((user as any).admin_id) {
        fetchPromises.push(fetch(`${API_BASE}/api/posts?admin_id=${(user as any).admin_id}`));
      } else {
        fetchPromises.push(Promise.resolve(new Response(JSON.stringify([]))));
      }

      const [statsRes, recordsRes, postsRes] = await Promise.all(fetchPromises);
      const statsData = await statsRes.json();
      const recordsData = await recordsRes.json();
      const postsData = await postsRes.json();

      setStats(statsData);
      setRecentRecords(recordsData.milk_records?.slice(0, 5) || []);
      setAdminPosts(Array.isArray(postsData) ? postsData : []);
    } catch (err) {
      console.error('Failed to fetch user dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout role="user">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  const isFullyVerified = user?.is_verified; // Using the basic verification flag

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Welcome, {user?.full_name || 'Farmer'}!</h1>
            <p className="text-muted-foreground">Here's your dairy farming overview</p>
          </div>
          <Link to="/user/supplements">
            <Button className="gradient-hero">
              <Plus className="h-4 w-4 mr-2" /> Request Supplement
            </Button>
          </Link>
        </div>

        {/* Verification Banner */}
        {!isFullyVerified && (
          <Card className="bg-dairy-gold/10 border-dairy-gold/30">
            <CardContent className="flex items-center gap-4 py-4">
              <AlertCircle className="h-6 w-6 text-dairy-gold shrink-0" />
              <div className="flex-1">
                <p className="font-medium">Verification Pending</p>
                <p className="text-sm text-muted-foreground">
                  Complete your verification to access all features and start milk collection
                </p>
              </div>
              <Link to="/user/profile">
                <Button variant="outline" size="sm">Complete Verification</Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="gradient-card hover:shadow-dairy transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Milk (L)
              </CardTitle>
              <Milk className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.total_milk?.toFixed(1) || 0} L</div>
              <p className="text-xs text-muted-foreground mt-1">Overall collection</p>
            </CardContent>
          </Card>
          <Card className="gradient-card hover:shadow-dairy transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pending Payout
              </CardTitle>
              <Banknote className="h-5 w-5 text-dairy-gold" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{stats?.pending_payout?.toLocaleString() || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">To be processed by admin</p>
            </CardContent>
          </Card>
          <Card className="gradient-card hover:shadow-dairy transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Avg. Fat %
              </CardTitle>
              <TrendingUp className="h-5 w-5 text-dairy-sky" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.avg_fat?.toFixed(1) || 0}%</div>
              <p className="text-xs text-muted-foreground mt-1">Quality average</p>
            </CardContent>
          </Card>
          <Card className="gradient-card hover:shadow-dairy transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Current Price
              </CardTitle>
              <Calendar className="h-5 w-5 text-dairy-sky" />
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <div className="flex justify-between items-center text-sm font-bold">
                  <span>Cow:</span>
                  <span className="text-primary">₹{stats?.cow_price || 45}/L</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold">
                  <span>Buffalo:</span>
                  <span className="text-primary">₹{stats?.buffalo_price || 65}/L</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Milk Records */}
          <Card className="gradient-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Milk className="h-5 w-5 text-primary" />
                  Recent Collections
                </CardTitle>
                <CardDescription>Your latest milk submissions</CardDescription>
              </div>
              <Link to="/user/milk-records">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentRecords.length === 0 ? (
                  <p className="text-center py-4 text-muted-foreground">No submissions found</p>
                ) : (
                  recentRecords.map((record) => (
                    <div key={record.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 flex-wrap sm:flex-nowrap gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{record.date}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {record.type} • {record.weight}L • {record.fat}% fat
                        </p>
                      </div>
                      <p className="font-semibold text-primary flex-shrink-0">₹{record.amount?.toFixed(2)}</p>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Supplement Quick Access */}
          <Card className="gradient-card">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  Supplement Status
                </CardTitle>
                <CardDescription>View your distributions</CardDescription>
              </div>
              <Link to="/user/supplements">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-success/5 border border-success/20">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-success/10 rounded-full text-success">
                    <CheckCircle className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-bold">Account Verified</p>
                    <p className="text-xs text-muted-foreground">
                      {isFullyVerified ? 'Your account is in good standing' : 'Complete your profile to get verified'}
                    </p>
                  </div>
                </div>
                {!isFullyVerified && (
                  <Link to="/user/profile">
                    <Button size="sm" className="gradient-hero">Verify</Button>
                  </Link>
                )}
              </div>

              <div className="p-3 text-center border border-dashed rounded-lg space-y-1">
                <p className="text-sm text-muted-foreground">
                  Cow Milk Price: <strong>₹{stats?.cow_price || 45}/L</strong>
                </p>
                <p className="text-sm text-muted-foreground">
                  Buffalo Milk Price: <strong>₹{stats?.buffalo_price || 65}/L</strong>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Updates Feed */}
        {adminPosts.length > 0 && (
          <Card className="gradient-card border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="h-5 w-5 text-primary" />
                Latest Updates from your Admin
              </CardTitle>
              <CardDescription>Important announcements and news for your center</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {adminPosts.map((post: any) => (
                  <div key={post.id} className="p-4 rounded-xl bg-secondary/30 border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                        {post.admin_name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{post.admin_name}</p>
                        <p className="text-xs text-muted-foreground">{post.created_at}</p>
                      </div>
                    </div>
                    {post.media_url && (
                      <div className="mb-3 rounded-lg overflow-hidden max-h-64 bg-black flex items-center justify-center">
                        {post.media_type === 'video' ? (
                          <video src={post.media_url.startsWith('http') ? post.media_url : `${API_BASE}${post.media_url}`} controls className="w-full h-full object-contain" />
                        ) : (
                          <img src={post.media_url.startsWith('http') ? post.media_url : `${API_BASE}${post.media_url}`} alt="Post" className="w-full max-h-64 object-contain" />
                        )}
                      </div>
                    )}
                    <p className="text-sm whitespace-pre-wrap">{post.content}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Verification Details */}
        <Card className="gradient-card">
          <CardHeader>
            <CardTitle>Account Status</CardTitle>
            <CardDescription>Overview of your account verification</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-3">
                {user?.is_verified ? (
                  <CheckCircle className="h-5 w-5 text-success" />
                ) : (
                  <Clock className="h-5 w-5 text-dairy-gold" />
                )}
                <span>Official Verification</span>
              </div>
              <Badge variant="outline" className={user?.is_verified ? 'bg-success/10 text-success' : 'bg-dairy-gold/10 text-dairy-gold'}>
                {user?.is_verified ? 'Verified' : 'Pending'}
              </Badge>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-success" />
                <span>Email: {user?.email}</span>
              </div>
              <Badge variant="outline" className="bg-success/10 text-success">Verified</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Price Info */}
        <Card className="gradient-card border-dairy-gold/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-dairy-gold" />
              Your Payment Share
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-lg bg-success/10 border border-success/30">
                <p className="text-3xl font-bold text-success">{stats?.farmer_share || 90}%</p>
                <p className="text-sm text-muted-foreground">Your Share</p>
                <p className="text-xs text-muted-foreground mt-1">of total milk value</p>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50">
                <p className="text-3xl font-bold text-dairy-earth">{stats?.admin_cut || 6}%</p>
                <p className="text-sm text-muted-foreground">Admin Fee</p>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50">
                <p className="text-3xl font-bold text-muted-foreground">{stats?.company_cut || 4}%</p>
                <p className="text-sm text-muted-foreground">Platform Fee</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
