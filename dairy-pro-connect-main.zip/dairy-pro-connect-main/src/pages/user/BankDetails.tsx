import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, Save, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';

export default function UserBankDetails() {
  const { user } = useAuth();
  const [bankName, setBankName] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchBankDetails();
    }
  }, [user]);

  const fetchBankDetails = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/bank-details/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        setBankName(data.bank_name || '');
        setAccountHolder(data.account_holder || '');
        setAccountNumber(data.account_number || '');
        setIfscCode(data.ifsc_code || '');
      }
    } catch (error) {
      console.error("Failed to fetch bank details:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user?.id) return;
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/bank-details/${user.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bank_name: bankName,
          account_holder: accountHolder,
          account_number: accountNumber,
          ifsc_code: ifscCode
        })
      });

      if (response.ok) {
        toast.success('Bank details saved successfully!');
      } else {
        toast.error('Failed to save bank details');
      }
    } catch (error) {
      toast.error('Connection error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout role="user">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="user">
      <div className="space-y-6">
        <h1 className="text-3xl font-display font-bold">Bank Details</h1>
        <Card className="gradient-card max-w-lg">
          <CardHeader><CardTitle className="flex items-center gap-2"><CreditCard className="h-5 w-5" />Your Bank Account</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>Bank Name</Label><Input placeholder="e.g., State Bank of India" value={bankName} onChange={(e) => setBankName(e.target.value)} /></div>
            <div><Label>Account Holder Name</Label><Input placeholder="As per bank records" value={accountHolder} onChange={(e) => setAccountHolder(e.target.value)} /></div>
            <div><Label>Account Number</Label><Input placeholder="Enter account number" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} /></div>
            <div><Label>IFSC Code</Label><Input placeholder="e.g., SBIN0001234" value={ifscCode} onChange={(e) => setIfscCode(e.target.value.toUpperCase())} /></div>
            <Button onClick={handleSave} className="w-full gradient-hero" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
              Save Bank Details
            </Button>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
