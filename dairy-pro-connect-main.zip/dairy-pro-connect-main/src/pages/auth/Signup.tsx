import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Milk, Loader2, Eye, EyeOff, CheckCircle, Phone, Mail, Shield, Building2 } from 'lucide-react';
import { toast } from 'sonner';
import { UserRole } from '@/types';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { API_BASE, safeFetch } from '@/lib/api';

type Step = 'details' | 'verify-mobile' | 'verify-email' | 'documents' | 'complete';

interface AdminSummary {
  id: number;
  full_name: string;
}

export default function Signup() {
  const navigate = useNavigate();
  const { signUp, verifyOTP } = useAuth();

  const [step, setStep] = useState<Step>('details');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Form data
  const [role, setRole] = useState<UserRole>('user');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [aadhaar, setAadhaar] = useState('');
  const [pan, setPan] = useState('');
  const [selectedAdminId, setSelectedAdminId] = useState<string>('');
  const [admins, setAdmins] = useState<AdminSummary[]>([]);

  // OTP
  const [mobileOtp, setMobileOtp] = useState('');
  const [emailOtp, setEmailOtp] = useState('');
  const [mobileVerified, setMobileVerified] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);

  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        const res = await safeFetch(`${API_BASE}/api/admins`);
        const data = await res.json();
        setAdmins(data);
      } catch (err: any) {
        toast.error(err.message || 'Failed to connect to server');
      }
    };
    fetchAdmins();
  }, []);

  const handleBasicDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (role === 'user' && !selectedAdminId) {
      toast.error('Please select an existing Admin/Dairy Center');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signUp(email, password, {
        full_name: fullName,
        mobile_number: mobile,
        admin_id: selectedAdminId,
      }, role);

      if (error) {
        toast.error(error);
        return;
      }

      toast.success('Account created! Verify your email OTP.');
      setStep('verify-email'); // Backend sends email OTP
    } catch (err) {
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyEmail = async () => {
    setLoading(true);
    const { error, role: verifiedRole } = await verifyOTP(email, emailOtp);
    setLoading(false);

    if (error) {
      toast.error(error);
    } else {
      setEmailVerified(true);
      toast.success('Email verified!');

      const userRole = verifiedRole || role;

      if (userRole === 'admin') {
        navigate('/admin/dashboard');
      } else {
        setStep('documents');
      }
    }
  };

  const handleDocuments = async () => {
    setLoading(true);
    try {
      const user = JSON.parse(localStorage.getItem('dairy_pro_user') || '{}');
      if (user && user.id) {
        await safeFetch(`${API_BASE}/api/users/${user.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ aadhaar, pan })
        });
      }
      toast.success('Documents submitted for verification!');
      setStep('complete');
    } catch (err) {
      toast.error('Failed to save documents');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyMobile = async () => {
    // Mobile OTP verification (demo — skipping to email step)
    setMobileVerified(true);
    setStep('verify-email');
  };

  const renderStep = () => {

    switch (step) {
      case 'details':
        return (
          <form onSubmit={handleBasicDetails}>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <Label>I am a</Label>
                <RadioGroup value={role} onValueChange={(v) => setRole(v as UserRole)} className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="user" id="user" />
                    <Label htmlFor="user" className="font-normal cursor-pointer">Farmer (User)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="admin" id="admin" />
                    <Label htmlFor="admin" className="font-normal cursor-pointer">Admin</Label>
                  </div>
                </RadioGroup>
              </div>

              {role === 'user' && (
                <div className="space-y-2">
                  <Label htmlFor="admin">Select Dairy Center (Admin) *</Label>
                  <Select value={selectedAdminId} onValueChange={setSelectedAdminId} required>
                    <SelectTrigger id="admin" className="w-full">
                      <SelectValue placeholder="Select an Admin" />
                    </SelectTrigger>
                    <SelectContent>
                      {admins.length > 0 ? (
                        admins.map((a) => (
                          <SelectItem key={a.id} value={a.id.toString()}>
                            {a.full_name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="none" disabled>No verified admins available</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Farmers must be linked to a dairy center to manage records.
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number</Label>
                <Input
                  id="mobile"
                  type="tel"
                  placeholder="+91 83690 98778"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Create a password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </CardContent>

            <CardFooter>
              <Button type="submit" className="w-full gradient-hero" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  'Continue'
                )}
              </Button>
            </CardFooter>
          </form>
        );

      case 'verify-mobile':
        return (
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-primary" />
              </div>
              <p className="text-muted-foreground">
                Enter the OTP sent to <br />
                <span className="font-medium text-foreground">{mobile}</span>
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                (Use 123456 for demo)
              </p>
            </div>

            <div className="flex justify-center">
              <InputOTP maxLength={6} value={mobileOtp} onChange={setMobileOtp}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <Button onClick={handleVerifyMobile} className="w-full gradient-hero">
              Verify Mobile
            </Button>
          </CardContent>
        );

      case 'verify-email':
        return (
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Mail className="h-8 w-8 text-primary" />
              </div>
              <p className="text-muted-foreground">
                Enter the OTP sent to <br />
                <span className="font-medium text-foreground">{email}</span>
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                (Check your spam folder if you don't see it)
              </p>
            </div>

            <div className="flex justify-center">
              <InputOTP maxLength={6} value={emailOtp} onChange={setEmailOtp}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <div className="space-y-3">
              <Button onClick={handleVerifyEmail} className="w-full gradient-hero" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Verify Email'}
              </Button>
              <div className="flex justify-between gap-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setStep('details')}
                >
                  Go Back
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={async () => {
                    setLoading(true);
                    try {
                      const res = await safeFetch(`${API_BASE}/api/auth/resend-otp`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email })
                      });
                      const data = await res.json();
                      if (res.ok) toast.success('OTP sent again!');
                      else toast.error(data.message);
                    } catch (err) {
                      toast.error('Failed to resend OTP');
                    } finally {
                      setLoading(false);
                    }
                  }}
                  disabled={loading}
                >
                  Resend OTP
                </Button>
              </div>
            </div>
          </CardContent>
        );

      case 'documents':
        return (
          <CardContent className="space-y-4">
            <div className="text-center mb-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <p className="text-muted-foreground">
                Enter your document details for verification
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="aadhaar">Aadhaar Number</Label>
              <Input
                id="aadhaar"
                placeholder="1234 5678 9012"
                value={aadhaar}
                onChange={(e) => setAadhaar(e.target.value)}
                maxLength={14}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pan">PAN Number</Label>
              <Input
                id="pan"
                placeholder="ABCDE1234F"
                value={pan}
                onChange={(e) => setPan(e.target.value.toUpperCase())}
                maxLength={10}
              />
            </div>

            <Button onClick={handleDocuments} className="w-full gradient-hero" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit for Verification'
              )}
            </Button>
          </CardContent>
        );

      case 'complete':
        return (
          <CardContent className="space-y-6 text-center">
            <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto">
              <CheckCircle className="h-10 w-10 text-success" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Registration Complete!</h3>
              <p className="text-muted-foreground">
                {role === 'admin'
                  ? 'Please complete your profile to access the dashboard.'
                  : 'Your documents are being verified. You can access limited features until verification is complete.'}
              </p>
            </div>
            <Button
              onClick={() => navigate(role === 'admin' ? '/admin/complete-profile' : '/user/dashboard')}
              className="w-full gradient-hero"
            >
              {role === 'admin' ? 'Complete Profile' : 'Go to Dashboard'}
            </Button>
          </CardContent>
        );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-hero-pattern bg-background p-4">
      <Card className="w-full max-w-md gradient-card shadow-dairy animate-scale-in">
        <CardHeader className="text-center">
          <Link to="/" className="inline-flex items-center justify-center gap-2 mb-4">
            <div className="p-2 rounded-lg gradient-hero">
              <Milk className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-display font-bold">Dairy Pro</span>
          </Link>
          <CardTitle className="text-2xl">Create Account</CardTitle>
          <CardDescription>
            {step === 'details' && 'Join our transparent dairy network'}
            {step === 'verify-mobile' && 'Verify your mobile number'}
            {step === 'verify-email' && 'Verify your email address'}
            {step === 'documents' && 'Document verification'}
            {step === 'complete' && 'Welcome to Dairy Pro'}
          </CardDescription>
        </CardHeader>

        {renderStep()}

        {step === 'details' && (
          <div className="px-6 pb-6">
            <p className="text-sm text-muted-foreground text-center">
              Already have an account?{' '}
              <Link to="/login" className="text-primary hover:underline font-medium">
                Sign in
              </Link>
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
