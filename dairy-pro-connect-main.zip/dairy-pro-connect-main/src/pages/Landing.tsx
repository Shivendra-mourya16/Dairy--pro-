import { useState, useEffect } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Milk, Shield, TrendingUp, Users, CheckCircle2,
  Heart, Phone, Mail, Scale, Banknote, Leaf,
  QrCode, Landmark, Loader2, MapPin, ImagePlus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { API_BASE, safeFetch, getImageUrl } from '@/lib/api';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import heroImage from '@/assets/hero-dairy.jpg';
import logoImg from '@/assets/logo-pro.png';

const benefits = [
  // ... (keeping existing benefits)
];

const indianStates = [
  "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
  "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa",
  "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
  "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
  "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
];

export default function Landing() {
  const navigate = useNavigate();
  const [customAmount, setCustomAmount] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form State
  const [donorName, setDonorName] = useState('');
  const [donorPhone, setDonorPhone] = useState('');
  const [country, setCountry] = useState('India');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [paymentMode, setPaymentMode] = useState('upi');
  const [selectedAdminId, setSelectedAdminId] = useState('');
  const [donationMessage, setDonationMessage] = useState('');

  // Network State
  const [admins, setAdmins] = useState<any[]>([]);
  const [adminPosts, setAdminPosts] = useState<any[]>([]);
  const [contactData, setContactData] = useState({ name: '', email: '', message: '' });
  const [contactLoading, setContactLoading] = useState(false);

  useEffect(() => {
    const fetchNetworkInfo = async () => {
      try {
        const [adminsRes, postsRes] = await Promise.all([
          safeFetch('/api/admins'),
          safeFetch('/api/posts')
        ]);
        const aData = await adminsRes.json();
        const pData = await postsRes.json();
        setAdmins(aData || []);
        setAdminPosts(pData || []);
      } catch (err) {
        console.error("Failed to load about us data");
      }
    };
    fetchNetworkInfo();
  }, []);

  const handleDonateClick = () => {
    if (!customAmount || parseFloat(customAmount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    setIsDialogOpen(true);
  };

  const handleFinalPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAdminId) {
      toast.error('Please select a local dairy center (Admin)');
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/donate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          donor_name: donorName,
          donor_phone: donorPhone,
          amount: parseFloat(customAmount),
          admin_id: parseInt(selectedAdminId),
          message: donationMessage,
          payment_mode: paymentMode,
          location: `${city}, ${state}`
        })
      });

      if (!res.ok) throw new Error('Donation failed');

      setLoading(false);
      setIsDialogOpen(false);
      toast.success(`Thank you ${donorName}! Your donation of ₹${customAmount} was successful support for your chosen center.`);
      
      // Reset form
      setCustomAmount('');
      setDonorName('');
      setDonorPhone('');
      setSelectedAdminId('');
      setDonationMessage('');
    } catch (err: any) {
      setLoading(false);
      toast.error(err.message || 'Error recording donation');
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setContactLoading(true);
    // Mock contact submission
    setTimeout(() => {
      setContactLoading(false);
      toast.success("Thank you for reaching out! Our team will contact you soon.");
      setContactData({ name: '', email: '', message: '' });
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full bg-background overflow-x-hidden flex flex-col">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Dairy farm landscape"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/70 to-foreground/40" />
        </div>

        <div className="relative container mx-auto px-4 py-24 md:py-32">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-primary/20 text-primary-foreground/90 px-4 py-2 rounded-full mb-6 backdrop-blur-sm shadow-lg border border-primary/30 text-white font-bold">
              <img src={logoImg} alt="logo" className="h-5 w-auto" />
              <span className="text-sm font-medium">Village Dairy Management</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-6xl font-display font-bold text-background mb-6 leading-tight break-words">
              Empowering Farmers with <br className="hidden sm:block" />
              <span className="text-dairy-gold">Transparent</span> Dairy Solutions
            </h1>

            <p className="text-lg text-background/80 mb-8 max-w-xl">
              Dairy Pro brings fairness and transparency to village milk collection.
              Track your milk quality, monitor payments, and grow your dairy business with confidence.
            </p>

            <div className="flex flex-col sm:flex-row flex-wrap gap-4">
              <Button
                size="lg"
                className="gradient-gold text-foreground font-semibold shadow-gold w-full sm:w-auto"
                onClick={() => navigate('/signup')}
              >
                Get Started Free
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-background/10 border-background/30 text-background hover:bg-background/20 w-full sm:w-auto"
                onClick={() => navigate('/login')}
              >
                Login to Dashboard
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Stats Section */}
      <section className="py-12 bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { label: 'Villages Served', value: '500+', icon: MapPin },
              { label: 'Registered Farmers', value: '12,000+', icon: Users },
              { label: 'Liters Collected', value: '2.5M+', icon: Milk },
              { label: 'Total Payouts', value: '₹10Cr+', icon: Banknote },
            ].map((stat, i) => (
              <div key={i} className="text-center group">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                  <stat.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="text-2xl md:text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="text-xs md:text-sm text-muted-foreground uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Why Choose Dairy Pro?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform is designed with farmers in mind, bringing modern technology to traditional dairy practices.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Shield,
                title: 'Complete Transparency',
                description: 'Real-time tracking of milk quality, quantity, and payments. Every transaction is recorded and visible.',
              },
              {
                icon: Scale,
                title: 'Fair Measurement',
                description: 'Accurate digital weighing with fat and SNF analysis ensures you get paid for the true value of your milk.',
              },
              {
                icon: Banknote,
                title: 'Timely Payments',
                description: 'Automatic payment calculations with clear breakdown of rates, deductions, and net payouts.',
              },
              {
                icon: TrendingUp,
                title: 'Track Your Progress',
                description: 'Detailed records of past and present milk collections help you monitor and improve productivity.',
              },
              {
                icon: Leaf,
                title: 'Supplement Support',
                description: 'Access to quality cattle feed and supplements, with transparent distribution records.',
              },
              {
                icon: Users,
                title: 'Community Network',
                description: 'Connect with other farmers, buy and sell cattle, and grow together as a dairy community.',
              },
            ].map((benefit, index) => (
              <Card key={index} className="gradient-card border-border/50 hover:shadow-dairy transition-shadow duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg gradient-hero flex items-center justify-center mb-4">
                    <benefit.icon className="h-6 w-6 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {benefit.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Simple steps to join our transparent dairy network
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: '1', title: 'Sign Up', desc: 'Create your account with basic details and verification' },
              { step: '2', title: 'Get Verified', desc: 'Complete Aadhaar & PAN verification for full access' },
              { step: '3', title: 'Start Collecting', desc: 'Bring your milk for digital measurement and recording' },
              { step: '4', title: 'Get Paid', desc: 'Receive transparent payments based on quality' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-full gradient-hero flex items-center justify-center mx-auto mb-4 text-2xl font-bold text-primary-foreground">
                  {item.step}
                </div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-secondary/20 border-y border-border/50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground">Everything you need to know about Dairy Pro Connect</p>
          </div>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1" className="border-b border-border/50">
              <AccordionTrigger className="text-lg font-semibold hover:no-underline py-6">How is my milk price calculated?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-6">
                Pricing is dynamic based on Milk Type (Cow/Buffalo), Fat %, and SNF %. We use industry-standard benchmarks. 
                If your milk quality exceeds the standard, you receive a bonus. If it's below standard, a base price is guaranteed.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2" className="border-b border-border/50">
              <AccordionTrigger className="text-lg font-semibold hover:no-underline py-6">When do I receive my payments?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-6">
                Payments are processed instantly and recorded in your dashboard. Actual Bank transfers or cash payouts happen 
                on your center's specific billing cycle (usually weekly or fortnightly).
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3" className="border-b border-border/50">
              <AccordionTrigger className="text-lg font-semibold hover:no-underline py-6">How can I support a specific dairy center?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-6">
                Go to the "Donate" section, choose your amount, and select your local dairy center from the dropdown. 
                The funds go to the organization to support cattle care and center upgrades at that specific location.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-lg font-semibold hover:no-underline py-6">Is my data secure?</AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-6">
                Yes, we use industry-standard encryption and secure cloud infrastructure. Your personal records and 
                bank details are protected and only visible to authorized personnel.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Donation Section */}
      <section id="donate" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <Card className="max-w-3xl mx-auto gradient-card border-dairy-gold/30 shadow-gold">
            <CardHeader className="text-center">
              <div className="w-16 h-16 rounded-full bg-dairy-gold/20 flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-dairy-gold" />
              </div>
              <CardTitle className="text-2xl md:text-3xl">Support Local Cattle Farms</CardTitle>
              <CardDescription className="text-base">
                Your donation helps provide food, shelter, and medical care for cattle at local farms.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4 mb-6">
                {[500, 1000, 2500].map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    className={`h-16 text-lg font-semibold border-2 transition-all ${customAmount === amount.toString()
                      ? 'border-dairy-gold bg-dairy-gold/10'
                      : 'hover:border-dairy-gold/50'
                      }`}
                    onClick={() => setCustomAmount(amount.toString())}
                  >
                    ₹{amount.toLocaleString()}
                  </Button>
                ))}
              </div>
              <div className="flex gap-4">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold">₹</span>
                  <Input
                    placeholder="Enter custom amount"
                    className="pl-8"
                    type="number"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                  />
                </div>
                <Button
                  className="gradient-gold text-foreground font-semibold px-8"
                  onClick={handleDonateClick}
                >
                  Donate Now
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Donation Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Heart className="h-6 w-6 text-dairy-gold fill-dairy-gold" />
              Complete Your Donation
            </DialogTitle>
            <DialogDescription>
              Support local dairy farmers and their cattle.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleFinalPayment} className="space-y-6 py-4">
            <div className="p-4 bg-secondary/50 rounded-lg flex justify-between items-center border border-border">
              <span className="font-medium">Donation Amount</span>
              <span className="text-2xl font-bold text-primary">₹{customAmount}</span>
            </div>

            <div className="space-y-2">
              <Label>Select Your Local Dairy Center (Admin) *</Label>
              <Select value={selectedAdminId} onValueChange={setSelectedAdminId} required>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Choose an admin or center" />
                </SelectTrigger>
                <SelectContent>
                  {admins.map((admin) => (
                    <SelectItem key={admin.id} value={admin.id.toString()}>
                      {admin.full_name} ({admin.city || 'Unknown'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground">Admin helps manage local operations; donation reaches organization centrally.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  placeholder="Enter your name"
                  required
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  placeholder="Enter 10 digit number"
                  required
                  maxLength={10}
                  value={donorPhone}
                  onChange={(e) => setDonorPhone(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Location Details</Label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger>
                    <SelectValue placeholder="Country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="India">India</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={state} onValueChange={setState}>
                  <SelectTrigger>
                    <SelectValue placeholder="State" />
                  </SelectTrigger>
                  <SelectContent>
                    {indianStates.map((s) => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  placeholder="City/Village"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">Message for Farmers (Optional)</Label>
              <Textarea
                id="message"
                placeholder="Message of support..."
                value={donationMessage}
                onChange={(e) => setDonationMessage(e.target.value)}
                className="min-h-[60px]"
              />
            </div>

            <div className="space-y-3">
              <Label>Payment Mode</Label>
              <RadioGroup
                value={paymentMode}
                onValueChange={setPaymentMode}
                className="grid grid-cols-2 gap-4"
              >
                <div>
                  <RadioGroupItem value="upi" id="upi" className="peer sr-only" />
                  <Label
                    htmlFor="upi"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Landmark className="mb-3 h-6 w-6" />
                    UPI
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="qr" id="qr" className="peer sr-only" />
                  <Label
                    htmlFor="qr"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <QrCode className="mb-3 h-6 w-6" />
                    QR Code
                  </Label>
                </div>
              </RadioGroup>
            </div>


            {paymentMode === 'upi' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-top-2 border p-4 rounded-lg bg-secondary/20">
                <div className="space-y-2">
                  <Label htmlFor="upiId">Your UPI ID (Optional)</Label>
                  <div className="relative">
                    <Input id="upiId" placeholder="username@upi" value={donorPhone && !donorName.includes('@') ? '' : ''} onChange={() => {}} />
                    <Landmark className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-[10px] text-muted-foreground">Enter your VPA for our records (optional)</p>
                </div>
                
                <div className="pt-2">
                  <a 
                    href={`upi://pay?pa=ayush.v.singh26112005-1@okaxis&pn=Dairy%20Pro%20Connect&am=${customAmount}&cu=INR`}
                    className="w-full flex items-center justify-center gap-2 bg-[#673AB7] hover:bg-[#5E35B1] text-white py-3 rounded-lg font-bold transition-all shadow-md active:scale-95"
                  >
                    <Phone className="h-5 w-5" />
                    Pay with UPI App
                  </a>
                </div>
              </div>
            )}

            {paymentMode === 'qr' && (
              <div className="flex flex-col items-center justify-center p-6 bg-white rounded-lg border-2 border-dashed border-primary/30 animate-in fade-in slide-in-from-top-2">
                <div className="relative w-48 h-48 bg-white p-2 border-2 border-primary/10 rounded-xl mb-4 shadow-sm group">
                  <div className="w-full h-full rounded-lg flex items-center justify-center relative overflow-hidden">
                    <img 
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(`upi://pay?pa=ayush.v.singh26112005-1@okaxis&pn=Dairy%20Pro%20Connect&am=${customAmount}&cu=INR`)}`} 
                      alt="Payment QR"
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute top-0 left-0 w-full h-1 bg-primary/40 animate-scan shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-primary mb-1">Scan to Pay ₹{customAmount}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold">UPI ID: ayush.v.singh26112005-1@okaxis</p>
                </div>
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-12 text-lg font-bold gradient-gold text-foreground"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Processing...
                </>
              ) : (
                `Donate ₹${customAmount}`
              )}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* About Section */}
      <section id="about" className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-6">
                About Dairy Pro
              </h2>
              <p className="text-muted-foreground mb-4">
                Dairy Pro was founded with a simple mission: to bring fairness and transparency
                to village dairy farming. We understand the challenges faced by small-scale farmers
                and are committed to providing them with tools that ensure they receive fair value
                for their hard work.
              </p>
              <p className="text-muted-foreground mb-6">
                Our digital platform eliminates manual errors, prevents fraud, and creates a
                permanent record of all transactions. With Dairy Pro, every drop of milk is
                measured accurately, and every payment is calculated fairly.
              </p>
              <ul className="space-y-3">
                {[
                  'Founded by dairy farming families',
                  'Serving 500+ villages across India',
                  'Over ₹10 Crore paid to farmers',
                  '100% transparent operations',
                ].map((item, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden shadow-dairy">
                <img
                  src={heroImage}
                  alt="About Dairy Pro"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-xl shadow-lg">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="text-muted-foreground">Villages Served</div>
              </div>
            </div>
          </div>

          {/* Network Leads (Admins) */}
          {admins.length > 0 && (
            <div className="mt-24">
              <div className="text-center mb-12">
                <h3 className="text-3xl font-display font-bold mb-4">Our Network Leads</h3>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Meet the dedicated center admins managing our village networks and ensuring fair practices.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {admins.map((admin) => (
                  <Card key={admin.id} className="gradient-card overflow-hidden">
                    <div className="h-24 bg-primary/10"></div>
                    <div className="px-6 pb-6 relative">
                      <div className="w-20 h-20 rounded-full border-4 border-background bg-secondary absolute -top-10 left-6 overflow-hidden flex items-center justify-center">
                        {admin.photo_url ? (
                          <img src={getImageUrl(admin.photo_url) || ''} alt={admin.full_name} className="w-full h-full object-cover" />
                        ) : (
                          <Users className="h-8 w-8 text-muted-foreground" />
                        )}
                      </div>
                      <div className="pt-12">
                        <h4 className="text-xl font-bold">{admin.full_name}</h4>
                        <p className="text-xs text-primary font-medium mb-4 uppercase tracking-wider">Admin ID: DP-{admin.id.toString().padStart(4, '0')}</p>
                        
                        {(admin.city || admin.state) && (
                          <div className="flex items-start gap-2 text-muted-foreground text-sm mb-2">
                            <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
                            <span>
                              {admin.address ? `${admin.address}, ` : ''}
                              {admin.city}{admin.city && admin.state ? ', ' : ''}{admin.state}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Organization Updates (Posts) */}
          {adminPosts.length > 0 && (
            <div className="mt-24">
              <div className="text-center mb-12">
                <h3 className="text-3xl font-display font-bold mb-4">Latest Organization Activity</h3>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Updates on free supplement camps, payments out, and network expansions.
                </p>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {adminPosts.slice(0, 6).map((post) => (
                  <Card key={post.id} className="overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                    <div className="p-4 flex items-center gap-3 border-b">
                      <div className="w-10 h-10 rounded-full bg-secondary overflow-hidden shrink-0">
                        {post.admin_photo ? (
                          <img src={getImageUrl(post.admin_photo) || ''} alt={post.admin_name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-primary/10 text-primary font-bold">
                            {post.admin_name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{post.admin_name}</p>
                        <p className="text-xs text-muted-foreground">{post.created_at}</p>
                      </div>
                    </div>
                    {post.media_url && (
                      <div className="w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
                        {post.media_type === 'video' ? (
                          <video src={getImageUrl(post.media_url) || ''} controls className="w-full h-full object-contain" />
                        ) : (
                          <img src={getImageUrl(post.media_url) || ''} alt="Post" className="w-full h-full object-cover" />
                        )}
                      </div>
                    )}
                    <CardContent className="p-4 bg-card">
                      <p className="text-sm whitespace-pre-wrap">{post.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

        </div>
      </section>

      {/* Support Section */}
      <section id="support" className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Need Help?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our support team is here to help you with any questions or concerns.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="gradient-card">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Call Us</CardTitle>
                <CardDescription>
                  Available Mon-Sat, 8 AM - 8 PM
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-xl font-semibold">+91 83690 98778</p>
                <p className="text-muted-foreground mt-2">
                  Our team speaks Hindi, Marathi, and English
                </p>
              </CardContent>
            </Card>

            <Card className="gradient-card">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Email Us</CardTitle>
                <CardDescription>
                  We respond within 24 hours
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-xl font-semibold">ayush.v.singh2611@gmail.com</p>
                <p className="text-muted-foreground mt-2">
                  For technical issues or payment queries
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-12 max-w-4xl mx-auto gradient-card overflow-hidden">
            <div className="md:grid md:grid-cols-2">
              <div className="p-8 bg-primary text-primary-foreground flex flex-col justify-center">
                <h3 className="text-2xl font-bold mb-4">Send us a Message</h3>
                <p className="text-primary-foreground/80 mb-6 font-light">
                  Have a specific question or feedback? Fill out the form and our representative will get back to you within 24 hours.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 opacity-70" />
                    <span>Technical Support</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 opacity-70" />
                    <span>Partnership Queries</span>
                  </div>
                </div>
              </div>
              <div className="p-8">
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="contact-name">Your Name</Label>
                    <Input 
                      id="contact-name" 
                      placeholder="Enter your name" 
                      required 
                      value={contactData.name}
                      onChange={e => setContactData({...contactData, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contact-email">Email Address</Label>
                    <Input 
                      id="contact-email" 
                      type="email" 
                      placeholder="name@example.com" 
                      required 
                      value={contactData.email}
                      onChange={e => setContactData({...contactData, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contact-message">How can we help?</Label>
                    <Textarea 
                      id="contact-message" 
                      placeholder="Tell us more about your inquiry..." 
                      className="min-h-[120px]" 
                      required 
                      value={contactData.message}
                      onChange={e => setContactData({...contactData, message: e.target.value})}
                    />
                  </div>
                  <Button type="submit" className="w-full gradient-hero h-12 text-lg font-bold" disabled={contactLoading}>
                    {contactLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : "Send Message"}
                  </Button>
                </form>
              </div>
            </div>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
