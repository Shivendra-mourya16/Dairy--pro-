import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Milk, Loader2, CheckCircle, CreditCard } from 'lucide-react';
import { toast } from 'sonner';
import { StartupPlan } from '@/types';

type Step = 'profile' | 'plan' | 'payment' | 'complete';

export default function CompleteProfile() {
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  
  const [step, setStep] = useState<Step>('profile');
  const [loading, setLoading] = useState(false);
  
  // Form data
  const [fullName, setFullName] = useState('');
  const [aadhaar, setAadhaar] = useState('');
  const [pan, setPan] = useState('');
  const [mobile, setMobile] = useState('');
  const [address, setAddress] = useState('');
  const [plan, setPlan] = useState<StartupPlan>('basic');

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      // Mock profile update
      setStep('plan');
    } catch (err) {
      toast.error('Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handlePlanSelect = () => {
    setStep('payment');
  };

  const handlePayment = async () => {
    if (!user) return;
    setLoading(true);
    
    // Simulate payment processing
    setTimeout(async () => {
      try {
        // Mock payment and profile completion
        await refreshProfile();
        toast.success('Profile completed successfully!');
        setStep('complete');
      } catch (err) {
        toast.error('Payment processing failed');
      } finally {
        setLoading(false);
      }
    }, 2000);
  };

  const renderStep = () => {
    switch (step) {
      case 'profile':
        return (
          <form onSubmit={handleProfileSubmit}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full legal name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="aadhaar">Aadhaar Number *</Label>
                  <Input
                    id="aadhaar"
                    placeholder="1234 5678 9012"
                    value={aadhaar}
                    onChange={(e) => setAadhaar(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pan">PAN Number *</Label>
                  <Input
                    id="pan"
                    placeholder="ABCDE1234F"
                    value={pan}
                    onChange={(e) => setPan(e.target.value.toUpperCase())}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number *</Label>
                <Input
                  id="mobile"
                  type="tel"
                  placeholder="+91 83690 98778"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address *</Label>
                <Textarea
                  id="address"
                  placeholder="Enter your complete address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                  rows={3}
                />
              </div>

              <Button type="submit" className="w-full gradient-hero" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Continue to Plan Selection'
                )}
              </Button>
            </CardContent>
          </form>
        );

      case 'plan':
        return (
          <CardContent className="space-y-6">
            <p className="text-muted-foreground text-center">
              Choose a startup plan to begin managing your dairy collection center
            </p>

            <RadioGroup value={plan} onValueChange={(v) => setPlan(v as StartupPlan)} className="space-y-4">
              <label className={`flex items-start p-4 rounded-lg border-2 cursor-pointer transition-all ${plan === 'basic' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'}`}>
                <RadioGroupItem value="basic" id="basic" className="mt-1" />
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-lg">Basic Setup</span>
                    <span className="text-xl font-bold text-primary">₹2-3 Lakhs</span>
                  </div>
                  <p className="text-muted-foreground mt-1">
                    Essential equipment for small-scale dairy collection
                  </p>
                  <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
                    <li>• Digital weighing scale</li>
                    <li>• Basic fat testing equipment</li>
                    <li>• Collection cans & supplies</li>
                    <li>• 6 months software license</li>
                  </ul>
                </div>
              </label>

              <label className={`flex items-start p-4 rounded-lg border-2 cursor-pointer transition-all ${plan === 'advanced' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'}`}>
                <RadioGroupItem value="advanced" id="advanced" className="mt-1" />
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-lg">Advanced Setup</span>
                    <span className="text-xl font-bold text-primary">₹5 Lakhs</span>
                  </div>
                  <p className="text-muted-foreground mt-1">
                    Complete solution for medium to large-scale operations
                  </p>
                  <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
                    <li>• Automated milk analyzer (Fat & SNF)</li>
                    <li>• Digital weighing with print receipt</li>
                    <li>• Chilling unit (500L capacity)</li>
                    <li>• 1 year software license + training</li>
                  </ul>
                </div>
              </label>
            </RadioGroup>

            <Button onClick={handlePlanSelect} className="w-full gradient-hero">
              Continue to Payment
            </Button>
          </CardContent>
        );

      case 'payment':
        return (
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-dairy-gold/20 flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-8 w-8 text-dairy-gold" />
              </div>
              <h3 className="text-xl font-semibold">Complete Payment</h3>
              <p className="text-muted-foreground mt-2">
                {plan === 'basic' ? 'Basic Setup: ₹2,50,000' : 'Advanced Setup: ₹5,00,000'}
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Card Number</Label>
                <Input placeholder="4242 4242 4242 4242" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Expiry</Label>
                  <Input placeholder="MM/YY" />
                </div>
                <div className="space-y-2">
                  <Label>CVV</Label>
                  <Input placeholder="123" type="password" />
                </div>
              </div>
            </div>

            <p className="text-xs text-muted-foreground text-center">
              This is a demo payment UI. Click below to simulate payment.
            </p>

            <Button onClick={handlePayment} className="w-full gradient-gold text-foreground" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing Payment...
                </>
              ) : (
                `Pay ${plan === 'basic' ? '₹2,50,000' : '₹5,00,000'}`
              )}
            </Button>
          </CardContent>
        );

      case 'complete':
        return (
          <CardContent className="space-y-6 text-center">
            <div className="w-20 h-20 rounded-full bg-success/10 flex items-center justify-center mx-auto">
              <CheckCircle className="h-10 w-10 text-success" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Setup Complete!</h3>
              <p className="text-muted-foreground">
                Your admin account is now fully activated. You can start managing milk collection.
              </p>
            </div>
            <Button 
              onClick={() => navigate('/admin/dashboard')} 
              className="w-full gradient-hero"
            >
              Go to Dashboard
            </Button>
          </CardContent>
        );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-hero-pattern bg-background p-4">
      <Card className="w-full max-w-lg gradient-card shadow-dairy">
        <CardHeader className="text-center">
          <div className="inline-flex items-center justify-center gap-2 mb-4">
            <div className="p-2 rounded-lg gradient-hero">
              <Milk className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-display font-bold">Dairy Pro</span>
          </div>
          <CardTitle className="text-2xl">Complete Your Profile</CardTitle>
          <CardDescription>
            {step === 'profile' && 'Enter your details to set up your admin account'}
            {step === 'plan' && 'Select a startup plan for your collection center'}
            {step === 'payment' && 'Complete payment to activate your account'}
            {step === 'complete' && 'Welcome to Dairy Pro Admin'}
          </CardDescription>
        </CardHeader>

        {renderStep()}
      </Card>
    </div>
  );
}
