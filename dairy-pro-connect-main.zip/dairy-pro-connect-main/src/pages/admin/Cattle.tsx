import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Eye, MapPin, Calendar, PiggyBank, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE, getImageUrl } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function AdminCattle() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCattle, setSelectedCattle] = useState<any | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const [listings, setListings] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({ active: 0, total_value: 0, sold_this_month: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/cattle?admin_id=${user?.id}`);
      const data = await res.json();
      setListings(data.listings || []);
      setStats(data.stats || { active: 0, total_value: 0, sold_this_month: 0 });
    } catch (err) {
      console.error('Failed to fetch cattle data:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredListings = listings.filter(cattle =>
    cattle.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cattle.owner.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Cattle Market</h1>
            <p className="text-muted-foreground">View cattle listings from verified users</p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search cattle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4">
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <PiggyBank className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.active}</p>
                  <p className="text-sm text-muted-foreground">Active Listings</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-dairy-gold/10">
                  <PiggyBank className="h-6 w-6 text-dairy-gold" />
                </div>
                <div>
                  <p className="text-2xl font-bold">₹{(stats.total_value / 100000).toFixed(1)}L</p>
                  <p className="text-sm text-muted-foreground">Total Value</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-success/10">
                  <PiggyBank className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.sold_this_month}</p>
                  <p className="text-sm text-muted-foreground">Sold This Month</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Listings Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((cattle) => (
            <Card key={cattle.id} className="gradient-card hover:shadow-dairy transition-shadow overflow-hidden">
              <div className="aspect-video bg-secondary flex items-center justify-center relative overflow-hidden">
                {cattle.image_url ? (
                  <img
                    src={getImageUrl(cattle.image_url) || ''}
                    alt={cattle.type}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <PiggyBank className="h-16 w-16 text-muted-foreground/30" />
                )}
              </div>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <CardTitle className="text-lg min-w-0 truncate pr-2 flex-1">{cattle.type}</CardTitle>
                  <Badge variant="outline" className={`flex-shrink-0 ${cattle.status === 'available' ? 'bg-primary/10 text-primary' : 'bg-success/10 text-success'}`}>
                    {cattle.status === 'available' ? 'For Sale' : cattle.status.toUpperCase()}
                  </Badge>
                </div>
                <CardDescription className="truncate">Listed by {cattle.owner}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Age: {cattle.age}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span className="truncate">{cattle.address}</span>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <p className="text-xl font-bold text-primary">₹{cattle.price.toLocaleString()}</p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedCattle(cattle);
                      setDialogOpen(true);
                    }}
                  >
                    <Eye className="h-4 w-4 mr-1" />
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Detail Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{selectedCattle?.type}</DialogTitle>
              <DialogDescription>Listed by {selectedCattle?.owner}</DialogDescription>
            </DialogHeader>

            {selectedCattle && (
              <div className="space-y-4 mt-4">
                <div className="aspect-video bg-secondary rounded-lg flex items-center justify-center overflow-hidden">
                  {selectedCattle.image_url ? (
                    <img
                      src={getImageUrl(selectedCattle.image_url) || ''}
                      alt={selectedCattle.type}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <PiggyBank className="h-20 w-20 text-muted-foreground/30" />
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Age</p>
                    <p className="font-medium">{selectedCattle.age}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Number of Calves</p>
                    <p className="font-medium">{selectedCattle.calves}</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Medical Records</p>
                  <p className="font-medium">{selectedCattle.medical}</p>
                </div>

                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-medium">{selectedCattle.address}</p>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div>
                    <p className="text-sm text-muted-foreground">Asking Price</p>
                    <p className="text-2xl font-bold text-primary">₹{selectedCattle.price.toLocaleString()}</p>
                  </div>
                  <Button className="gradient-hero">Contact Seller</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
