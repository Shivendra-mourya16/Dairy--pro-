import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Package, Plus, Search, Gift, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function Supplements() {
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState('');
  const [supplementName, setSupplementName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('kg');
  const [isFree, setIsFree] = useState(false);
  const [price, setPrice] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const [records, setRecords] = useState<any[]>([]);
  const [stats, setStats] = useState<any>({ total: 0, free: 0, paid: 0 });
  const [farmers, setFarmers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      const [supRes, farmersRes] = await Promise.all([
        fetch(`${API_BASE}/api/admin/supplements?admin_id=${user?.id}`),
        fetch(`${API_BASE}/api/admin/users?admin_id=${user?.id}`)
      ]);
      const supData = await supRes.json();
      const farmersData = await farmersRes.json();

      setRecords(supData.records || []);
      setStats(supData.stats || { total: 0, free: 0, paid: 0 });
      setFarmers(farmersData.filter((f: any) => f.is_verified));
    } catch (err) {
      console.error('Failed to fetch data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || !supplementName) {
      toast.error('Please fill all required fields');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/supplements/add`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmer_id: selectedUser,
          name: supplementName,
          quantity: parseFloat(quantity),
          unit,
          is_free: isFree,
          price: isFree ? 0 : parseFloat(price)
        })
      });

      if (!res.ok) throw new Error('Failed to record distribution');

      toast.success('Supplement distribution recorded!');
      setDialogOpen(false);
      fetchData();

      // Reset form
      setSelectedUser('');
      setSupplementName('');
      setQuantity('');
      setIsFree(false);
      setPrice('');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredRecords = records.filter(r =>
    r.farmer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.supplement.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Supplements Distribution</h1>
            <p className="text-muted-foreground">Manage cattle feed and supplement distribution</p>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gradient-hero">
                <Plus className="h-4 w-4 mr-2" />
                Add Distribution
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5 text-primary" />
                  New Supplement Distribution
                </DialogTitle>
                <DialogDescription>
                  Record supplement distribution to a farmer
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Select Farmer *</Label>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a farmer" />
                    </SelectTrigger>
                    <SelectContent>
                      {farmers.map((farmer) => (
                        <SelectItem key={farmer.id} value={farmer.id.toString()}>
                          {farmer.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Supplement Name *</Label>
                  <Select value={supplementName} onValueChange={setSupplementName}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a supplement" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Cattle Feed Premium">Cattle Feed Premium</SelectItem>
                      <SelectItem value="Mineral Mix">Mineral Mix</SelectItem>
                      <SelectItem value="Vitamin Supplement">Vitamin Supplement</SelectItem>
                      <SelectItem value="Cattle Feed Standard">Cattle Feed Standard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Quantity *</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Unit</Label>
                    <Select value={unit} onValueChange={setUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">Kilograms (kg)</SelectItem>
                        <SelectItem value="liter">Liters</SelectItem>
                        <SelectItem value="unit">Units</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="free"
                    checked={isFree}
                    onCheckedChange={(checked) => setIsFree(checked as boolean)}
                  />
                  <Label htmlFor="free" className="font-normal cursor-pointer">
                    Free distribution (no charge)
                  </Label>
                </div>

                {!isFree && (
                  <div className="space-y-2">
                    <Label>Price (₹) *</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      required={!isFree}
                    />
                  </div>
                )}

                <Button type="submit" className="w-full gradient-hero" disabled={submitting}>
                  {submitting && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
                  Record Distribution
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4">
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <Package className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.total}</p>
                  <p className="text-sm text-muted-foreground">Total Distributions</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-success/10">
                  <Gift className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.free}</p>
                  <p className="text-sm text-muted-foreground">Free Distributions</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-dairy-gold/10">
                  <Package className="h-6 w-6 text-dairy-gold" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.paid}</p>
                  <p className="text-sm text-muted-foreground">Paid Distributions</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Distribution Records */}
        <Card className="gradient-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Distribution Records</CardTitle>
              <CardDescription>Monthly supplement distribution history</CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredRecords.map((record) => (
                <div key={record.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 flex-wrap sm:flex-nowrap gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold truncate">{record.farmer}</p>
                    <p className="text-sm text-muted-foreground truncate">
                      {record.supplement} • {record.quantity} {record.unit}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">{record.date}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    {record.isFree ? (
                      <Badge className="bg-success/10 text-success border-success/30">
                        <Gift className="h-3 w-3 mr-1" />
                        Free
                      </Badge>
                    ) : (
                      <p className="font-semibold text-primary">₹{record.price}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
