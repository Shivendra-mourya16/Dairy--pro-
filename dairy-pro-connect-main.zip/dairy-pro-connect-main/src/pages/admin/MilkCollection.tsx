import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Milk, Plus, Search, AlertCircle, Loader2, Download } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function MilkCollection() {
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState('');
  const [milkType, setMilkType] = useState<'Cow' | 'Buffalo'>('Cow');
  const [weight, setWeight] = useState('');
  const [fat, setFat] = useState('');
  const [snf, setSnf] = useState('');
  const [water, setWater] = useState('0');
  const [searchTerm, setSearchTerm] = useState('');

  const [farmers, setFarmers] = useState<any[]>([]);
  const [recentRecords, setRecentRecords] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      const [farmersRes, statsRes] = await Promise.all([
        fetch(`${API_BASE}/api/admin/users?admin_id=${user?.id}`),
        fetch(`${API_BASE}/api/admin/stats?admin_id=${user?.id}`)
      ]);

      const farmersData = await farmersRes.json();
      const statsData = await statsRes.json();

      setFarmers(farmersData.filter((f: any) => f.is_verified));
      setRecentRecords(statsData.recent_collections || []);

      // Fetch settings separately or use statsData if it contains them
      const settingsRes = await fetch(`${API_BASE}/api/admin/settings`);
      const settingsData = await settingsRes.json();

      setSettings({
        ...settingsData,
        cow_price: settingsData.cow_normal_price || 45,
        buffalo_price: settingsData.buffalo_normal_price || 65,
        farmer_share: settingsData.farmer_share || 90,
        admin_cut: settingsData.admin_cut || 6,
        company_cut: settingsData.company_cut || 4
      });
    } catch (err) {
      console.error('Failed to fetch data:', err);
    } finally {
      setLoading(false);
    }
  };

  const calculateTotal = () => {
    const weightNum = parseFloat(weight) || 0;
    const fatNum = parseFloat(fat) || 0;
    const snfNum = parseFloat(snf) || 0;
    const waterNum = parseFloat(water) || 0;

    if (!settings) return { total: 0, userPayout: 0, adminCut: 0, companyCut: 0, quality: 'Normal', pricePerLiter: 0, fBonus: 0, sBonus: 0, wDeduction: 0 };

    const isCow = milkType === 'Cow';
    const base = isCow ? settings.cow_base_price : settings.buffalo_base_price;
    const normal = isCow ? settings.cow_normal_price : settings.buffalo_normal_price;
    const fStd = isCow ? settings.cow_fat_std : settings.buffalo_fat_std;
    const sStd = isCow ? settings.cow_snf_std : settings.buffalo_snf_std;

    let quality = 'Normal';
    let pricePerLiter = normal;
    let fBonus = 0;
    let sBonus = 0;
    let wDeduction = 0;

    if (fatNum < fStd || snfNum < sStd) {
      quality = 'Low';
      pricePerLiter = base;
    } else if (fatNum > fStd || snfNum > sStd) {
      quality = 'High';
      if (fatNum > fStd) fBonus = (fatNum - fStd) * settings.fat_bonus_rate;
      if (snfNum > sStd) sBonus = (snfNum - sStd) * settings.snf_bonus_rate;
      pricePerLiter = normal + fBonus + sBonus;
    }

    const waterPct = (waterNum / weightNum) * 100 || 0;
    if (waterPct > settings.water_threshold) {
      wDeduction = settings.water_deduction_rate;
      pricePerLiter -= wDeduction;
    }

    pricePerLiter = Math.max(pricePerLiter, base);

    const total = weightNum * pricePerLiter;
    const userPayout = total * (settings.farmer_share / 100);
    const adminCut = total * (settings.admin_cut / 100);
    const companyCut = total * (settings.company_cut / 100);

    return { total, userPayout, adminCut, companyCut, quality, pricePerLiter, fBonus, sBonus, wDeduction };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      toast.error('Please select a verified user');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/api/milk/add`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmer_id: selectedUser,
          type: milkType,
          weight: parseFloat(weight),
          fat: parseFloat(fat),
          snf: parseFloat(snf),
          water: parseFloat(water)
        })
      });

      if (!res.ok) throw new Error('Failed to add record');

      toast.success('Milk record added successfully!');
      setDialogOpen(false);
      fetchData(); // Refresh list

      // Reset form
      setSelectedUser('');
      setWeight('');
      setFat('');
      setSnf('');
      setWater('0');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredCollections = recentRecords.filter(c =>
    c.farmer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExport = () => {
    const adminId = user?.id;
    if (!adminId) return;
    window.open(`${API_BASE}/api/export/milk-history?admin_id=${adminId}`, '_blank');
  };

  const { total, userPayout, adminCut, companyCut, quality, pricePerLiter, fBonus, sBonus, wDeduction } = calculateTotal();

  if (loading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Milk Collection</h1>
            <p className="text-muted-foreground">Record and manage daily milk collections</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleExport} className="border-blue-200 hover:bg-blue-50 text-blue-600">
              <Download className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gradient-hero">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Collection
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Milk className="h-5 w-5 text-primary" />
                    New Milk Collection
                  </DialogTitle>
                <DialogDescription>
                  Add milk collection entry for a verified farmer
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Select Verified User *</Label>
                  <Select value={selectedUser} onValueChange={setSelectedUser}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a farmer" />
                    </SelectTrigger>
                    <SelectContent>
                      {farmers.map((farmer) => (
                        <SelectItem key={farmer.id} value={farmer.id.toString()}>
                          {farmer.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Milk Type *</Label>
                  <Select value={milkType} onValueChange={(v) => setMilkType(v as 'Cow' | 'Buffalo')}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Cow">Cow Milk</SelectItem>
                      <SelectItem value="Buffalo">Buffalo Milk</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Weight (Liters) *</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Fat % *</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      value={fat}
                      onChange={(e) => setFat(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>SNF % *</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      value={snf}
                      onChange={(e) => setSnf(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Water Quantity (L)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      placeholder="0.0"
                      value={water}
                      onChange={(e) => setWater(e.target.value)}
                    />
                  </div>
                </div>

                {weight && (
                  <Card className="bg-secondary/50 overflow-hidden">
                    <div className={`h-1 w-full ${quality === 'High' ? 'bg-primary' : quality === 'Low' ? 'bg-destructive' : 'bg-dairy-gold'}`} />
                    <CardContent className="pt-4">
                      <div className="flex justify-between items-center mb-4">
                        <p className="text-sm font-bold">Payment Breakdown</p>
                        <Badge variant={quality === 'High' ? 'default' : quality === 'Low' ? 'destructive' : 'secondary'}>
                          {quality} Quality
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Base/Normal Price</span>
                          <span>₹{pricePerLiter - fBonus - sBonus + wDeduction}</span>
                        </div>
                        
                        {(fBonus > 0 || sBonus > 0) && (
                          <div className="p-2 rounded bg-primary/5 space-y-1">
                            {fBonus > 0 && (
                              <div className="flex justify-between text-xs text-primary">
                                <span>Fat Bonus</span>
                                <span>+₹{fBonus.toFixed(2)}</span>
                              </div>
                            )}
                            {sBonus > 0 && (
                              <div className="flex justify-between text-xs text-primary">
                                <span>SNF Bonus</span>
                                <span>+₹{sBonus.toFixed(2)}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {wDeduction > 0 && (
                          <div className="flex justify-between text-xs text-destructive">
                            <span>Water Deduction</span>
                            <span>-₹{wDeduction.toFixed(2)}</span>
                          </div>
                        )}

                        <div className="h-px bg-border my-2" />

                        <div className="flex justify-between font-bold">
                          <span>Final Price per Liter</span>
                          <span className="text-primary italic">₹{pricePerLiter.toFixed(2)}</span>
                        </div>

                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Amount ({weight}L)</span>
                          <span>₹{total.toFixed(2)}</span>
                        </div>
                        
                        <div className="flex justify-between text-primary font-bold pt-2 border-t">
                          <span>Farmer Payout ({settings?.farmer_share}%)</span>
                          <span>₹{userPayout.toFixed(2)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Button type="submit" className="w-full gradient-hero" disabled={submitting}>
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Add Collection
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

        {/* Info Banner */}
        <Card className="bg-dairy-gold/10 border-dairy-gold/30">
          <CardContent className="flex items-center gap-3 py-4">
            <AlertCircle className="h-5 w-5 text-dairy-gold" />
            <p className="text-sm">
              <strong>Note:</strong> Milk records can only be added for verified users. Unverified users must complete their verification first.
            </p>
          </CardContent>
        </Card>

        {/* Current Price */}
        <div className="grid sm:grid-cols-4 gap-4">
          <Card className="gradient-card">
            <CardContent className="pt-6 text-center">
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] uppercase text-muted-foreground">
                   <span>Cow</span>
                   <span>Base: ₹{settings?.cow_base_price}</span>
                </div>
                <p className="text-2xl font-bold text-primary">₹{settings?.cow_normal_price || 45}</p>
                
                <div className="h-px bg-border my-1" />
                
                <div className="flex justify-between items-center text-[10px] uppercase text-muted-foreground">
                   <span>Buffalo</span>
                   <span>Base: ₹{settings?.buffalo_base_price}</span>
                </div>
                <p className="text-2xl font-bold text-primary">₹{settings?.buffalo_normal_price || 65}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6 text-center">
              <p className="text-3xl font-bold text-dairy-gold">{settings?.farmer_share || 90}%</p>
              <p className="text-sm text-muted-foreground">Farmer Payout</p>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6 text-center">
              <p className="text-3xl font-bold text-dairy-earth">{settings?.admin_cut || 6}%</p>
              <p className="text-sm text-muted-foreground">Admin Cut</p>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6 text-center">
              <p className="text-3xl font-bold text-muted-foreground">{settings?.company_cut || 4}%</p>
              <p className="text-sm text-muted-foreground">Company Cut</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Collections */}
        <Card className="gradient-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Collections</CardTitle>
              <CardDescription>Latest milk collection entries</CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search farmer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredCollections.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No collections found</p>
              ) : (
                filteredCollections.map((collection) => (
                  <div key={collection.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 flex-wrap sm:flex-nowrap gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold truncate">{collection.farmer}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        {collection.type} • {collection.liters}L • Fat: {collection.fat}%
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-semibold text-primary">₹{collection.amount?.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">{collection.date}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
