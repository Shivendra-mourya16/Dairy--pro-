import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, Download, Banknote, CheckCircle, Clock, XCircle, Eye, Printer, User, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

export default function AdminPayments() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('payouts');
  const [selectedPayment, setSelectedPayment] = useState<any>(null);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [pendingPayouts, setPendingPayouts] = useState<any[]>([]);
  const [pendingSupplements, setPendingSupplements] = useState<any[]>([]);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<any>(null);

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      const [pendingRes, historyRes, supplementsRes] = await Promise.all([
        fetch(`${API_BASE}/api/admin/pending-payouts?admin_id=${user?.id}`),
        fetch(`${API_BASE}/api/admin/payment-history?admin_id=${user?.id}`),
        fetch(`${API_BASE}/api/admin/pending-supplements?admin_id=${user?.id}`)
      ]);
      const pendingData = await pendingRes.json();
      const historyData = await historyRes.json();
      const supplementsData = await supplementsRes.json();

      setPendingPayouts(Array.isArray(pendingData) ? pendingData : []);
      setPaymentHistory(Array.isArray(historyData) ? historyData : []);
      setPendingSupplements(Array.isArray(supplementsData) ? supplementsData : []);
    } catch (err) {
      console.error('Failed to fetch payments:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePay = async (payout: any) => {
    setProcessingId(payout.id);
    try {
      const res = await fetch(`${API_BASE}/api/admin/confirm-payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: payout.id,
          amount: payout.pendingAmount
        })
      });

      if (!res.ok) throw new Error('Payment failed');

      toast.success(`Payment of ₹${payout.pendingAmount} processed for ${payout.farmer}`);
      fetchData();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setProcessingId(null);
    }
  };

  const handleApproveSupplement = async (sup: any) => {
    setProcessingId(sup.id);
    try {
      const res = await fetch(`${API_BASE}/api/admin/supplements/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: sup.id })
      });

      if (!res.ok) throw new Error('Approval failed');

      toast.success(`Supplement approved for ${sup.farmer}`);
      fetchData();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setProcessingId(null);
    }
  };

  const filteredHistory = paymentHistory.filter(p =>
    p.farmer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.txn_id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex h-[60vh] items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Payments & Transactions</h1>
            <p className="text-muted-foreground">Manage payouts and track all platform payments</p>
          </div>
          <Button
            variant="outline"
            onClick={() => window.open(`${API_BASE}/api/export/milk-history?admin_id=${user?.id}`, '_blank')}
          >
            <Download className="h-4 w-4 mr-2" />Export All
          </Button>
        </div>

        <Tabs defaultValue="payouts" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="flex flex-wrap h-auto w-full gap-2 sm:grid sm:grid-cols-3 lg:w-[600px] bg-transparent sm:bg-muted p-0 sm:p-1">
            <TabsTrigger value="payouts" className="flex-1 min-w-[120px] bg-muted sm:bg-transparent data-[state=active]:bg-background">Farmer Payouts</TabsTrigger>
            <TabsTrigger value="supplements" className="flex-1 min-w-[120px] bg-muted sm:bg-transparent data-[state=active]:bg-background">Supplements</TabsTrigger>
            <TabsTrigger value="cattle" className="flex-1 min-w-[120px] bg-muted sm:bg-transparent data-[state=active]:bg-background">Cattle Market</TabsTrigger>
          </TabsList>

          <TabsContent value="payouts" className="space-y-4 mt-6">
            <div className="grid sm:grid-cols-2 gap-4">
              {pendingPayouts.length === 0 ? (
                <div className="col-span-2 text-center py-12 text-muted-foreground">
                  <Banknote className="h-12 w-12 mx-auto mb-3 opacity-20" />
                  <p>No pending payouts at the moment</p>
                </div>
              ) : (
                pendingPayouts.map((payout) => (
                  <Card key={payout.id} className="gradient-card overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl">{payout.farmer}</CardTitle>
                          <CardDescription>Pending Payout: ₹{payout.pendingAmount.toLocaleString()}</CardDescription>
                        </div>
                        <Badge variant="outline" className="bg-dairy-gold/10 text-dairy-gold">Auto-Calculated</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-2 text-sm bg-secondary/30 p-3 rounded-lg">
                        <div><p className="text-muted-foreground">Bank</p><p className="font-medium">{payout.bank}</p></div>
                        <div><p className="text-muted-foreground">IFSC</p><p className="font-medium">{payout.ifsc}</p></div>
                        <div className="col-span-2"><p className="text-muted-foreground">A/C Number</p><p className="font-medium">{payout.acc}</p></div>
                      </div>
                      <div className="flex items-center justify-between text-sm pt-2">
                        <span>Total Milk: <strong>{payout.totalLiters.toFixed(1)}L</strong></span>
                        <span>Avg Fat: <strong>{payout.avgFat.toFixed(1)}%</strong></span>
                      </div>
                      <Button
                        className="w-full gradient-hero"
                        onClick={() => handlePay(payout)}
                        disabled={processingId === payout.id}
                      >
                        {processingId === payout.id ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <Banknote className="h-4 w-4 mr-2" />
                        )}
                        Confirm & Pay ₹{payout.pendingAmount.toLocaleString()}
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="supplements" className="mt-6 space-y-6">
            {pendingSupplements.length > 0 && (
              <Card className="border-dairy-gold/30 bg-dairy-gold/5">
                <CardHeader>
                  <CardTitle className="text-dairy-gold flex items-center gap-2">
                    <Clock className="h-5 w-5" /> Pending Requests
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {pendingSupplements.map(sup => (
                    <div key={sup.id} className="flex items-center justify-between p-4 rounded-lg bg-background border border-dairy-gold/20 shadow-sm">
                      <div>
                        <p className="font-semibold">{sup.farmer}</p>
                        <p className="text-sm text-muted-foreground">{sup.supplement} • {sup.quantity} {sup.unit}</p>
                        <p className="text-xs text-muted-foreground">{sup.date}</p>
                      </div>
                      <div className="flex items-center gap-4 flex-shrink-0 mt-2 sm:mt-0">
                        <div className="text-right">
                          <p className="font-bold text-primary">₹{sup.price}</p>
                          {sup.isFree && <Badge className="bg-success/10 text-success border-success/30">Free</Badge>}
                        </div>
                        <Button
                          size="sm"
                          className="gradient-hero"
                          onClick={() => handleApproveSupplement(sup)}
                          disabled={processingId === sup.id}
                        >
                          {processingId === sup.id ? <Loader2 className="h-4 w-4 animate-spin" /> : "Approve & Deliver"}
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            <Card className="gradient-card">
              <CardHeader><CardTitle>Supplement Payment History</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredHistory.filter(p => p.type.includes('Supplement')).length === 0 ? (
                    <p className="text-center py-8 text-muted-foreground">No supplement payments found</p>
                  ) : (
                    filteredHistory.filter(p => p.type.includes('Supplement')).map(p => (
                      <div key={p.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg bg-secondary/50 border border-transparent hover:border-primary/20 transition-all cursor-pointer gap-2" onClick={() => { setSelectedPayment(p); setReceiptOpen(true); }}>
                        <div className="flex items-center gap-3 min-w-0 w-full sm:w-auto">
                          <div className="p-2 bg-dairy-sky/10 rounded-full text-dairy-sky flex-shrink-0"><User className="h-5 w-5" /></div>
                          <div className="min-w-0 flex-1"><p className="font-semibold truncate">{p.farmer}</p><p className="text-xs sm:text-sm text-muted-foreground truncate">{p.item || 'Supplement'}</p></div>
                        </div>
                        <div className="text-left sm:text-right flex-shrink-0 ml-11 sm:ml-0">
                          <p className="font-bold text-primary">₹{p.amount}</p>
                          <p className="text-xs text-muted-foreground">{p.date}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cattle" className="mt-6">
            <Card className="gradient-card">
              <CardHeader><CardTitle>Cattle Purchase Advance (10%)</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredHistory.filter(p => p.type.includes('Cattle')).length === 0 ? (
                    <p className="text-center py-8 text-muted-foreground">No cattle advance payments found</p>
                  ) : (
                    filteredHistory.filter(p => p.type.includes('Cattle')).map(p => (
                      <div key={p.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-all cursor-pointer gap-2" onClick={() => { setSelectedPayment(p); setReceiptOpen(true); }}>
                        <div className="flex items-center gap-3 min-w-0 w-full sm:w-auto">
                          <div className="p-2 bg-primary/10 rounded-full text-primary flex-shrink-0"><Banknote className="h-5 w-5" /></div>
                          <div className="min-w-0 flex-1">
                            <p className="font-semibold truncate">Buyer: {p.buyer || p.farmer}</p>
                            <p className="text-xs sm:text-sm text-muted-foreground truncate">Cattle: {p.cattle || 'Listed Cattle'} | Seller: {p.seller || 'N/A'}</p>
                          </div>
                        </div>
                        <div className="text-left sm:text-right flex-shrink-0 ml-11 sm:ml-0">
                          <p className="font-bold text-primary">₹{p.amount.toLocaleString()}</p>
                          <Badge className="bg-success/10 text-success border-success/30">Paid</Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Payment History Search */}
        {activeTab === 'payouts' && (
          <Card className="gradient-card mt-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <div><CardTitle>Recent History</CardTitle><CardDescription>All processed payments</CardDescription></div>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search transaction..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {filteredHistory.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No transaction history found</p>
                ) : (
                  filteredHistory.map((p) => (
                    <div key={p.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg bg-secondary/50 group cursor-pointer gap-2" onClick={() => { setSelectedPayment(p); setReceiptOpen(true); }}>
                      <div className="flex items-center gap-3 min-w-0 w-full sm:w-auto">
                        <div className="w-10 h-10 flex-shrink-0 rounded-full bg-success/10 flex items-center justify-center text-success"><CheckCircle className="h-6 w-6" /></div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold truncate">{p.farmer}</p>
                          <p className="text-xs sm:text-sm text-muted-foreground truncate">{p.date} • {p.txn_id}</p>
                          <Badge variant="outline" className="text-[10px] uppercase mt-1">{p.type}</Badge>
                        </div>
                      </div>
                      <div className="flex items-center justify-between w-full sm:w-auto sm:justify-end gap-4 ml-0 sm:ml-auto mt-2 sm:mt-0">
                        <p className="font-bold text-lg ml-11 sm:ml-0">₹{p.amount.toLocaleString()}</p>
                        <Button variant="ghost" size="icon" className="sm:opacity-0 group-hover:opacity-100 flex-shrink-0"><Eye className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Receipt Dialog */}
        <Dialog open={receiptOpen} onOpenChange={setReceiptOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-center text-2xl">Payment Receipt</DialogTitle>
              <DialogDescription className="text-center">Dairy Pro Connect Official Transaction</DialogDescription>
            </DialogHeader>
            {selectedPayment && (
              <div className="space-y-6 mt-4 p-6 border-t border-b border-dashed">
                <div className="flex justify-between items-center"><span className="text-muted-foreground text-sm uppercase">Transaction ID</span><span className="font-mono font-bold">{selectedPayment.txn_id}</span></div>
                <div className="flex justify-between items-center"><span className="text-muted-foreground text-sm uppercase">Payment Date</span><span>{selectedPayment.date}</span></div>
                <div className="flex justify-between items-center"><span className="text-muted-foreground text-sm uppercase">Payment Mode</span><span>{selectedPayment.mode}</span></div>
                <div className="flex justify-between items-center"><span className="text-muted-foreground text-sm uppercase">Type</span><Badge variant="outline">{selectedPayment.type}</Badge></div>

                <div className="bg-secondary/30 p-4 rounded-lg space-y-2">
                  <div className="flex justify-between"><span className="text-sm">User Details</span><span className="font-medium">{selectedPayment.farmer}</span></div>
                </div>

                <div className="text-center pt-4">
                  <p className="text-muted-foreground text-xs mb-1 uppercase tracking-widest">Amount Paid</p>
                  <p className="text-4xl font-bold text-primary">₹{selectedPayment.amount.toLocaleString()}</p>
                </div>
              </div>
            )}
            <div className="flex gap-3 pt-2">
              <Button className="flex-1" variant="outline" onClick={() => window.open(`${API_BASE}/api/export/receipt/${selectedPayment?.id}`, '_blank')}><Printer className="h-4 w-4 mr-2" />Print PDF</Button>
              <Button className="flex-1 gradient-hero" onClick={() => setReceiptOpen(false)}>Done</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
