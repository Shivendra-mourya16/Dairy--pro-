import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Heart, Landmark, CreditCard, QrCode } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';

export default function AdminDonations() {
  const { user } = useAuth();
  const [donations, setDonations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      fetchDonations();
    }
  }, [user]);

  const fetchDonations = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/donations?admin_id=${user?.id}`);
      const data = await res.json();
      setDonations(data || []);
    } catch (err) {
      console.error('Failed to fetch donations:', err);
    } finally {
      setLoading(false);
    }
  };

  const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">Center Donations</h1>
            <p className="text-muted-foreground">Community support tracking for your dairy center</p>
          </div>
          <Card className="bg-primary/10 border-primary/20">
            <CardContent className="py-4 px-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <Heart className="h-6 w-6 text-primary fill-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Support</p>
                <p className="text-2xl font-bold text-primary">₹{totalAmount.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="gradient-card">
          <CardHeader>
            <CardTitle>Recent Support Activity</CardTitle>
            <CardDescription>
              Donors who chose to support your village center (Money is managed by organization)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">Loading donations...</div>
            ) : donations.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Heart className="h-12 w-12 mx-auto mb-4 opacity-20" />
                <p>No donations recorded for your center yet.</p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Donor</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Mode</TableHead>
                      <TableHead>Message</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {donations.map((d) => (
                      <TableRow key={d.id}>
                        <TableCell className="font-medium">{d.date}</TableCell>
                        <TableCell>{d.donor_name}</TableCell>
                        <TableCell className="text-xs">{d.location}</TableCell>
                        <TableCell className="font-bold text-primary">₹{d.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {d.payment_mode === 'upi' && <Landmark className="h-3 w-3" />}
                            {d.payment_mode === 'card' && <CreditCard className="h-3 w-3" />}
                            {d.payment_mode === 'qr' && <QrCode className="h-3 w-3" />}
                            <span className="capitalize text-xs">{d.payment_mode}</span>
                          </div>
                        </TableCell>
                        <TableCell className="max-w-xs truncate text-xs italic">
                          "{d.message || 'No message'}"
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
