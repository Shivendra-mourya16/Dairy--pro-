import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Eye, User, CheckCircle, XCircle, Clock, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface DBUser {
  id: number;
  full_name: string;
  mobile: string;
  email: string;
  address: string;
  is_verified: boolean;
  created_at: string;
  bank_details?: {
    bank_name: string;
    account_holder: string;
    account_number: string;
    ifsc_code: string;
  };
}

interface UserRecords {
  milk_records: any[];
  payments: any[];
}

export default function UserManagement() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<DBUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<DBUser | null>(null);
  const [userRecords, setUserRecords] = useState<UserRecords | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [recordsLoading, setRecordsLoading] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchUsers();
    }
  }, [user]);

  const fetchUsers = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/users?admin_id=${user?.id}`);
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error('Failed to fetch users:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserRecords = async (userId: number) => {
    setRecordsLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/user/${userId}/records`);
      const data = await res.json();
      setUserRecords(data);
    } catch (err) {
      console.error('Failed to fetch user records:', err);
    } finally {
      setRecordsLoading(false);
    }
  };

  const filteredUsers = users.filter(u =>
    u.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.mobile.includes(searchTerm) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const verifiedCount = users.filter(u => u.is_verified).length;
  const pendingCount = users.filter(u => !u.is_verified).length;

  const handleViewUser = (u: DBUser) => {
    setSelectedUser(u);
    setUserRecords(null);
    fetchUserRecords(u.id);
    setDialogOpen(true);
  };

  const UserRow = ({ user, onView }: { user: DBUser, onView: (u: DBUser) => void }) => (
    <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors flex-wrap sm:flex-nowrap gap-2">
      <div className="flex items-center gap-4 min-w-0 flex-1">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
          <span className="text-xl font-semibold text-primary">
            {user.full_name.charAt(0)}
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-semibold truncate">{user.full_name}</p>
          <p className="text-sm text-muted-foreground truncate">{user.mobile}</p>
        </div>
      </div>
      <div className="flex items-center gap-3 flex-shrink-0">
        {user.is_verified ? (
          <Badge variant="outline" className="bg-success/10 text-success border-success/30">
            <CheckCircle className="h-3 w-3 mr-1" />
            Verified
          </Badge>
        ) : (
          <Badge variant="outline" className="bg-dairy-gold/10 text-dairy-gold border-dairy-gold/30">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )}
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onView(user)}
        >
          <Eye className="h-4 w-4 mr-1" />
          View
        </Button>
      </div>
    </div>
  );

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold">User Management</h1>
            <p className="text-muted-foreground">View and manage verified farmers</p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-3 gap-4">
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{verifiedCount}</p>
                  <p className="text-sm text-muted-foreground">Verified Users</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-dairy-gold/10">
                  <Clock className="h-6 w-6 text-dairy-gold" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{pendingCount}</p>
                  <p className="text-sm text-muted-foreground">Pending Verification</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="gradient-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-dairy-sky/10">
                  <User className="h-6 w-6 text-dairy-sky" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{users.filter(u => {
                    const created = new Date(u.created_at);
                    const weekAgo = new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return created > weekAgo;
                  }).length}</p>
                  <p className="text-sm text-muted-foreground">New This Week</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* User List */}
        <Card className="gradient-card">
          <CardHeader>
            <CardTitle>Farmer Management</CardTitle>
            <CardDescription>View and manage all farmers registered under your center</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="verified" className="w-full">
              <TabsList className="grid w-full grid-cols-2 max-w-[400px] mb-6">
                <TabsTrigger value="verified">Verified ({verifiedCount})</TabsTrigger>
                <TabsTrigger value="pending">Pending ({pendingCount})</TabsTrigger>
              </TabsList>

              <TabsContent value="verified" className="space-y-4">
                {loading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredUsers.filter(u => u.is_verified).length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No verified farmers found</p>
                ) : (
                  filteredUsers.filter(u => u.is_verified).map((user) => (
                    <UserRow key={user.id} user={user} onView={handleViewUser} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="pending" className="space-y-4">
                {loading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : filteredUsers.filter(u => !u.is_verified).length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No pending verifications</p>
                ) : (
                  filteredUsers.filter(u => !u.is_verified).map((user) => (
                    <UserRow key={user.id} user={user} onView={handleViewUser} />
                  ))
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* User Detail Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-lg font-semibold text-primary">
                    {selectedUser?.full_name.charAt(0)}
                  </span>
                </div>
                {selectedUser?.full_name}
              </DialogTitle>
              <DialogDescription>
                User profile and records (Read-only)
              </DialogDescription>
            </DialogHeader>

            {selectedUser && (
              <Tabs defaultValue="profile" className="mt-4">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="profile">Profile</TabsTrigger>
                  <TabsTrigger value="bank">Bank Details</TabsTrigger>
                  <TabsTrigger value="milk">Milk Records</TabsTrigger>
                  <TabsTrigger value="payments">Payments</TabsTrigger>
                </TabsList>

                <TabsContent value="profile" className="space-y-4 mt-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Mobile Number</p>
                      <p className="font-medium">{selectedUser.mobile}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium">{selectedUser.email}</p>
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                      <p className="text-sm text-muted-foreground">Address</p>
                      <p className="font-medium">{selectedUser.address || 'N/A'}</p>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <p className="text-sm font-medium mb-3">Verification Status</p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className={`flex items-center gap-2 p-2 rounded ${selectedUser.is_verified ? 'bg-success/10' : 'bg-dairy-gold/10'}`}>
                        {selectedUser.is_verified ? <CheckCircle className="h-4 w-4 text-success" /> : <Clock className="h-4 w-4 text-dairy-gold" />}
                        <span className="text-sm">Account</span>
                      </div>
                      {['Email', 'Aadhaar', 'PAN'].map((item) => (
                        <div key={item} className="flex items-center gap-2 p-2 rounded bg-secondary/50">
                          <CheckCircle className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="bank" className="space-y-4 mt-4">
                  <Card className="bg-secondary/30">
                    <CardContent className="pt-6 space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground uppercase">Bank Name</p>
                          <p className="font-semibold text-primary">{selectedUser.bank_details?.bank_name || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase">IFSC Code</p>
                          <p className="font-semibold text-primary">{selectedUser.bank_details?.ifsc_code || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase">Account Number</p>
                          <p className="font-semibold text-primary">{selectedUser.bank_details?.account_number || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground uppercase">Account Holder</p>
                          <p className="font-semibold text-primary">{selectedUser.bank_details?.account_holder || 'N/A'}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="milk" className="mt-4">
                  {recordsLoading ? (
                    <div className="flex justify-center py-4">
                      <Loader2 className="h-6 w-6 animate-spin" />
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {userRecords?.milk_records.length === 0 ? (
                        <p className="text-center text-muted-foreground">No milk records found</p>
                      ) : (
                        userRecords?.milk_records.map((record) => (
                          <div key={record.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                            <div>
                              <p className="font-medium">{record.date}</p>
                              <p className="text-sm text-muted-foreground">
                                {record.type} • {record.weight}L • {record.fat}% fat • {record.snf}% SNF
                              </p>
                            </div>
                            <p className="font-semibold text-primary">₹{record.amount?.toFixed(2) || '0.00'}</p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="payments" className="mt-4">
                  {recordsLoading ? (
                    <div className="flex justify-center py-4">
                      <Loader2 className="h-6 w-6 animate-spin" />
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {userRecords?.payments.length === 0 ? (
                        <p className="text-center text-muted-foreground">No payments found</p>
                      ) : (
                        userRecords?.payments.map((payment) => (
                          <div key={payment.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                            <div>
                              <p className="font-medium">{payment.date}</p>
                              <Badge variant="outline" className={`${payment.status === 'completed' ? 'bg-success/10 text-success' : 'bg-dairy-gold/10 text-dairy-gold'} border-current mt-1`}>
                                {payment.status}
                              </Badge>
                            </div>
                            <p className="font-semibold text-primary">₹{payment.amount?.toLocaleString()}</p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
