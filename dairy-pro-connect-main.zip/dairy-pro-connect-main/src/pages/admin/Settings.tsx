import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Settings, Save, CreditCard, Loader2, User as UserIcon, ImagePlus, Milk } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';

export default function AdminSettings() {
  const { user } = useAuth();
  
  // Milk Pricing & Standards
  const [cowBasePrice, setCowBasePrice] = useState('40');
  const [cowNormalPrice, setCowNormalPrice] = useState('45');
  const [cowFatStd, setCowFatStd] = useState('3.5');
  const [cowSnfStd, setCowSnfStd] = useState('8.0');
  
  const [buffaloBasePrice, setBuffaloBasePrice] = useState('55');
  const [buffaloNormalPrice, setBuffaloNormalPrice] = useState('65');
  const [buffaloFatStd, setBuffaloFatStd] = useState('5.5');
  const [buffaloSnfStd, setBuffaloSnfStd] = useState('9.0');
  
  const [fatBonusRate, setFatBonusRate] = useState('7.0');
  const [snfBonusRate, setSnfBonusRate] = useState('1.5');
  const [waterThreshold, setWaterThreshold] = useState('10');
  const [waterDeductionRate, setWaterDeductionRate] = useState('3.0');
  
  const [dist, setDist] = useState<any>(null);
  
  // Bank Details
  const [bankName, setBankName] = useState('');
  const [accountHolder, setAccountHolder] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  
  // Profile Settings
  const [fullName, setFullName] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [address, setAddress] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);

  const [loading, setLoading] = useState(true);
  const [updatingPrice, setUpdatingPrice] = useState(false);
  const [updatingProfile, setUpdatingProfile] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchSettings();
      fetchProfile();
    }
  }, [user]);

  const fetchSettings = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/settings`);
      const data = await res.json();
      
      setCowBasePrice(data.cow_base_price?.toString() || '40');
      setCowNormalPrice(data.cow_normal_price?.toString() || '45');
      setCowFatStd(data.cow_fat_std?.toString() || '3.5');
      setCowSnfStd(data.cow_snf_std?.toString() || '8.0');
      
      setBuffaloBasePrice(data.buffalo_base_price?.toString() || '55');
      setBuffaloNormalPrice(data.buffalo_normal_price?.toString() || '65');
      setBuffaloFatStd(data.buffalo_fat_std?.toString() || '5.5');
      setBuffaloSnfStd(data.buffalo_snf_std?.toString() || '9.0');
      
      setFatBonusRate(data.fat_bonus_rate?.toString() || '7.0');
      setSnfBonusRate(data.snf_bonus_rate?.toString() || '1.5');
      setWaterThreshold(data.water_threshold?.toString() || '10');
      setWaterDeductionRate(data.water_deduction_rate?.toString() || '3.0');
      
      setDist(data);
    } catch (err) {
      console.error('Failed to fetch settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProfile = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admins`);
      const data = await res.json();
      const myProfile = data.find((a: any) => a.id === user?.id);
      if (myProfile) {
        setFullName(myProfile.full_name || '');
        setCity(myProfile.city || '');
        setState(myProfile.state || '');
        setAddress(myProfile.address || '');
        setPhotoUrl(myProfile.photo_url || '');
      }
    } catch (err) {
      console.error('Failed to fetch profile:', err);
    }
  };

  const handlePriceUpdate = async () => {
    setUpdatingPrice(true);
    try {
      const res = await fetch(`${API_BASE}/api/admin/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cow_base_price: parseFloat(cowBasePrice),
          cow_normal_price: parseFloat(cowNormalPrice),
          cow_fat_std: parseFloat(cowFatStd),
          cow_snf_std: parseFloat(cowSnfStd),
          buffalo_base_price: parseFloat(buffaloBasePrice),
          buffalo_normal_price: parseFloat(buffaloNormalPrice),
          buffalo_fat_std: parseFloat(buffaloFatStd),
          buffalo_snf_std: parseFloat(buffaloSnfStd),
          fat_bonus_rate: parseFloat(fatBonusRate),
          snf_bonus_rate: parseFloat(snfBonusRate),
          water_threshold: parseFloat(waterThreshold),
          water_deduction_rate: parseFloat(waterDeductionRate),
          cow_milk_price: parseFloat(cowNormalPrice), // Legacy support
          buffalo_milk_price: parseFloat(buffaloNormalPrice) // Legacy support
        })
      });
      if (!res.ok) throw new Error('Update failed');
      toast.success('Milk price updated successfully!');
      fetchSettings();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setUpdatingPrice(false);
    }
  };

  const handleProfileUpdate = async () => {
    setUpdatingProfile(true);
    try {
      const formData = new FormData();
      formData.append('full_name', fullName);
      formData.append('city', city);
      formData.append('state', state);
      formData.append('address', address);
      if (photoFile) {
        formData.append('photo', photoFile);
      }

      const res = await fetch(`${API_BASE}/api/admin/${user?.id}`, {
        method: 'PUT',
        body: formData,
      });

      if (!res.ok) throw new Error('Update failed');
      
      const data = await res.json();
      toast.success('Profile updated successfully!');
      
      if (data.photo_url) {
        setPhotoUrl(data.photo_url);
        setPhotoFile(null);
      }
    } catch (err: any) {
      toast.error(err.message || 'Error updating profile');
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleBankUpdate = () => {
    toast.success('Bank details updated successfully!');
  };

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-display font-bold">Settings <span className="text-xs text-muted-foreground ml-2">v2.1-LIVE-Pricer</span></h1>
          <p className="text-muted-foreground">Manage milk pricing, bank details, and your public profile</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Admin Profile Settings */}
          <Card className="gradient-card lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="h-5 w-5 text-primary" />
                Public Profile (About Us)
              </CardTitle>
              <CardDescription>This information will be visible to everyone on the Landing Page</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className="w-full md:w-32 flex flex-col items-center gap-3">
                  <div className="w-32 h-32 rounded-full bg-secondary overflow-hidden border-4 border-white shadow-lg flex items-center justify-center relative">
                    {photoFile ? (
                      <img src={URL.createObjectURL(photoFile)} alt="Preview" className="w-full h-full object-cover" />
                    ) : photoUrl ? (
                      <img src={photoUrl.startsWith('http') ? photoUrl : `${API_BASE}${photoUrl}`} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <ImagePlus className="h-10 w-10 text-muted-foreground opacity-50" />
                    )}
                  </div>
                  <div>
                    <Label htmlFor="photo" className="cursor-pointer text-sm font-medium text-primary hover:underline">
                      Change Photo
                    </Label>
                    <Input 
                      id="photo" 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                    />
                  </div>
                </div>
                
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                  <div className="space-y-2">
                    <Label>Center/Admin Name</Label>
                    <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>City / District</Label>
                    <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="e.g. Pune" />
                  </div>
                  <div className="space-y-2">
                    <Label>State</Label>
                    <Input value={state} onChange={(e) => setState(e.target.value)} placeholder="e.g. Maharashtra" />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Full Address</Label>
                    <Textarea 
                      value={address} 
                      onChange={(e) => setAddress(e.target.value)} 
                      placeholder="Detailed address of your Dairy center..." 
                      className="min-h-[80px]"
                    />
                  </div>
                </div>
              </div>
              <Button onClick={handleProfileUpdate} className="w-full md:w-auto gradient-hero" disabled={updatingProfile} >
                {updatingProfile ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                Save Profile
              </Button>
            </CardContent>
          </Card>

          <Card className="gradient-card lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-primary" />
                Dynamic Milk Pricing & Quality Standards
              </CardTitle>
              <CardDescription>Configure base/normal prices, quality benchmarks, and bonus/deduction rates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Cow & Buffalo Pricing Grid */}
              <div className="grid md:grid-cols-2 gap-8">
                {/* Cow Milk Pricing */}
                <div className="space-y-4 p-4 rounded-xl bg-secondary/30 border border-primary/10">
                  <h3 className="font-bold flex items-center gap-2 text-primary">
                    <Milk className="h-4 w-4" /> Cow Milk Constants
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Base Price (Min ₹)</Label>
                      <Input type="number" value={cowBasePrice} onChange={(e) => setCowBasePrice(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Normal Price (Std ₹)</Label>
                      <Input type="number" value={cowNormalPrice} onChange={(e) => setCowNormalPrice(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Fat Standard (%)</Label>
                      <Input type="number" value={cowFatStd} onChange={(e) => setCowFatStd(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">SNF Standard (%)</Label>
                      <Input type="number" value={cowSnfStd} onChange={(e) => setCowSnfStd(e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* Buffalo Milk Pricing */}
                <div className="space-y-4 p-4 rounded-xl bg-secondary/30 border border-dairy-earth/10">
                  <h3 className="font-bold flex items-center gap-2 text-dairy-earth">
                    <Milk className="h-4 w-4" /> Buffalo Milk Constants
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Base Price (Min ₹)</Label>
                      <Input type="number" value={buffaloBasePrice} onChange={(e) => setBuffaloBasePrice(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Normal Price (Std ₹)</Label>
                      <Input type="number" value={buffaloNormalPrice} onChange={(e) => setBuffaloNormalPrice(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Fat Standard (%)</Label>
                      <Input type="number" value={buffaloFatStd} onChange={(e) => setBuffaloFatStd(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">SNF Standard (%)</Label>
                      <Input type="number" value={buffaloSnfStd} onChange={(e) => setBuffaloSnfStd(e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Bonus & Water Logic */}
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="font-bold">Bonus Rates (High Quality)</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Fat Bonus (₹ per 1%)</Label>
                      <Input type="number" value={fatBonusRate} onChange={(e) => setFatBonusRate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">SNF Bonus (₹ per 1%)</Label>
                      <Input type="number" value={snfBonusRate} onChange={(e) => setSnfBonusRate(e.target.value)} />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-bold">Water / Adulteration Handling</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Water Threshold (%)</Label>
                      <Input type="number" value={waterThreshold} onChange={(e) => setWaterThreshold(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Deduction (₹ per Liter)</Label>
                      <Input type="number" value={waterDeductionRate} onChange={(e) => setWaterDeductionRate(e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col md:flex-row gap-6 items-end justify-between border-t pt-6">
                <div className="flex-1 w-full max-w-md p-4 rounded-lg bg-secondary/50 space-y-2">
                  <p className="text-sm font-medium">Payment Distribution</p>
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div>
                      <p className="text-lg font-bold text-primary">{dist?.farmer_share || 90}%</p>
                      <p className="text-muted-foreground">Farmer</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-dairy-earth">{dist?.admin_cut || 6}%</p>
                      <p className="text-muted-foreground">Admin</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold text-muted-foreground">{dist?.company_cut || 4}%</p>
                      <p className="text-muted-foreground">Company</p>
                    </div>
                  </div>
                </div>
                
                <Button onClick={handlePriceUpdate} className="w-full md:w-auto min-w-[200px] gradient-hero h-12" disabled={updatingPrice}>
                  {updatingPrice ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                  Save Pricing System
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Bank Details */}
          <Card className="gradient-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Bank Details
              </CardTitle>
              <CardDescription>Your bank account for commission deposits</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Bank Name</Label>
                <Input
                  placeholder="e.g., State Bank of India"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Account Holder Name</Label>
                <Input
                  placeholder="As per bank records"
                  value={accountHolder}
                  onChange={(e) => setAccountHolder(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Account Number</Label>
                <Input
                  placeholder="Enter account number"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>IFSC Code</Label>
                <Input
                  placeholder="e.g., SBIN0001234"
                  value={ifscCode}
                  onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                />
              </div>

              <Button onClick={handleBankUpdate} className="w-full gradient-hero">
                <Save className="h-4 w-4 mr-2" />
                Save Bank Details
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
