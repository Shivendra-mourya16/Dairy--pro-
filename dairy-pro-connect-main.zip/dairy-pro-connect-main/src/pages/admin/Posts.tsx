import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Newspaper, ImagePlus, Loader2, Send } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE, safeFetch } from '@/lib/api';

export default function AdminPosts() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  // Post Form State
  const [content, setContent] = useState('');
  const [mediaFile, setMediaFile] = useState<File | null>(null);

  useEffect(() => {
    if (user?.id) {
      fetchPosts();
    }
  }, [user]);

  const fetchPosts = async () => {
    try {
      const res = await safeFetch(`/api/posts?admin_id=${user?.id}`);
      const data = await res.json();
      setPosts(data);
    } catch (err) {
      console.error('Failed to fetch posts:', err);
      toast.error('Failed to load recent posts');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      toast.error('Post content is required');
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('admin_id', user!.id.toString());
      formData.append('content', content);
      if (mediaFile) {
        formData.append('media', mediaFile);
      }

      // We don't use safeFetch here as FormData behaves differently with caching/headers in standard wrappers
      const res = await fetch(`${API_BASE}/api/admin/posts`, {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) throw new Error('Failed to create post');
      
      toast.success('Post published successfully!');
      setContent('');
      setMediaFile(null);
      
      // Reset file input UI
      const fileInput = document.getElementById('media-upload') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
      
      fetchPosts();
    } catch (err: any) {
      toast.error(err.message || 'Error publishing post');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DashboardLayout role="admin">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-display font-bold">Organization Updates</h1>
          <p className="text-muted-foreground">Post updates, free supplements, or announcements for your farmers</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Create Post Form */}
          <div className="lg:col-span-1">
            <Card className="gradient-card sticky top-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Newspaper className="h-5 w-5 text-primary" />
                  Create New Post
                </CardTitle>
                <CardDescription>Share activity with your network</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="content">Post Content</Label>
                    <Textarea 
                      id="content"
                      placeholder="Write about recent distributions, camps, or updates..."
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      className="min-h-[120px]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="media-upload">Add Image/Video (Optional)</Label>
                    <div className="flex items-center gap-3">
                      <Input 
                        id="media-upload"
                        type="file" 
                        accept="image/*,video/mp4,video/webm"
                        onChange={(e) => setMediaFile(e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full gradient-hero" disabled={submitting}>
                    {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                    Publish Post
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Posts Feed */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-xl font-bold mb-4">Your Recent Posts</h2>
            
            {loading ? (
              <div className="flex items-center justify-center p-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : posts.length === 0 ? (
              <Card className="bg-secondary/20">
                <CardContent className="flex flex-col items-center py-12 text-muted-foreground">
                  <ImagePlus className="h-12 w-12 mb-4 opacity-50" />
                  <p>You haven't published any posts yet.</p>
                </CardContent>
              </Card>
            ) : (
              posts.map((post) => (
                <Card key={post.id} className="overflow-hidden">
                  {post.media_url && (
                    <div className="w-full max-h-80 bg-black flex items-center justify-center overflow-hidden">
                      {post.media_type === 'video' ? (
                        <video 
                          src={post.media_url.startsWith('http') ? post.media_url : `${API_BASE}${post.media_url}`} 
                          controls className="w-full h-auto max-h-80 object-contain" 
                        />
                      ) : (
                        <img 
                          src={post.media_url.startsWith('http') ? post.media_url : `${API_BASE}${post.media_url}`} 
                          alt="Post media" 
                          className="w-full h-auto max-h-80 object-cover"
                        />
                      )}
                    </div>
                  )}
                  <CardContent className="p-6">
                    <p className="whitespace-pre-wrap">{post.content}</p>
                    <p className="text-xs text-muted-foreground mt-4 border-t pt-2">
                      Published on {post.created_at}
                    </p>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
