import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Milk, Banknote, TrendingUp, Package, PiggyBank, Loader2, ArrowUpRight, Plus, Users2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { API_BASE } from '@/lib/api';
import { MilkSummary } from '@/components/dashboard/MilkSummary';
import { GrowthSummary } from '@/components/dashboard/GrowthSummary';
import { RevenueGauge } from '@/components/dashboard/RevenueGauge';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/admin/stats?admin_id=${user?.id}`);
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout role="admin">
        <div className="flex h-[60vh] items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-muted-foreground animate-pulse font-medium">Loading Dashboard Data...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout role="admin">
      <div className="space-y-8 pb-10">
        {/* Top Navigation / App Bar */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-black tracking-tight text-gray-900">Admin Dashboard</h1>
            <p className="text-muted-foreground font-medium">Welcome back, {user?.full_name || 'Admin'}!</p>
          </div>
          <div className="flex items-center gap-3">
             <button 
                onClick={() => navigate('/admin/milk-collection')}
                className="p-2 border border-blue-200 rounded-full hover:bg-blue-50 transition-colors shadow-sm relative group"
                title="Quick Add Milk"
             >
                <div className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse" />
                <Plus className="w-5 h-5 text-blue-600" />
             </button>
             <button 
                onClick={() => navigate('/admin/settings')}
                className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-100 to-purple-100 border border-white flex items-center justify-center overflow-hidden shadow-md hover:scale-105 transition-transform"
                title="Profile Settings"
             >
                <Users2 className="w-6 h-6 text-blue-500" />
             </button>
          </div>
        </div>

        {/* Top Row Circles/Circles Actions (Inspired by Image) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button onClick={() => navigate('/admin/users')} className="flex flex-col items-center gap-3 group">
            <div className="w-24 h-24 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center group-hover:border-blue-400 group-hover:bg-blue-50 transition-all">
              <Plus className="w-8 h-8 text-gray-400 group-hover:text-blue-500 group-hover:rotate-90 transition-all" />
            </div>
            <p className="font-bold text-gray-700">Distributor</p>
          </button>
          <button onClick={() => navigate('/admin/milk-collection')} className="flex flex-col items-center gap-3 group">
            <div className="w-24 h-24 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center group-hover:border-green-400 group-hover:bg-green-50 transition-all">
              <Plus className="w-8 h-8 text-gray-400 group-hover:text-green-500 group-hover:rotate-90 transition-all" />
            </div>
            <p className="font-bold text-gray-700">Import</p>
          </button>
          <button className="flex flex-col items-center gap-3 group">
            <div className="w-24 h-24 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center group-hover:border-purple-400 group-hover:bg-purple-50 transition-all">
              <Plus className="w-8 h-8 text-gray-400 group-hover:text-purple-500 group-hover:rotate-90 transition-all" />
            </div>
            <p className="font-bold text-gray-700">Team</p>
          </button>
        </div>

        {/* Visual Summaries Section (Milk Summary + Growth Summary + Gauge) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 grid md:grid-cols-2 gap-8">
             <MilkSummary 
               importLiters={stats?.import_volume || 0} 
               distributionLiters={stats?.distribution_volume || 0} 
             />
             <GrowthSummary 
               importCount={stats?.import_volume || 0}
               locationCount={stats?.location_count || 0}
               distributorCount={stats?.verified_users || 0}
               routeCount={Math.round((stats?.location_count || 0) * 0.6)} // Simulated routes based on locations
             />
          </div>
          <div className="flex flex-col gap-8">
             <RevenueGauge 
               current={stats?.monthly_revenue || 0} 
               target={stats?.revenue_target || 1000000} 
             />
             
             {/* Small Progress Bars Card (from image) */}
             <Card className="rounded-3xl border-white/20 bg-white/50 backdrop-blur-md shadow-xl overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl font-bold">Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm font-bold text-gray-600">
                      <span>Production</span>
                      <span className="text-blue-500">{stats?.production_pct || 0}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${stats?.production_pct || 0}%` }} />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm font-bold text-gray-600">
                      <span>Marketing</span>
                      <span className="text-green-500">{stats?.marketing_pct || 0}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500 transition-all duration-1000" style={{ width: `${stats?.marketing_pct || 0}%` }} />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm font-bold text-gray-600">
                      <span>Service</span>
                      <span className="text-yellow-500">{stats?.service_pct || 0}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 transition-all duration-1000" style={{ width: `${stats?.service_pct || 0}%` }} />
                    </div>
                  </div>
                </CardContent>
             </Card>
          </div>
        </div>

        {/* Existing Content Grid (Recent Collections & Quick Actions) */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Collections */}
          <Card className="rounded-3xl border-none shadow-xl bg-white overflow-hidden group">
            <CardHeader className="bg-gray-50/50">
              <CardTitle className="flex items-center gap-2 text-xl font-black tracking-tight">
                <Milk className="h-6 w-6 text-blue-500 group-hover:animate-bounce" />
                Recent Collections
              </CardTitle>
              <CardDescription className="font-medium">Latest milk collection entries</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {stats?.recent_collections?.length === 0 ? (
                  <div className="text-center py-12 flex flex-col items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center">
                      <Milk className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-muted-foreground font-medium">No collections recorded yet today.</p>
                  </div>
                ) : (
                  stats?.recent_collections?.map((collection: any) => (
                    <div key={collection.id} className="flex items-center justify-between p-4 rounded-2xl bg-gray-50 border border-gray-100/50 hover:border-blue-100 hover:bg-blue-50/30 transition-all group/item">
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-gray-800">{collection.farmer}</p>
                        <p className="text-sm text-muted-foreground font-medium">
                          {collection.type} • {collection.liters}L • {collection.fat}% fat
                        </p>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <p className="font-black text-blue-600">₹{collection.amount?.toLocaleString()}</p>
                        <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-gray-300 group-hover/item:text-blue-500 shadow-sm">
                           <ArrowUpRight size={16} />
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="rounded-3xl border-none shadow-xl bg-white overflow-hidden">
            <CardHeader className="bg-gray-50/50">
              <CardTitle className="text-xl font-black tracking-tight">Quick Actions</CardTitle>
              <CardDescription className="font-medium">Common tasks and shortcuts</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4 pt-6">
              <button
                onClick={() => navigate('/admin/milk-collection')}
                className="p-6 rounded-3xl bg-blue-50/50 border border-blue-100 hover:bg-blue-100/50 transition-all hover:scale-[1.02] active:scale-[0.98] text-left group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center mb-4 shadow-sm group-hover:rotate-6 transition-transform">
                  <Milk className="h-6 w-6 text-blue-500" />
                </div>
                <p className="font-black text-gray-800">Add Collection</p>
                <p className="text-xs text-muted-foreground font-medium mt-1">Record new milk entry</p>
              </button>
              <button
                onClick={() => navigate('/admin/payments')}
                className="p-6 rounded-3xl bg-amber-50/50 border border-amber-100 hover:bg-amber-100/50 transition-all hover:scale-[1.02] active:scale-[0.98] text-left group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center mb-4 shadow-sm group-hover:animate-pulse transition-transform">
                  <Banknote className="h-6 w-6 text-amber-500" />
                </div>
                <p className="font-black text-gray-800">Payments</p>
                <p className="text-xs text-muted-foreground font-medium mt-1">Farmer payouts</p>
              </button>
              <button
                onClick={() => navigate('/admin/supplements')}
                className="p-6 rounded-3xl bg-emerald-50/50 border border-emerald-100 hover:bg-emerald-100/50 transition-all hover:scale-[1.02] active:scale-[0.98] text-left group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center mb-4 shadow-sm group-hover:rotate-12 transition-transform">
                  <Package className="h-6 w-6 text-emerald-500" />
                </div>
                <p className="font-black text-gray-800">Supplements</p>
                <p className="text-xs text-muted-foreground font-medium mt-1">Feed distribution</p>
              </button>
              <button
                onClick={() => navigate('/admin/cattle')}
                className="p-6 rounded-3xl bg-rose-50/50 border border-rose-100 hover:bg-rose-100/50 transition-all hover:scale-[1.02] active:scale-[0.98] text-left group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center mb-4 shadow-sm group-hover:scale-110 transition-transform">
                  <PiggyBank className="h-6 w-6 text-rose-500" />
                </div>
                <p className="font-black text-gray-800">Cattle Market</p>
                <p className="text-xs text-muted-foreground font-medium mt-1">View listings</p>
              </button>
            </CardContent>
          </Card>
        </div>

        {/* Improved Price Info */}
        <Card className="rounded-3xl border-none shadow-xl bg-gradient-to-r from-blue-600 to-indigo-700 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white text-xl font-black">
              <TrendingUp className="h-6 w-6" />
              Live Pricing Policy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-5 gap-4">
              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center">
                <p className="text-2xl font-black text-white">₹{stats?.cow_price || 45}</p>
                <p className="text-[10px] uppercase font-bold text-blue-100">Cow (L)</p>
              </div>
              <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center">
                <p className="text-2xl font-black text-white">₹{stats?.buffalo_price || 65}</p>
                <p className="text-[10px] uppercase font-bold text-blue-100">Buffalo (L)</p>
              </div>
              <div className="p-4 rounded-2xl bg-white/20 border border-white/30 text-center">
                <p className="text-2xl font-black text-white">{stats?.farmer_share || 90}%</p>
                <p className="text-[10px] uppercase font-bold text-white/80">Farmer Share</p>
              </div>
              <div className="p-4 rounded-2xl bg-white/10 text-center">
                <p className="text-2xl font-black text-white/90">{stats?.admin_cut || 6}%</p>
                <p className="text-[10px] uppercase font-bold text-blue-100">Admin</p>
              </div>
              <div className="p-4 rounded-2xl bg-white/10 text-center">
                <p className="text-2xl font-black text-white/90">{stats?.company_cut || 4}%</p>
                <p className="text-[10px] uppercase font-bold text-blue-100">Company</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
