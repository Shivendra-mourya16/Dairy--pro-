export type UserRole = 'admin' | 'user';

export type VerificationStatus = 'pending' | 'verified';

export type MilkType = 'cow' | 'buffalo';

export type StartupPlan = 'basic' | 'advanced';

export interface Profile {
  id: string;
  full_name: string;
  mobile: string;
  mobile_number?: string;
  email: string;
  aadhaar?: string;
  pan?: string;
  aadhaar_number?: string;
  pan_number?: string;
  address?: string;
  mobile_verified: boolean;
  email_verified: boolean;
  aadhaar_verified: boolean;
  pan_verified: boolean;
  profile_completed: boolean;
  startup_plan?: StartupPlan;
  payment_completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserRoleRecord {
  id: string;
  user_id: string;
  role: UserRole;
}

export interface BankDetails {
  id: string;
  user_id: string;
  bank_name: string;
  account_holder_name: string;
  account_number: string;
  ifsc_code: string;
  created_at: string;
  updated_at: string;
}

export interface MilkRecord {
  id: string;
  user_id: string;
  admin_id?: string;
  milk_type: MilkType;
  weight_liters: number;
  fat_percentage: number;
  snf_percentage: number;
  water_quantity: number;
  price_per_liter: number;
  total_amount: number;
  user_payout: number;
  admin_cut: number;
  company_cut: number;
  record_date: string;
  created_at: string;
}

export interface Payment {
  id: string;
  user_id: string;
  milk_record_id?: string;
  amount: number;
  payment_type: string;
  status: string;
  payment_date: string;
  created_at: string;
}

export interface CattleListing {
  id: string;
  user_id: string;
  photo_url?: string;
  cattle_type: string;
  age_years: number;
  age_months: number;
  number_of_calves: number;
  medical_records?: string;
  address: string;
  price: number;
  description?: string;
  is_sold: boolean;
  created_at: string;
  updated_at: string;
  buyer?: {
    name: string;
    mobile: string;
    address?: string;
  };
}

export interface Supplement {
  id: string;
  user_id: string;
  admin_id?: string;
  supplement_name: string;
  quantity: number;
  unit: string;
  is_free: boolean;
  price: number;
  distribution_date: string;
  created_at: string;
}

export interface MilkPriceSettings {
  id: string;
  price_per_liter: number;
  company_cut_percentage: number;
  admin_cut_percentage: number;
  user_payout_percentage: number;
  updated_by?: string;
  created_at: string;
  updated_at: string;
}

export interface AuthUser {
  id: string;
  email: string;
  profile?: Profile;
  role?: UserRole;
}
