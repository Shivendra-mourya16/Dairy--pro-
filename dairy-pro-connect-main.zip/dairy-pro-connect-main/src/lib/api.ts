// Central API configuration
let rawApiUrl = import.meta.env.VITE_API_URL || '';

// Ensure URL has protocol if it's a remote host
if (rawApiUrl && !rawApiUrl.startsWith('http')) {
    rawApiUrl = `https://${rawApiUrl}`;
}

// Helper to trim trailing slashes
const trimSlash = (url: string) => url?.replace(/\/+$/, '');

export const API_BASE = trimSlash(rawApiUrl);

export function getImageUrl(path: string | null | undefined): string | null {
    if (!path) return null;
    if (path.startsWith('http')) return path; // Return as-is if it's already a full URL (Cloudinary)
    
    // For local uploads, ensure path starts with a slash
    const normalizedPath = path.startsWith('/') ? path : `/${path}`;
    return `${API_BASE}${normalizedPath}`;
}

if (!API_BASE) {
    console.warn('⚠️ VITE_API_URL is NOT defined. Using local path (might cause JSON errors on Vercel).');
}

console.log('Dairy Pro API initialized with base:', API_BASE);

// Safe fetch with auto-retry
export async function safeFetch(url: string, options?: RequestInit, retries = 3): Promise<Response> {
    const fullUrl = url.startsWith('http') ? url : `${API_BASE}${url}`;

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            console.log(`[API] Fetching: ${fullUrl} (Attempt ${attempt})`);
            const res = await fetch(fullUrl, options);

            // On Vercel, we expect JSON or actual errors
            if (res.ok) {
                return res;
            }

            const contentType = res.headers.get('content-type');
            if (contentType && !contentType.includes('application/json')) {
                console.error(`[API] Received non-JSON response from ${fullUrl}:`, contentType);
            }

            if (attempt < retries) {
                console.warn(`[safeFetch] Request failed (${res.status}), retrying... Attempt ${attempt}/${retries}`);
                await new Promise(r => setTimeout(r, 2000));
            } else {
                return res;
            }
        } catch (err: any) {
            console.error(`[safeFetch] Attempt ${attempt} failed for ${fullUrl}:`, err.message);
            if (attempt === retries) {
                throw new Error(`Connection failed: ${err.message}`);
            }
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    throw new Error('Connection timeout.');
}
