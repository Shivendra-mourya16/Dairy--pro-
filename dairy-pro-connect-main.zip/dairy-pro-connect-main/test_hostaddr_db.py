import os
import psycopg2
from dotenv import load_dotenv

load_dotenv()
# The original URL
original_url = os.getenv('DATABASE_URL')
# Resolved IP
ip = "13.228.184.17"

# Append hostaddr to the URL
if "?" in original_url:
    url_with_ip = f"{original_url}&hostaddr={ip}"
else:
    url_with_ip = f"{original_url}?hostaddr={ip}"

try:
    print(f"Connecting with hostaddr-patched URL...")
    conn = psycopg2.connect(url_with_ip)
    print("Connection successful!")
    cur = conn.cursor()
    cur.execute("SELECT version();")
    print(cur.fetchone())
    cur.close()
    conn.close()
except Exception as e:
    print("Connection failed!")
    print(e)
