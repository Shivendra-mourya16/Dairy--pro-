import os
import sqlalchemy
from sqlalchemy import create_engine
from dotenv import load_dotenv
import sys

# Add root to path to import app and extensions
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.app import app
from backend.extensions import db

load_dotenv()
url = os.getenv('DATABASE_URL')

# Neon IP for ap-southeast-1 (AWS)
ip = "13.228.46.236"

# Create a custom engine that uses the IP but keeps the host for SSL
# In SQLAlchemy 2.0+, we use connect_args for psycopg2
engine = create_engine(
    url,
    connect_args={"hostaddr": ip}
)

print(f"[Fix] Connecting to DB via IP {ip}...")
with app.app_context():
    try:
        # We need to bind the metadata to our new engine
        db.metadata.create_all(bind=engine)
        print("✅ Migration successful via hostaddr patch!")
        print("Tables created in Neon.")
    except Exception as e:
        print("❌ Migration failed even with hostaddr patch:")
        print(e)
