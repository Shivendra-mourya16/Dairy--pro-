
import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text

env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(env_path)

db_url = os.getenv('DATABASE_URL')
if not db_url:
    print("DATABASE_URL not found")
    exit(1)

if db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql://", 1)

engine = create_engine(db_url)

with engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
    try:
        conn.execute(text('SELECT cow_milk_price FROM app_settings LIMIT 1'))
        print("Columns already exist")
    except Exception:
        print("Updating app_settings table...")
        try:
            conn.execute(text('ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS cow_milk_price DOUBLE PRECISION DEFAULT 45.0'))
            print("Added cow_milk_price")
            conn.execute(text('ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS buffalo_milk_price DOUBLE PRECISION DEFAULT 65.0'))
            print("Added buffalo_milk_price")
            try:
                conn.execute(text('ALTER TABLE app_settings DROP COLUMN IF EXISTS milk_price_per_liter'))
                print("Dropped milk_price_per_liter")
            except Exception as e:
                print(f"Note: Could not drop column: {e}")
            print("Table updated successfully!")
        except Exception as e:
            print(f"Error during migration: {e}")
