from app import app
from extensions import db
from models import Admin, User

with app.app_context():
    admins = Admin.query.all()
    print("--- Admins ---")
    for a in admins:
        print(f"ID: {a.id}, Name: {a.full_name}, Email: {a.email}, Verified: {a.is_verified}")
    
    users = User.query.all()
    print("\n--- Users ---")
    for u in users:
        print(f"ID: {u.id}, Name: {u.full_name}, Email: {u.email}, Verified: {u.is_verified}")
