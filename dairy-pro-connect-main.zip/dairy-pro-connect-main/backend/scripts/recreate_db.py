from app import app
from extensions import db
import models

def recreate_db():
    with app.app_context():
        print("Dropping all tables...")
        db.drop_all()
        print("Creating all tables with new schema...")
        db.create_all()
        
        # Add default settings
        from models import AppSettings
        if not AppSettings.query.first():
            db.session.add(AppSettings())
            db.session.commit()
            
        print("Database recreated successfully! All columns are now up to date.")

if __name__ == "__main__":
    recreate_db()
