from app import app
from extensions import db
from models import User, Admin, BankDetail, MilkRecord, Payment, Supplement, CattleListing, AppSettings

def reset_data():
    with app.app_context():
        # Delete data in correct order to avoid foreign key errors
        print("Clearing data...")
        db.session.query(MilkRecord).delete()
        db.session.query(Payment).delete()
        db.session.query(BankDetail).delete()
        db.session.query(Supplement).delete()
        db.session.query(CattleListing).delete()
        db.session.query(User).delete()
        db.session.query(Admin).delete()
        db.session.query(AppSettings).delete()
        
        # Add default settings back
        db.session.add(AppSettings())
        
        db.session.commit()
        print("Database cleared successfully! Tables are intact.")

if __name__ == "__main__":
    reset_data()
