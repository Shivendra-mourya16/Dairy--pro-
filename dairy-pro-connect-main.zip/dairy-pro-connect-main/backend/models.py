from extensions import db
from datetime import datetime
import json

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=True) # Linked Admin
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    mobile = db.Column(db.String(15), unique=True, nullable=False)
    address = db.Column(db.Text)
    role = db.Column(db.String(20), default='user')
    is_verified = db.Column(db.Boolean, default=False)
    otp = db.Column(db.String(6))
    otp_expiry = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    aadhaar_number = db.Column(db.String(20), nullable=True)
    pan_number = db.Column(db.String(20), nullable=True)
    
    bank_details = db.relationship('BankDetail', backref='user', uselist=False)
    milk_records = db.relationship('MilkRecord', backref='farmer', lazy=True)
    supplements = db.relationship('Supplement', backref='farmer', lazy=True)
    payments = db.relationship('Payment', backref='user', lazy=True)
    cattle_listings = db.relationship('CattleListing', foreign_keys='CattleListing.seller_id', backref='seller', lazy=True)

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    mobile = db.Column(db.String(15), unique=True, nullable=False)
    role = db.Column(db.String(20), default='admin')
    is_verified = db.Column(db.Boolean, default=False)
    otp = db.Column(db.String(6))
    otp_expiry = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # New Profile Fields for About Us
    address = db.Column(db.Text, nullable=True)
    city = db.Column(db.String(100), nullable=True)
    state = db.Column(db.String(100), nullable=True)
    photo_url = db.Column(db.String(500), nullable=True)
    aadhaar_number = db.Column(db.String(20), nullable=True)
    pan_number = db.Column(db.String(20), nullable=True)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    media_url = db.Column(db.String(500), nullable=True)
    media_type = db.Column(db.String(20), nullable=True) # 'image' or 'video'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    admin = db.relationship('Admin', backref='posts', lazy=True)

class BankDetail(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    bank_name = db.Column(db.String(100))
    account_holder = db.Column(db.String(100))
    account_number = db.Column(db.String(50))
    ifsc_code = db.Column(db.String(20))

class MilkRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    farmer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    type = db.Column(db.String(20)) # Cow, Buffalo
    weight = db.Column(db.Float, nullable=False)
    fat = db.Column(db.Float, nullable=False)
    snf = db.Column(db.Float, nullable=False)
    water = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Float)
    farmer_payout = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending') # pending, paid
    
    # New Pricing Fields
    quality = db.Column(db.String(20)) # Low, Normal, High
    fat_bonus = db.Column(db.Float, default=0.0)
    snf_bonus = db.Column(db.Float, default=0.0)
    water_deduction = db.Column(db.Float, default=0.0)

class Supplement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    farmer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), default='kg')
    price = db.Column(db.Float, default=0.0)
    is_free = db.Column(db.Boolean, default=False)
    status = db.Column(db.String(20), default='requested') # requested, delivered
    date = db.Column(db.DateTime, default=datetime.utcnow)

class CattleListing(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=True) # Cached admin_id
    type = db.Column(db.String(100), nullable=False)
    age = db.Column(db.String(50))
    calves = db.Column(db.Integer)
    milk_yield = db.Column(db.Float)
    price = db.Column(db.Float, nullable=False)
    medical_records = db.Column(db.Text)
    location = db.Column(db.String(255))
    status = db.Column(db.String(20), default='available') # available, booked, sold
    image_url = db.Column(db.String(500))
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='cattle_bought', lazy=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=True) # Payment receiver/manager
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(50)) # PAYOUT, SUPPLEMENT, CATTLE_ADVANCE
    transaction_id = db.Column(db.String(100), unique=True)
    mode = db.Column(db.String(50)) # UPI, Bank Transfer
    status = db.Column(db.String(20), default='completed')
    date = db.Column(db.DateTime, default=datetime.utcnow)
    receipt_data = db.Column(db.Text) # JSON string with all receipt details

class AppSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    
    # Cow Milk Pricing
    cow_base_price = db.Column(db.Float, default=40.0)
    cow_normal_price = db.Column(db.Float, default=45.0)
    cow_fat_std = db.Column(db.Float, default=3.5)
    cow_snf_std = db.Column(db.Float, default=8.0)
    
    # Buffalo Milk Pricing
    buffalo_base_price = db.Column(db.Float, default=55.0)
    buffalo_normal_price = db.Column(db.Float, default=65.0)
    buffalo_fat_std = db.Column(db.Float, default=5.5)
    buffalo_snf_std = db.Column(db.Float, default=9.0)
    
    # Bonus & Deduction Rates
    fat_bonus_rate = db.Column(db.Float, default=7.0) # per 1% fat
    snf_bonus_rate = db.Column(db.Float, default=1.5) # per 1% snf
    water_threshold = db.Column(db.Float, default=10.0) # in % or Liters? Let's use % of total
    water_deduction_rate = db.Column(db.Float, default=3.0) # per liter
    
    # Legend/Backwards Compatibility
    cow_milk_price = db.Column(db.Float, default=45.0) # Still here to avoid breakdown
    buffalo_milk_price = db.Column(db.Float, default=65.0)
    
    farmer_share_pct = db.Column(db.Float, default=90.0)
    admin_cut_pct = db.Column(db.Float, default=6.0)
    company_cut_pct = db.Column(db.Float, default=4.0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_name = db.Column(db.String(100), nullable=False)
    donor_phone = db.Column(db.String(15), nullable=True)
    amount = db.Column(db.Float, nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False) # The local admin chosen
    message = db.Column(db.Text)
    status = db.Column(db.String(20), default='completed') # completed, pending
    payment_mode = db.Column(db.String(50)) # UPI, Card, QR
    location = db.Column(db.String(255)) # City/Village, State
    date = db.Column(db.DateTime, default=datetime.utcnow)
    
    admin = db.relationship('Admin', backref='donations_list', lazy=True)
