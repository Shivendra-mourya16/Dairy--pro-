from app import app
from extensions import db
from sqlalchemy import text
import traceback

def add_column_if_not_exists(table, column_name, column_type):
    try:
        with db.engine.connect() as conn:
            conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column_name} {column_type}"))
            conn.commit()
            print(f"Successfully added column '{column_name}' to '{table}'")
    except Exception as e:
        print(f"Skipped adding '{column_name}' to '{table}' (might already exist): {e}")

if __name__ == '__main__':
    with app.app_context():
        try:
            print("Running database migrations...")
            add_column_if_not_exists('admin', 'address', 'TEXT')
            add_column_if_not_exists('admin', 'city', 'VARCHAR(100)')
            add_column_if_not_exists('admin', 'state', 'VARCHAR(100)')
            add_column_if_not_exists('admin', 'photo_url', 'VARCHAR(500)')
            
            print("Creating new tables (like Post)...")
            db.create_all()
            print("Migration completed successfully!")
        except Exception as e:
            print("Fatal Error during migration:")
            traceback.print_exc()
