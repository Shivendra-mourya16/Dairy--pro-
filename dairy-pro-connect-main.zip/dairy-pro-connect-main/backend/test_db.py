import os
from dotenv import load_dotenv
load_dotenv()
database_url = os.getenv('DATABASE_URL')
if database_url and database_url.startswith('postgres://'):
    database_url = database_url.replace('postgres://', 'postgresql://', 1)

from sqlalchemy import create_engine, text
engine = create_engine(database_url)
with engine.connect() as conn:
    res = conn.execute(text("SELECT email, mobile, address FROM \"user\" WHERE email = 'ayush.v.singh261104@gmail.com'"))
    print("User rows:")
    for row in res:
        print(f"email={row[0]}, mobile={row[1]}, address={row[2]}")
        
    res2 = conn.execute(text("SELECT email, mobile, address FROM admin WHERE email = 'ayush.v.singh261104@gmail.com'"))
    print("Admin rows:")
    for row in res2:
        print(f"email={row[0]}, mobile={row[1]}, address={row[2]}")
