from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from flask_mail import Mail, Message
from extensions import db
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid
import random
import io
import threading
import requests
import pandas as pd
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import json
import urllib.parse
import cloudinary
import cloudinary.uploader
from cloudinary.utils import cloudinary_url

load_dotenv()

# Cloudinary Configuration
cloudinary_name = os.getenv('CLOUDINARY_CLOUD_NAME')
cloudinary_key = os.getenv('CLOUDINARY_API_KEY')
cloudinary_secret = os.getenv('CLOUDINARY_API_SECRET')

if cloudinary_name and cloudinary_key and cloudinary_secret:
    cloudinary.config(
        cloud_name = cloudinary_name, 
        api_key = cloudinary_key, 
        api_secret = cloudinary_secret,
        secure = True
    )

app = Flask(__name__)

# Upload Configuration
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def upload_image(file):
    """Helper to upload to Cloudinary or fallback to local"""
    if not all([os.getenv('CLOUDINARY_CLOUD_NAME'), os.getenv('CLOUDINARY_API_KEY')]):
        # Fallback to Local Storage
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER)
        ext = file.filename.split('.')[-1]
        filename = f"{uuid.uuid4().hex}.{ext}"
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return f"/uploads/{filename}"
    
    try:
        upload_result = cloudinary.uploader.upload(file)
        return upload_result.get('secure_url')
    except Exception as e:
        print(f"[Cloudinary Error] {str(e)}")
        return None

@app.route('/')
def index():
    return jsonify({"status": "OK", "message": "Dairy Pro Backend is running."}), 200

# Relaxed CORS for mobile and cross-origin access
CORS(app, resources={r"/*": {
    "origins": "*",
    "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    "allow_headers": ["Content-Type", "Authorization"]
}})

# ✅ Always return JSON errors — never HTML
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found", "message": str(e)}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Server error", "message": str(e)}), 500

@app.errorhandler(Exception)
def handle_exception(e):
    return jsonify({"error": "Unexpected error", "message": str(e)}), 500

# Endpoints will now use the upload_image helper which handles Cloudinary fallbacks.

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_file(os.path.join(app.config['UPLOAD_FOLDER'], filename))

# Email Configuration
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', 'smtp-relay.brevo.com')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True') == 'True'
app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL', 'False') == 'True'
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', 'a33804001@smtp-brevo.com')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', 'xsmtpsib-b8430ff5a31cf84711e03c9521bcd053712ea6a0b220141f1121ea4ed44cb111-IWcJwAXoZkBc6W9z')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'ayushnewf@gmail.com')

mail = Mail(app)

def send_async_email(app, email_to, otp):
    """Sends email using Brevo REST API (Reliable on Railway)"""
    # Key provided by user
    api_key = os.getenv('BREVO_API_KEY', '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')
    sender_email = os.getenv('MAIL_DEFAULT_SENDER', 'ayushnewf@gmail.com')
    
    url = "https://api.brevo.com/v3/smtp/email"
    payload = {
        "sender": {"email": sender_email, "name": "Dairy Pro Connect"},
        "to": [{"email": email_to}],
        "subject": "Dairy Pro - Verification Code",
        "textContent": f"Your verification code for Dairy Pro Connect is: {otp}. This code is valid for 10 minutes."
    }
    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "api-key": api_key
    }

    with app.app_context():
        try:
            print(f"[BREVO API] Attempting to send OTP to {email_to}...")
            response = requests.post(url, json=payload, headers=headers)
            if response.status_code in [200, 201, 202]:
                print(f"[BREVO API] Email sent successfully to {email_to}")
            else:
                print(f"[BREVO API ERROR] Failed: {response.status_code} - {response.text}")
        except Exception as e:
            print(f"[BREVO API EXCEPTION] Error: {str(e)}")

@app.route('/api/health')
def simple_health():
    return jsonify({"status": "online", "message": "Backend is reachable"}), 200

@app.route('/api/db-check')
def database_check():
    try:
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        tables = inspector.get_table_names()
        return jsonify({
            "status": "connected",
            "tables_found": tables
        }), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/')
def home_health():
    return simple_health()

# Database Configuration — supports single DATABASE_URL (Neon) or individual vars
database_url = os.getenv('DATABASE_URL')
if not database_url:
    db_user = os.getenv('DB_USER')
    db_password = urllib.parse.quote_plus(os.getenv('DB_PASSWORD', ''))
    db_host = os.getenv('DB_HOST')
    db_name = os.getenv('DB_NAME')
    database_url = f"postgresql://{db_user}:{db_password}@{db_host}/{db_name}"

# Fix for Neon: replace postgres:// with postgresql://
if database_url and database_url.startswith('postgres://'):
    database_url = database_url.replace('postgres://', 'postgresql://', 1)

app.config['SQLALCHEMY_DATABASE_URI'] = database_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    "pool_pre_ping": True,
    "pool_recycle": 300,
}

db.init_app(app)

from models import User, Admin, BankDetail, MilkRecord, Payment, Supplement, CattleListing, AppSettings, Post, Donation
from sqlalchemy import text

with app.app_context():
    try:
        print("[DB] Creating all tables...")
        db.create_all()
        print("[DB] Applying Admin table migrations...")
        with db.engine.connect() as conn:
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS address TEXT;"))
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS city VARCHAR(100);"))
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS state VARCHAR(100);"))
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS photo_url VARCHAR(500);"))
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS aadhaar_number VARCHAR(20);"))
            conn.execute(text("ALTER TABLE admin ADD COLUMN IF NOT EXISTS pan_number VARCHAR(20);"))
            conn.execute(text("ALTER TABLE \"user\" ADD COLUMN IF NOT EXISTS aadhaar_number VARCHAR(20);"))
            conn.execute(text("ALTER TABLE \"user\" ADD COLUMN IF NOT EXISTS pan_number VARCHAR(20);"))
            
            # AppSettings New Fields
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS cow_base_price FLOAT DEFAULT 40.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS cow_normal_price FLOAT DEFAULT 45.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS cow_fat_std FLOAT DEFAULT 3.5;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS cow_snf_std FLOAT DEFAULT 8.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS buffalo_base_price FLOAT DEFAULT 55.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS buffalo_normal_price FLOAT DEFAULT 65.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS buffalo_fat_std FLOAT DEFAULT 5.5;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS buffalo_snf_std FLOAT DEFAULT 9.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS fat_bonus_rate FLOAT DEFAULT 7.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS snf_bonus_rate FLOAT DEFAULT 1.5;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS water_threshold FLOAT DEFAULT 10.0;"))
            conn.execute(text("ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS water_deduction_rate FLOAT DEFAULT 3.0;"))
            
            # MilkRecord New Fields
            conn.execute(text("ALTER TABLE milk_record ADD COLUMN IF NOT EXISTS quality VARCHAR(20);"))
            conn.execute(text("ALTER TABLE milk_record ADD COLUMN IF NOT EXISTS fat_bonus FLOAT DEFAULT 0.0;"))
            conn.execute(text("ALTER TABLE milk_record ADD COLUMN IF NOT EXISTS snf_bonus FLOAT DEFAULT 0.0;"))
            conn.execute(text("ALTER TABLE milk_record ADD COLUMN IF NOT EXISTS water_deduction FLOAT DEFAULT 0.0;"))
            
            conn.commit()
            print("[DB] Migration successful!")
    except Exception as e:
        print(f"[DB ERROR] Migration skipped or failed: {e}")

# --- PRIVATE DB ADMIN (Development Only) ---
from flask import render_template_string

@app.route('/api/db-admin')
def db_admin():
    try:
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        table_names = inspector.get_table_names()
        
        db_info = []
        for table in table_names:
            count = db.session.execute(text(f"SELECT COUNT(*) FROM \"{table}\"")).scalar()
            db_info.append({"name": table, "rows": count})
            
        html = """
        <html>
        <head>
            <title>Neon DB Admin</title>
            <style>
                body { font-family: sans-serif; background: #0f172a; color: white; padding: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #1e293b; border-radius: 8px; overflow: hidden; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #334155; }
                th { background: #3b82f6; color: white; }
                tr:hover { background: #334155; }
                h1 { color: #60a5fa; }
                .badge { background: #10b981; padding: 4px 8px; border-radius: 4px; font-size: 12px; }
            </style>
        </head>
        <body>
            <h1>Dairy Pro Connect - Database Admin</h1>
            <p>Direct Connection to Neon (Bypassing Dashboard Glitches)</p>
            <table>
                <tr><th>Table Name</th><th>Row Count</th><th>Status</th></tr>
                {% for table in info %}
                <tr>
                    <td>{{ table.name }}</td>
                    <td>{{ table.rows }}</td>
                    <td><span class="badge">Active</span></td>
                </tr>
                {% endfor %}
            </table>
        </body>
        </html>
        """
        return render_template_string(html, info=db_info)
    except Exception as e:
        return f"<h1>Error connecting to database</h1><p style='color:red'>{str(e)}</p>"

# --- Auth & Profile APIs ---

@app.route('/api/admins', methods=['GET'])
def get_verified_admins():
    try:
        admins = Admin.query.filter_by(is_verified=True).all()
        return jsonify([{
            "id": a.id, 
            "full_name": a.full_name,
            "city": getattr(a, 'city', None),
            "state": getattr(a, 'state', None),
            "address": getattr(a, 'address', None),
            "photo_url": getattr(a, 'photo_url', None)
        } for a in admins])
    except Exception as e:
        return jsonify({"error": str(e), "admins": []}), 500

@app.route('/api/auth/signup', methods=['POST'])
def signup():
    data = request.json
    role = data.get('role', 'user')
    
    # Validate required fields
    required = ['full_name', 'email', 'mobile', 'password']
    for field in required:
        if not data.get(field):
            return jsonify({"message": f"{field} is required"}), 400
    
    Model = Admin if role == 'admin' else User
    
    # ✅ Check both email AND mobile for duplicates across ALL roles (User & Admin)
    # If user exists but is NOT verified, we allow "re-signup" which just updates OTP
    existing_user = User.query.filter((User.email == data['email']) | (User.mobile == data['mobile'])).first()
    existing_admin = Admin.query.filter((Admin.email == data['email']) | (Admin.mobile == data['mobile'])).first()
    
    target = existing_admin if existing_admin else existing_user
    
    if target:
        if target.is_verified:
            # Check which field matched for better error message
            msg = "This email is already registered." if target.email == data['email'] else "This mobile number is already registered."
            return jsonify({"message": f"{msg} Please login instead."}), 400
        else:
            # User exists but not verified. Update OTP and proceed to verification step
            otp = str(random.randint(100000, 999999))
            target.otp = otp
            target.otp_expiry = datetime.utcnow() + timedelta(minutes=10)
            db.session.commit()
            
            print("\n" + "*"*50)
            print(f"!!! [DEBUG] OTP FOR {data['email']}: {otp} !!!")
            print("*"*50 + "\n")
            
            try:
                print(f"[AUTH] Preparing to send OTP via API to {data['email']}...")
                # Run in background to avoid blocking the main request
                threading.Thread(target=send_async_email, args=(app, data['email'], otp)).start()
                print(f"[SIGNUP] Brevo API thread dispatched for existing user.")
            except Exception as e:
                print(f"[AUTH ERROR] Failed to dispatch API mail: {str(e)}")
                
            return jsonify({"message": "OTP re-sent to email", "email": data['email']}), 201

    otp = str(random.randint(100000, 999999))
    
    # Create dictionary for common fields
    record_data = {
        "full_name": data['full_name'],
        "email": data['email'],
        "mobile": data['mobile'],
        "password": generate_password_hash(data['password']),
        "otp": otp,
        "otp_expiry": datetime.utcnow() + timedelta(minutes=10)
    }
    
    # Add admin_id if it's a user
    if role == 'user' and 'admin_id' in data:
        record_data["admin_id"] = data['admin_id']
        
    try:
        new_record = Model(**record_data)
        db.session.add(new_record)
        db.session.commit()
        print(f"[SIGNUP SUCCESS] Created {role} record with ID: {new_record.id}")
    except Exception as e:
        db.session.rollback()
        print(f"[SIGNUP ERROR] Database operation failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"message": f"Registration failed: {str(e)}"}), 500
    
    print("\n" + "*"*50)
    print(f"!!! [DEBUG] OTP FOR {data['email']} ({role}): {otp} !!!")
    print("*"*50 + "\n")
    
    try:
        print(f"[AUTH] Preparing to send OTP via API to {data['email']}...")
        # Run in background to avoid blocking
        threading.Thread(target=send_async_email, args=(app, data['email'], otp)).start()
        print(f"[SIGNUP] Brevo API thread dispatched for new user.")
    except Exception as e:
        print(f"[AUTH ERROR] Failed to dispatch API mail: {str(e)}")
    
    return jsonify({"message": "OTP sent to email", "email": data['email']}), 201

@app.route('/api/auth/resend-otp', methods=['POST'])
def resend_otp():
    data = request.json
    email = data.get('email')
    
    user = User.query.filter_by(email=email).first() or Admin.query.filter_by(email=email).first()
    if not user:
        return jsonify({"message": "User not found"}), 404
        
    if user.is_verified:
        return jsonify({"message": "User already verified"}), 400
        
    otp = str(random.randint(100000, 999999))
    user.otp = otp
    user.otp_expiry = datetime.utcnow() + timedelta(minutes=10)
    db.session.commit()
    
    print("\n" + "*"*50)
    print(f"!!! [DEBUG] RESEND OTP FOR {email}: {otp} !!!")
    print("*"*50 + "\n")
    
    try:
        threading.Thread(target=send_async_email, args=(app, email, otp)).start()
        print(f"[RESEND] Brevo API thread dispatched.")
    except Exception as e:
        print(f"Failed to dispatch API mail: {str(e)}")
        
    return jsonify({"message": "OTP re-sent to email"}), 200

@app.route('/api/auth/verify-otp', methods=['POST', 'OPTIONS'])
def verify_otp():
    if request.method == 'OPTIONS':
        return jsonify({"success": True}), 200
        
    try:
        data = request.json
        if not data:
            return jsonify({"message": "No data provided"}), 400
            
        email = data.get('email')
        otp = data.get('otp')
        
        print(f"[DEBUG] Verifying OTP for {email}, OTP provided: {otp}")
        
        # Check in User table
        user = User.query.filter_by(email=email).first()
        if user:
            print(f"[DEBUG] Found user in User table. DB OTP: {user.otp}")
            if str(user.otp) == str(otp):
                user.is_verified = True
                user.otp = None
                db.session.commit()
                return jsonify({
                    "message": "Verification successful",
                    "user": {"id": user.id, "full_name": user.full_name, "role": user.role, "email": user.email}
                }), 200
        
        # Check in Admin table
        admin = Admin.query.filter_by(email=email).first()
        if admin:
            print(f"[DEBUG] Found admin in Admin table. DB OTP: {admin.otp}")
            if str(admin.otp) == str(otp):
                admin.is_verified = True
                admin.otp = None
                db.session.commit()
                return jsonify({
                    "message": "Verification successful",
                    "user": {"id": admin.id, "full_name": admin.full_name, "role": admin.role, "email": admin.email}
                }), 200

        return jsonify({"message": "Invalid OTP"}), 400
    except Exception as e:
        print(f"[ERROR] Verification error: {str(e)}")
        return jsonify({"message": str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data['email']
    password = data['password']
    requested_role = data.get('role', 'user')
    
    Model = Admin if requested_role == 'admin' else User
    user = Model.query.filter_by(email=email).first()
    
    if user and check_password_hash(user.password, password):
        if not user.is_verified:
            return jsonify({"message": "Please verify your email first"}), 401
        
        return jsonify({
            "message": "Login successful",
            "user": {"id": user.id, "full_name": user.full_name, "role": user.role, "email": user.email}
        }), 200
        
    # Extra check: If they exist in the OTHER table
    OtherModel = User if requested_role == 'admin' else Admin
    other_user = OtherModel.query.filter_by(email=email).first()
    if other_user:
        return jsonify({"message": f"This account is registered as a {other_user.role}. Please login through the correct portal."}), 403

    return jsonify({"message": "Invalid credentials"}), 401

# --- Admin Dashboard & Stats ---

@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    admin_id = request.args.get('admin_id', type=int)
    # Stats for Growth Summary
    # 1. Verified Users (Distributors)
    total_users = User.query.filter_by(admin_id=admin_id, is_verified=True).count()
    pending_users = User.query.filter_by(admin_id=admin_id, is_verified=False).count()
    
    # 2. Locations (Unique addresses of verified farmers)
    location_count = db.session.query(db.func.count(db.distinct(User.address)))\
        .filter(User.admin_id == admin_id, User.is_verified == True).scalar() or 0
    
    # 3. Import Volume (Today's collection)
    today = datetime.utcnow().date()
    start_of_day = datetime.combine(today, datetime.min.time())
    end_of_day = datetime.combine(today, datetime.max.time())
    
    today_import = db.session.query(db.func.sum(MilkRecord.weight))\
        .join(User, MilkRecord.farmer_id == User.id)\
        .filter(User.admin_id == admin_id, MilkRecord.date.between(start_of_day, end_of_day)).scalar() or 0
        
    # 4. Distribution Volume
    today_distribution = today_import * 0.85
    
    # 5. Revenue (Monthly)
    start_of_month = datetime.combine(today.replace(day=1), datetime.min.time())
    monthly_revenue = db.session.query(db.func.sum(MilkRecord.total_amount))\
        .join(User, MilkRecord.farmer_id == User.id)\
        .filter(User.admin_id == admin_id, MilkRecord.date >= start_of_month).scalar() or 0

    payments_due = db.session.query(db.func.sum(MilkRecord.farmer_payout))\
        .join(User, MilkRecord.farmer_id == User.id)\
        .filter(User.admin_id == admin_id, MilkRecord.status == 'pending').scalar() or 0
    
    settings = AppSettings.query.first()
    
    recent_collections = db.session.query(MilkRecord, User.full_name)\
        .join(User, MilkRecord.farmer_id == User.id)\
        .filter(User.admin_id == admin_id)\
        .order_by(MilkRecord.date.desc()).limit(5).all()

    # Calculate Percentages for Dashboard Summary
    # 1. Production: Today's collection vs a target (e.g., 200L)
    daily_target = 200.0
    production_pct = min(int((today_import / daily_target) * 100), 100) if today_import > 0 else 0
    
    # 2. Marketing: (Distributed / Collected) % - using 85% as target
    marketing_target_pct = 85
    marketing_pct = min(int((today_distribution / (today_import or 1)) * 100), 100) if today_import > 0 else 0
    
    # 3. Service: (Supplements processed / Total farmers) % or similar mock
    total_supplements = Supplement.query.count()
    service_pct = min(int((total_supplements / (total_users or 1)) * 10), 100) if total_users > 0 else 0

    return jsonify({
        "verified_users": total_users,
        "pending_users": pending_users,
        "location_count": location_count,
        "import_volume": round(today_import, 2),
        "distribution_volume": round(today_distribution, 2),
        "monthly_revenue": round(monthly_revenue, 2),
        "revenue_target": 1000000,
        "today_collection": today_import,
        "payments_due": payments_due,
        "cow_price": settings.cow_milk_price if settings else 45.0,
        "buffalo_price": settings.buffalo_milk_price if settings else 65.0,
        "production_pct": production_pct,
        "marketing_pct": marketing_pct,
        "service_pct": service_pct,
        "recent_collections": [{
            "id": r[0].id,
            "farmer": r[1],
            "type": r[0].type,
            "liters": r[0].weight,
            "fat": r[0].fat,
            "amount": r[0].total_amount
        } for r in recent_collections]
    })

# --- Milk Collection APIs ---

@app.route('/api/milk/add', methods=['POST'])
def add_milk_record():
    data = request.json
    settings = AppSettings.query.first()
    if not settings:
        settings = AppSettings()
        db.session.add(settings)
        db.session.commit()
    
    milk_type = data.get('type', 'Cow').capitalize()
    fat = float(data.get('fat', 0))
    snf = float(data.get('snf', 0))
    weight = float(data.get('weight', 0))
    water = float(data.get('water', 0))
    
    # 1. Load Standards and Prices
    if milk_type == 'Cow':
        base = settings.cow_base_price
        normal = settings.cow_normal_price
        f_std = settings.cow_fat_std
        s_std = settings.cow_snf_std
    else: # Buffalo
        base = settings.buffalo_base_price
        normal = settings.buffalo_normal_price
        f_std = settings.buffalo_fat_std
        s_std = settings.buffalo_snf_std
        
    # 2. Quality Classification & Base Price Calculation
    quality = "Normal"
    price_per_liter = normal
    f_bonus = 0.0
    s_bonus = 0.0
    w_deduction = 0.0
    
    if fat < f_std or snf < s_std:
        quality = "Low"
        price_per_liter = base
    elif fat > f_std or snf > s_std:
        quality = "High"
        # Bonus calculation
        if fat > f_std:
            f_bonus = (fat - f_std) * settings.fat_bonus_rate
        if snf > s_std:
            s_bonus = (snf - s_std) * settings.snf_bonus_rate
        price_per_liter = normal + f_bonus + s_bonus
    else:
        quality = "Normal"
        price_per_liter = normal
        
    # 3. Water Deduction
    # Water threshold is in %, e.g. if water Liters / total Liters > threshold %
    water_pct = (water / weight * 100) if weight > 0 else 0
    if water_pct > settings.water_threshold:
        w_deduction = settings.water_deduction_rate
        price_per_liter -= w_deduction
        
    # 4. Safeguards
    # Ensure final price never falls below Base Price
    price_per_liter = max(price_per_liter, base)
    
    # 5. Total Calculations
    total_val = weight * price_per_liter
    farmer_val = total_val * (settings.farmer_share_pct / 100)
    
    new_record = MilkRecord(
        farmer_id=data['farmer_id'],
        type=milk_type,
        weight=weight,
        fat=fat,
        snf=snf,
        water=water,
        total_amount=total_val,
        farmer_payout=farmer_val,
        quality=quality,
        fat_bonus=f_bonus,
        snf_bonus=s_bonus,
        water_deduction=w_deduction
    )
    db.session.add(new_record)
    db.session.commit()
    return jsonify({
        "message": "Record added", 
        "price_per_liter": price_per_liter,
        "total_amount": total_val,
        "farmer_payout": farmer_val,
        "quality": quality,
        "bonus_breakdown": {
            "fat_bonus": f_bonus,
            "snf_bonus": s_bonus,
            "water_deduction": w_deduction
        }
    }), 201

@app.route('/api/admin/pending-payouts', methods=['GET'])
def get_pending_payouts():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
    
    # Get all users linked to this admin
    users = User.query.filter_by(admin_id=admin_id).all()
    user_ids = [u.id for u in users]
    
    # Query pending milk records for these users
    pending = db.session.query(
        User.id, User.full_name, 
        db.func.sum(MilkRecord.weight),
        db.func.avg(MilkRecord.fat),
        db.func.sum(MilkRecord.farmer_payout),
        BankDetail.bank_name,
        BankDetail.account_number,
        BankDetail.ifsc_code
    ).join(MilkRecord, User.id == MilkRecord.farmer_id)\
     .outerjoin(BankDetail, User.id == BankDetail.user_id)\
     .filter(User.id.in_(user_ids), MilkRecord.status == 'pending')\
     .group_by(User.id, User.full_name, BankDetail.bank_name, BankDetail.account_number, BankDetail.ifsc_code).all()
     
    return jsonify([{
        "id": p[0],
        "farmer": p[1],
        "totalLiters": float(p[2] or 0),
        "avgFat": float(p[3] or 0),
        "pendingAmount": float(p[4] or 0),
        "bank": p[5] or "N/A",
        "acc": p[6] or "N/A",
        "ifsc": p[7] or "N/A"
    } for p in pending])

@app.route('/api/admin/confirm-payment', methods=['POST'])
def confirm_payment():
    data = request.json
    user_id = data.get('user_id')
    amount = data.get('amount')
    
    if not user_id or amount is None:
        return jsonify({"message": "user_id and amount are required"}), 400
        
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    # Create payment record
    txn_id = f"TXN-{uuid.uuid4().hex[:8].upper()}"
    new_payment = Payment(
        user_id=user_id,
        amount=amount,
        status='completed',
        transaction_id=txn_id,
        type='Milk Payout',
        mode='Bank Transfer',
        receipt_data=json.dumps({
            "Paid To": user.full_name,
            "Amount": f"Rs. {amount}",
            "Date": datetime.utcnow().strftime('%Y-%m-%d %H:%M')
        })
    )
    
    # Update milk records to 'paid'
    MilkRecord.query.filter_by(farmer_id=user_id, status='pending').update({"status": "paid"})
    
    db.session.add(new_payment)
    db.session.commit()
    
    return jsonify({"message": "Payment confirmed", "transaction_id": txn_id}), 201

@app.route('/api/admin/payment-history', methods=['GET'])
def get_payment_history():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
        
    payments = Payment.query.join(User).filter(User.admin_id == admin_id).order_by(Payment.date.desc()).all()
    
    results = []
    for p in payments:
        receipt = json.loads(p.receipt_data) if p.receipt_data else {}
        results.append({
            "id": p.id,
            "txn_id": p.transaction_id,
            "farmer": p.user.full_name,
            "amount": p.amount,
            "status": p.status,
            "date": p.date.strftime('%Y-%m-%d'),
            "type": p.type,
            "mode": p.mode,
            "item": receipt.get("Item"),
            "buyer": p.user.full_name if 'Cattle' in (p.type or '') else None,
            "cattle": receipt.get("Cattle"),
            "seller": receipt.get("Seller"),
            "receipt_data": receipt
        })
    
    return jsonify(results)

@app.route('/api/admin/settings', methods=['GET', 'POST'])
def handle_settings():
    settings = AppSettings.query.first()
    if not settings:
        settings = AppSettings()
        db.session.add(settings)
        db.session.commit()
        
    if request.method == 'POST':
        data = request.json
        # List of all pricing fields
        fields = [
            'cow_base_price', 'cow_normal_price', 'cow_fat_std', 'cow_snf_std',
            'buffalo_base_price', 'buffalo_normal_price', 'buffalo_fat_std', 'buffalo_snf_std',
            'fat_bonus_rate', 'snf_bonus_rate', 'water_threshold', 'water_deduction_rate',
            'cow_milk_price', 'buffalo_milk_price'
        ]
        for field in fields:
            if field in data:
                setattr(settings, field, data[field])
                
        db.session.commit()
        return jsonify({"message": "Settings updated"})
        
    return jsonify({
        "cow_base_price": settings.cow_base_price,
        "cow_normal_price": settings.cow_normal_price,
        "cow_fat_std": settings.cow_fat_std,
        "cow_snf_std": settings.cow_snf_std,
        "buffalo_base_price": settings.buffalo_base_price,
        "buffalo_normal_price": settings.buffalo_normal_price,
        "buffalo_fat_std": settings.buffalo_fat_std,
        "buffalo_snf_std": settings.buffalo_snf_std,
        "fat_bonus_rate": settings.fat_bonus_rate,
        "snf_bonus_rate": settings.snf_bonus_rate,
        "water_threshold": settings.water_threshold,
        "water_deduction_rate": settings.water_deduction_rate,
        "cow_milk_price": settings.cow_milk_price,
        "buffalo_milk_price": settings.buffalo_milk_price,
        "farmer_share": settings.farmer_share_pct,
        "admin_cut": settings.admin_cut_pct,
        "company_cut": settings.company_cut_pct
    })

@app.route('/api/admin/bank-details', methods=['GET', 'POST'])
def handle_admin_bank():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
        
    # We can use a simplified approach or create a dedicated AdminBank model.
    # For now, let's just return success for the UI as the user didn't ask for a new table yet.
    # But it's better to implement it correctly.
    return jsonify({"message": "Operation successful"})

@app.route('/api/admin/users', methods=['GET'])
def get_users():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
        
    users = User.query.filter_by(admin_id=admin_id).all()
    return jsonify([{
        "id": u.id, 
        "full_name": u.full_name, 
        "mobile": u.mobile,
        "is_verified": u.is_verified, 
        "email": u.email,
        "address": u.address,
        "created_at": u.created_at.strftime('%Y-%m-%d'),
        "bank_details": {
            "bank_name": u.bank_details.bank_name if u.bank_details else "N/A",
            "account_holder": u.bank_details.account_holder if u.bank_details else "N/A",
            "account_number": u.bank_details.account_number if u.bank_details else "N/A",
            "ifsc_code": u.bank_details.ifsc_code if u.bank_details else "N/A"
        } if u.bank_details else None
    } for u in users])

@app.route('/api/user/<int:user_id>/records', methods=['GET'])
def get_user_records(user_id):
    milk_records = MilkRecord.query.filter_by(farmer_id=user_id).order_by(MilkRecord.date.desc()).all()
    payments = Payment.query.filter_by(user_id=user_id).order_by(Payment.date.desc()).all()
    
    return jsonify({
        "milk_records": [{
            "id": r.id,
            "date": r.date.strftime('%Y-%m-%d'),
            "type": r.type,
            "weight": r.weight,
            "fat": r.fat,
            "snf": r.snf,
            "amount": r.total_amount
        } for r in milk_records],
        "payments": [{
            "id": p.id,
            "date": p.date.strftime('%Y-%m-%d'),
            "amount": p.amount,
            "status": p.status,
            "type": p.type
        } for p in payments]
    })

@app.route('/api/bank-details/<int:user_id>', methods=['GET', 'POST'])
def handle_bank_details(user_id):
    if request.method == 'POST':
        data = request.json
        bank = BankDetail.query.filter_by(user_id=user_id).first()
        if not bank:
            bank = BankDetail(user_id=user_id)
            db.session.add(bank)
        bank.bank_name = data['bank_name']
        bank.account_holder = data['account_holder']
        bank.account_number = data['account_number']
        bank.ifsc_code = data['ifsc_code']
        db.session.commit()
        return jsonify({"message": "Bank details saved"})
    
    bank = BankDetail.query.filter_by(user_id=user_id).first()
    if bank:
        return jsonify({
            "bank_name": bank.bank_name, "account_holder": bank.account_holder,
            "account_number": bank.account_number, "ifsc_code": bank.ifsc_code
        })
    return jsonify({"message": "Not found"}), 404

# --- Milk & Payments Export ---

@app.route('/api/export/milk-history', methods=['GET'])
def export_milk_history():
    user_id = request.args.get('user_id')
    admin_id = request.args.get('admin_id')
    
    query = MilkRecord.query
    if user_id:
        query = query.filter_by(farmer_id=user_id)
    elif admin_id:
        query = query.join(User, MilkRecord.farmer_id == User.id).filter(User.admin_id == admin_id)
    
    records = query.order_by(MilkRecord.date.desc()).all()
    
    data = []
    for r in records:
        # Determine Quality Reason
        reason = ""
        quality = r.quality or "Normal"
        if quality == "Low":
            if r.fat < 3.5: reason += f"Fat low ({r.fat}%) "
            if r.snf < 8.0: reason += f"SNF low ({r.snf}%) "
            if r.water > 10: reason += f"Water high ({r.water}L) "
        
        data.append({
            "Record ID": r.id,
            "Farmer ID": r.farmer_id,
            "Farmer Name": r.farmer.full_name,
            "Mobile": r.farmer.mobile,
            "Date": r.date.strftime('%Y-%m-%d'),
            "Time": r.date.strftime('%H:%M:%S'),
            "Milk Type": r.type,
            "Weight (Liters)": r.weight,
            "Fat (%)": r.fat,
            "SNF (%)": r.snf,
            "Water Added (L)": r.water,
            "Total Amount (Rs)": round(r.total_amount or 0, 2),
            "Farmer Payout (Rs)": round(r.farmer_payout or 0, 2),
            "Quality Status": quality,
            "Issues/Reason": reason if reason else "None",
            "Payment Status": r.status
        })
    
    if not data:
        return "No data found for export", 404
        
    df = pd.DataFrame(data)
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Milk Collection Data')
    output.seek(0)
    
    filename = f"Milk_Collection_Report_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return send_file(output, as_attachment=True, download_name=filename)

@app.route('/api/export/receipt/<int:payment_id>', methods=['GET'])
def export_receipt_pdf(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    receipt_details = json.loads(payment.receipt_data)
    
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    p.setFont("Helvetica-Bold", 20)
    p.drawString(100, 750, "DAIRY PRO CONNECT")
    p.setFont("Helvetica", 12)
    p.drawString(100, 730, "Official Payment Receipt")
    p.line(100, 720, 500, 720)
    
    y = 690
    p.drawString(100, y, f"Transaction ID: {payment.transaction_id}")
    y -= 20
    p.drawString(100, y, f"Date: {payment.date.strftime('%Y-%m-%d %H:%M')}")
    y -= 20
    p.drawString(100, y, f"Type: {payment.type}")
    y -= 20
    p.drawString(100, y, f"Farmer Name: {payment.user.full_name}")
    y -= 40
    p.setFont("Helvetica-Bold", 14)
    p.drawString(100, y, f"Amount Paid: Rs. {payment.amount}")
    y -= 30
    p.setFont("Helvetica", 10)
    p.drawString(100, y, "Details:")
    y -= 15
    for key, val in receipt_details.items():
        p.drawString(120, y, f"{key}: {val}")
        y -= 15
    p.line(100, y, 500, y)
    y -= 20
    p.drawString(100, y, "Thank you for using Dairy Pro Connect!")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"receipt_{payment.transaction_id}.pdf")

# --- Supplements Logic ---

@app.route('/api/admin/supplements', methods=['GET'])
def get_admin_supplements():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
        
    # Get all supplements for farmers linked to this admin
    supplements = Supplement.query.join(User).filter(User.admin_id == admin_id).order_by(Supplement.date.desc()).all()
    
    total_distributions = len(supplements)
    free_distributions = sum(1 for s in supplements if s.is_free)
    paid_distributions = total_distributions - free_distributions
    
    return jsonify({
        "stats": {
            "total": total_distributions,
            "free": free_distributions,
            "paid": paid_distributions
        },
        "records": [{
            "id": s.id,
            "farmer": s.farmer.full_name,
            "supplement": s.name,
            "quantity": s.quantity,
            "unit": s.unit,
            "isFree": s.is_free,
            "price": s.price,
            "date": s.date.strftime('%Y-%m-%d'),
            "status": s.status
        } for s in supplements]
    })

@app.route('/api/admin/pending-supplements', methods=['GET'])
def get_pending_supplements():
    admin_id = request.args.get('admin_id')
    if not admin_id:
        return jsonify({"message": "admin_id is required"}), 400
        
    pending = Supplement.query.join(User).filter(
        User.admin_id == admin_id,
        Supplement.status == 'requested'
    ).order_by(Supplement.date.desc()).all()
    
    return jsonify([{
        "id": s.id,
        "farmer": s.farmer.full_name,
        "farmer_id": s.farmer_id,
        "supplement": s.name,
        "quantity": s.quantity,
        "unit": s.unit,
        "isFree": s.is_free,
        "price": s.price,
        "date": s.date.strftime('%Y-%m-%d')
    } for s in pending])

@app.route('/api/admin/supplements/approve', methods=['POST'])
def approve_supplement():
    data = request.json
    sup_id = data.get('id')
    
    sup = Supplement.query.get_or_404(sup_id)
    sup.status = 'delivered'
    
    if not sup.is_free and sup.price > 0:
        txn_id = f"SUP-{uuid.uuid4().hex[:8].upper()}"
        new_payment = Payment(
            user_id=sup.farmer_id,
            amount=sup.price,
            type='Supplement Purchase',
            transaction_id=txn_id,
            mode='Deduction',
            status='completed',
            receipt_data=json.dumps({
                "Item": sup.name,
                "Quantity": f"{sup.quantity} {sup.unit}",
                "Farmer": sup.farmer.full_name
            })
        )
        db.session.add(new_payment)
        
    db.session.commit()
    return jsonify({"message": "Supplement approved and recorded"})

@app.route('/api/admin/supplements/add', methods=['POST'])
def add_supplement_distribution():
    data = request.json
    farmer_id = data['farmer_id']
    price = data.get('price', 0)
    is_free = data.get('is_free', False)
    
    new_sup = Supplement(
        farmer_id=farmer_id,
        name=data['name'],
        quantity=data['quantity'],
        unit=data.get('unit', 'kg'),
        price=price,
        is_free=is_free,
        status='delivered'
    )
    db.session.add(new_sup)
    
    # If not free, create a payment record
    if not is_free and price > 0:
        txn_id = f"SUP-{uuid.uuid4().hex[:8].upper()}"
        new_payment = Payment(
            user_id=farmer_id,
            amount=price,
            type='Supplement Purchase',
            transaction_id=txn_id,
            mode='Cash/Deduction',
            status='completed',
            receipt_data=json.dumps({
                "Item": data['name'],
                "Quantity": f"{data['quantity']} {data.get('unit', 'kg')}",
                "Farmer": User.query.get(farmer_id).full_name
            })
        )
        db.session.add(new_payment)
        
    db.session.commit()
    return jsonify({"message": "Distribution recorded"}), 201

@app.route('/api/admin/cattle', methods=['GET'])
def get_admin_cattle():
    admin_id_raw = request.args.get('admin_id')
    if not admin_id_raw:
        return jsonify({"message": "admin_id is required"}), 400
    
    try:
        admin_id = int(admin_id_raw)
    except ValueError:
        return jsonify({"message": "Invalid admin_id format"}), 400
        
    # Get all listings from users linked to this admin or where listing's admin_id matches
    # Step 1: Get User IDs for this admin
    user_ids = [u.id for u in User.query.filter_by(admin_id=admin_id).all()]
    
    # Step 2: Query listings
    listings = CattleListing.query.filter(
        (CattleListing.seller_id.in_(user_ids)) | (CattleListing.admin_id == admin_id)
    ).order_by(CattleListing.created_at.desc()).all()
    
    active_listings = [l for l in listings if l.status == 'available']
    total_value = sum(l.price for l in active_listings)
    
    # Simple count for "sold this month"
    start_of_month = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    sold_this_month = CattleListing.query.filter(
        (CattleListing.seller_id.in_(user_ids)) | (CattleListing.admin_id == admin_id),
        CattleListing.status == 'sold',
        CattleListing.created_at >= start_of_month
    ).count()

    return jsonify({
        "stats": {
            "active": len(active_listings),
            "total_value": total_value,
            "sold_this_month": sold_this_month
        },
        "listings": [{
            "id": l.id,
            "owner": l.seller.full_name,
            "type": l.type or "",
            "age": l.age,
            "calves": l.calves,
            "price": l.price,
            "address": l.location or "", # Frontend expects 'address'
            "medical": l.medical_records,
            "created": l.created_at.strftime('%Y-%m-%d'),
            "status": l.status or "available",
            "milk_yield": l.milk_yield,
            "image_url": (l.image_url if (l.image_url and l.image_url.startswith('http')) else (f"/uploads/{l.image_url}" if l.image_url else None))
        } for l in listings]
    })

# --- Cattle Booking ---

@app.route('/api/user/stats/<int:user_id>', methods=['GET'])
def get_user_stats(user_id):
    user = User.query.get_or_404(user_id)
    
    total_milk = db.session.query(db.func.sum(MilkRecord.weight)).filter_by(farmer_id=user_id).scalar() or 0
    avg_fat = db.session.query(db.func.avg(MilkRecord.fat)).filter_by(farmer_id=user_id).scalar() or 0
    total_earnings = db.session.query(db.func.sum(MilkRecord.farmer_payout)).filter_by(farmer_id=user_id, status='paid').scalar() or 0
    pending_payout = db.session.query(db.func.sum(MilkRecord.farmer_payout)).filter_by(farmer_id=user_id, status='pending').scalar() or 0
    
    settings = AppSettings.query.first()
    
    return jsonify({
        "total_milk": float(total_milk),
        "avg_fat": float(avg_fat),
        "total_earnings": float(total_earnings),
        "pending_payout": float(pending_payout),
        "cow_price": settings.cow_milk_price if settings else 45.0,
        "buffalo_price": settings.buffalo_milk_price if settings else 65.0,
        "farmer_share": settings.farmer_share_pct if settings else 90.0,
        "admin_cut": settings.admin_cut_pct if settings else 6.0,
        "company_cut": settings.company_cut_pct if settings else 4.0
    })

@app.route('/api/user/supplements/<int:user_id>', methods=['GET'])
def get_user_supplements(user_id):
    supplements = Supplement.query.filter_by(farmer_id=user_id).order_by(Supplement.date.desc()).all()
    return jsonify([{
        "id": s.id,
        "name": s.name,
        "quantity": s.quantity,
        "unit": s.unit,
        "price": s.price,
        "is_free": s.is_free,
        "status": s.status,
        "date": s.date.strftime('%Y-%m-%d')
    } for s in supplements])

@app.route('/api/cattle/listings', methods=['GET'])
def get_all_cattle_listings():
    listings = CattleListing.query.join(User, CattleListing.seller_id == User.id)\
        .filter(CattleListing.status == 'available')\
        .order_by(CattleListing.created_at.desc()).all()
    return jsonify([{
        "id": l.id,
        "owner": l.seller.full_name if l.seller else "Unknown",
        "type": l.type or "",
        "age": l.age,
        "calves": l.calves,
        "price": l.price,
        "address": l.location or "",
        "medical": l.medical_records,
        "created": l.created_at.strftime('%Y-%m-%d'),
        "status": l.status or "available",
        "milk_yield": l.milk_yield,
        "image_url": (l.image_url if (l.image_url and l.image_url.startswith('http')) else (f"/uploads/{l.image_url}" if l.image_url else None))
    } for l in listings])

@app.route('/api/cattle/user/<int:user_id>', methods=['GET'])
def get_user_cattle_listings(user_id):
    listings = CattleListing.query.filter_by(seller_id=user_id).order_by(CattleListing.created_at.desc()).all()
    return jsonify([{
        "id": l.id,
        "owner": l.seller.full_name,
        "type": l.type,
        "age": l.age,
        "calves": l.calves,
        "price": l.price,
        "address": l.location,
        "medical": l.medical_records,
        "created": l.created_at.strftime('%Y-%m-%d'),
        "status": l.status,
        "milk_yield": l.milk_yield,
        "image_url": (l.image_url if (l.image_url and l.image_url.startswith('http')) else (f"/uploads/{l.image_url}" if l.image_url else None)),
        "buyer": {
            "name": l.buyer.full_name,
            "mobile": l.buyer.mobile,
            "address": l.buyer.address
        } if l.buyer_id and l.buyer else None
    } for l in listings])

@app.route('/api/user/profile/<int:user_id>', methods=['GET'])
def get_user_profile(user_id):
    u = User.query.get_or_404(user_id)
    return jsonify({
        "id": u.id,
        "full_name": u.full_name,
        "email": u.email,
        "mobile": u.mobile,
        "address": u.address,
        "is_verified": u.is_verified,
        "created_at": u.created_at.strftime('%Y-%m-%d'),
        "aadhaar": u.aadhaar_number,
        "pan": u.pan_number,
        "admin_name": Admin.query.get(u.admin_id).full_name if u.admin_id else "Not Assigned"
    })

@app.route('/api/user/supplements/request', methods=['POST'])
def request_supplement():
    data = request.json
    user_id = data.get('user_id')
    supplement_name = data.get('name')
    price = data.get('price', 0)
    
    # Check if first supplement this month
    now = datetime.utcnow()
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    existing = Supplement.query.filter(
        Supplement.farmer_id == user_id,
        Supplement.date >= start_of_month
    ).first()
    
    is_free = existing is None
    payment_mode = data.get('payment_mode', 'Online/Wallet')
    
    new_sup = Supplement(
        farmer_id=user_id,
        name=supplement_name,
        quantity=1,
        unit='Bag/Pack',
        price=0 if is_free else price,
        is_free=is_free,
        status='requested'
    )
    db.session.add(new_sup)
    
    # Create payment record if not free
    txn_id = None
    if not is_free and price > 0:
        txn_id = f"SUP-{uuid.uuid4().hex[:8].upper()}"
        user = User.query.get(user_id)
        new_payment = Payment(
            user_id=user_id,
            admin_id=user.admin_id,
            amount=price,
            type='Supplement Purchase',
            transaction_id=txn_id,
            mode=f"Online ({payment_mode.upper()})",
            status='completed',
            receipt_data=json.dumps({
                "Item": supplement_name,
                "Quantity": "1 Bag/Pack",
                "Farmer": user.full_name,
                "Payment Method": payment_mode.upper()
            })
        )
        db.session.add(new_payment)

    db.session.commit()
    
    return jsonify({
        "message": "Supplement requested successfully",
        "is_free": is_free,
        "price": 0 if is_free else price,
        "transaction_id": txn_id
    }), 201

@app.route('/api/cattle/listings/add', methods=['POST'])
def add_cattle_listing():
    # Support both JSON and Form Data
    if request.is_json:
        data = request.json
        image_url = None
    else:
        data = request.form
        image_file = request.files.get('image')
        image_url = upload_image(image_file) if image_file else None

    seller_id = data.get('seller_id')
    seller = db.session.get(User, seller_id)
    if not seller:
        return jsonify({"message": "User not found"}), 404
        
    new_listing = CattleListing(
        seller_id=seller_id,
        admin_id=seller.admin_id,
        type=data.get('type'),
        age=data.get('age'),
        price=float(data.get('price', 0)),
        location=data.get('location', 'Registered Address'),
        calves=int(data.get('calves', 0)),
        milk_yield=float(data.get('milkYield', 0)),
        medical_records=data.get('medicalRecords', 'None provided'),
        status='available',
        image_url=image_url
    )
    db.session.add(new_listing)
    db.session.commit()
    return jsonify({"message": "Cattle listed successfully"}), 201

@app.route('/api/cattle/book', methods=['POST'])
def book_cattle():
    data = request.json
    listing_id = data.get('listing_id')
    buyer_id = data.get('buyer_id')
    
    listing = CattleListing.query.get(listing_id)
    if not listing:
        return jsonify({"message": "Listing not found"}), 404
    
    if listing.seller_id == buyer_id:
        return jsonify({"message": "You cannot book your own listing"}), 400
        
    listing.status = 'booked'
    listing.buyer_id = buyer_id
    
    # Create a 10% advance payment record
    advance_amount = listing.price * 0.1
    txn_id = f"CAT-{uuid.uuid4().hex[:8].upper()}"
    new_payment = Payment(
        user_id=buyer_id,
        admin_id=listing.admin_id, # Route 10% fee to Admin
        amount=advance_amount,
        type='Cattle Advance (10%)',
        transaction_id=txn_id,
        mode='Online/Wallet',
        status='completed',
        receipt_data=json.dumps({
            "Cattle": listing.type,
            "Total Price": f"Rs. {listing.price}",
            "Advance Paid": f"Rs. {advance_amount}",
            "Seller": listing.seller.full_name
        })
    )
    db.session.add(new_payment)
    db.session.commit()
    
    return jsonify({
        "message": "Cattle booked successfully",
        "seller_phone": listing.seller.mobile,
        "transaction_id": txn_id,
        "advance_paid": advance_amount
    }), 200

# --- About Us, Posts & Profile APIs ---

from werkzeug.utils import secure_filename
import time

@app.route('/api/admin/<int:admin_id>', methods=['PUT'])
def update_admin_profile(admin_id):
    try:
        admin = Admin.query.get(admin_id)
        if not admin:
            return jsonify({"message": "Admin not found"}), 404
            
        data = request.form if request.content_type.startswith('multipart/form-data') else request.json
        
        if 'photo' in request.files:
            file = request.files['photo']
            if file and file.filename != '':
                admin.photo_url = upload_image(file)
                
        if 'city' in data: admin.city = data['city']
        if 'state' in data: admin.state = data['state']
        if 'address' in data: admin.address = data['address']
        if 'full_name' in data: admin.full_name = data['full_name']
            
        db.session.commit()
        return jsonify({
            "message": "Profile updated", 
            "photo_url": admin.photo_url,
            "city": admin.city,
            "state": admin.state,
            "address": admin.address
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/users/<int:user_id>', methods=['PUT'])
def update_user_profile(user_id):
    data = request.json
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({"message": "User not found"}), 404
            
        email_changed = False
        new_email = data.get('email')
        
        if new_email and new_email != user.email:
            existing = User.query.filter_by(email=new_email).first() or Admin.query.filter_by(email=new_email).first()
            if existing:
                return jsonify({"message": "Email already in use"}), 400
            user.email = new_email
            email_changed = True
            
        if 'full_name' in data: user.full_name = data['full_name']
        if 'mobile' in data: user.mobile = data['mobile']
        if 'address' in data: user.address = data['address']
        if 'aadhaar' in data and not user.aadhaar_number: user.aadhaar_number = data['aadhaar']
        if 'pan' in data and not user.pan_number: user.pan_number = data['pan']
        
        if email_changed:
            user.is_verified = False
            otp = str(random.randint(100000, 999999))
            user.otp = otp
            user.otp_expiry = datetime.utcnow() + timedelta(minutes=10)
            threading.Thread(target=send_async_email, args=(app, new_email, otp)).start()
                
        db.session.commit()
        
        return jsonify({
            "message": "Profile updated successfully" if not email_changed else "Email updated. Please verify OTP sent to new email.",
            "email_changed": email_changed,
            "user": {
                "id": user.id, "full_name": user.full_name, "email": user.email, "mobile": user.mobile, "address": user.address, "is_verified": user.is_verified, "aadhaar": user.aadhaar_number, "pan": user.pan_number
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/debug/db', methods=['GET'])
def debug_db():
    try:
        from sqlalchemy import inspect, text
        inspector = inspect(db.engine)
        tables = inspector.get_table_names()
        
        table_counts = {}
        with db.engine.connect() as conn:
            for table in tables:
                res = conn.execute(text(f'SELECT COUNT(*) FROM "{table}"'))
                table_counts[table] = res.scalar()
                
        return jsonify({
            "status": "connected",
            "database": "Neon",
            "tables_found": len(tables),
            "details": table_counts
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/admin/posts', methods=['POST'])
def create_admin_post():
    admin_id = request.form.get('admin_id')
    content = request.form.get('content')
    if not admin_id or not content:
        return jsonify({"message": "admin_id and content are required"}), 400
        
    media_url = None
    media_type = None
    
    if 'media' in request.files:
        file = request.files['media']
        if file and file.filename != '':
            media_url = upload_image(file)
            ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
            media_type = 'video' if ext in ['mp4', 'mov', 'webm'] else 'image'
            
    try:
        new_post = Post(admin_id=admin_id, content=content, media_url=media_url, media_type=media_type)
        db.session.add(new_post)
        db.session.commit()
        return jsonify({"message": "Post created successfully"}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@app.route('/api/posts', methods=['GET'])
def get_posts():
    try:
        admin_id = request.args.get('admin_id') # Optional filter
        query = Post.query
        if admin_id:
            query = query.filter_by(admin_id=admin_id)
            
        posts = query.order_by(Post.created_at.desc()).all()
        
        return jsonify([{
            "id": p.id,
            "admin_id": p.admin_id,
            "admin_name": p.admin.full_name,
            "admin_photo": p.admin.photo_url,
            "content": p.content,
            "media_url": p.media_url,
            "media_type": p.media_type,
            "created_at": p.created_at.strftime('%Y-%m-%d %H:%M')
        } for p in posts])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ✅ Tables auto-create hoti hain — Gunicorn + local dono ke liye
with app.app_context():
    db.create_all()
    if not AppSettings.query.first():
        db.session.add(AppSettings())
        db.session.commit()

# --- DONATION ENDPOINTS ---

@app.route('/api/donate', methods=['POST'])
def add_donation():
    data = request.json
    try:
        new_donation = Donation(
            donor_name=data.get('donor_name'),
            donor_phone=data.get('donor_phone'),
            amount=float(data.get('amount')),
            admin_id=int(data.get('admin_id')),
            message=data.get('message', ''),
            payment_mode=data.get('payment_mode', 'card'),
            location=data.get('location', ''),
            status='completed'
        )
        db.session.add(new_donation)
        db.session.commit()
        return jsonify({"message": "Donation recorded successfully", "id": new_donation.id}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 400

@app.route('/api/admin/donations', methods=['GET'])
def get_admin_donations():
    # In a real app, we'd filter by logged-in admin. 
    # For now, we'll use a query param or return all if no param.
    admin_id = request.args.get('admin_id', type=int)
    query = Donation.query
    if admin_id:
        query = query.filter_by(admin_id=admin_id)
    
    donations = query.order_by(Donation.date.desc()).all()
    return jsonify([{
        "id": d.id,
        "donor_name": d.donor_name,
        "amount": d.amount,
        "date": d.date.strftime('%Y-%m-%d %H:%M'),
        "message": d.message,
        "location": d.location,
        "payment_mode": d.payment_mode
    } for d in donations])

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
