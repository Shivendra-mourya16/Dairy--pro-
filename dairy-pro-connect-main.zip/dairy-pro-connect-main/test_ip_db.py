import os
import psycopg2
from dotenv import load_dotenv

# Use the IP resolved from Google DNS
ip = "13.228.184.17" 
url = "postgresql://neondb_owner:npg_AGSE1tkzXua8@13.228.184.17/neondb?sslmode=require"

try:
    print(f"Connecting to IP: {ip}")
    # We might need to pass the actual host for SSL SNI
    conn = psycopg2.connect(url, host=ip)
    print("Connection successful!")
    cur = conn.cursor()
    cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';")
    tables = cur.fetchall()
    print("Tables found:", tables)
    cur.close()
    conn.close()
except Exception as e:
    print("Connection failed!")
    print(e)
